/* =====================================================================
   اسکریپت ۰۱ — بررسی پیش‌نیازهای FILESTREAM (فقط‌خواندنی / READ-ONLY)
   پروژه: سامانه مدیریت بودجه سرمایه‌ای (Capital Budget Management System)
   ماژول: مدیریت پیوست‌ها — سند طراحی ۰۳ نسخه ۶ (تصمیم D-21)
   ---------------------------------------------------------------------
   هدف:
     اطمینان از اینکه ذخیره‌سازی FILESTREAM در سطح نمونه (Instance) و
     پایگاه‌داده جاری آماده است؛ شامل: سطح پیکربندی‌شده، سطح مؤثر، نام
     Share، مقدار sp_configure «filestream access level»، پشتیبانی
     ویرایش، وجود فایل‌گروپ FILESTREAM در پایگاه‌داده جاری و فضای آزاد
     ولوم‌های میزبان فایل‌ها (sys.dm_os_volume_stats).
   ---------------------------------------------------------------------
   نکات ایمنی:
     * این اسکریپت «فقط‌خواندنی» است و هیچ شیء، داده یا تنظیمی را
       تغییر نمی‌دهد. اصلاح FILESTREAM «خودکار انجام نمی‌شود» و باید
       دستی (Configuration Manager + sp_configure + ری‌استارت) توسط
       IT/DBA انجام شود — ستون توضیح ردیف FAIL راهنمای کامل را می‌دهد.
     * قابل اجرای مکرر (Idempotent) است.
   ---------------------------------------------------------------------
   نگاشت ستون Status: PASS = تائید | WARN = هشدار | FAIL = رد (باید
   پیش از اسکریپت ۰۲ برطرف شود). توضیح هر ردیف به فارسی است.
   ===================================================================== */
SET NOCOUNT ON;

DECLARE @DbName NVARCHAR(128) = DB_NAME();

IF @DbName IN (N'master', N'model', N'msdb', N'tempdb')
BEGIN
    PRINT N'FAIL: در یک پایگاه‌داده سیستمی هستید. ابتدا با USE به پایگاه‌داده هدف (CapitalBudgetManagement_Lab) متصل شوید.';
    RETURN;
END

CREATE TABLE #Checklist
(
    Id       INT IDENTITY(1,1) NOT NULL,
    [بررسی]  NVARCHAR(150) COLLATE DATABASE_DEFAULT NOT NULL,
    [مقدار]  NVARCHAR(400) COLLATE DATABASE_DEFAULT NOT NULL,
    [Status] NVARCHAR(10)  COLLATE DATABASE_DEFAULT NOT NULL,
    [توضیح]  NVARCHAR(1200) COLLATE DATABASE_DEFAULT NULL
);

/* ---------- ۱) سطح پیکربندی‌شده FILESTREAM ---------- */
DECLARE @Configured INT = CAST(SERVERPROPERTY('FilestreamConfiguredLevel') AS INT);

INSERT INTO #Checklist ([بررسی], [مقدار], [Status], [توضیح])
VALUES (N'سطح پیکربندی‌شده FILESTREAM (FilestreamConfiguredLevel)', CAST(@Configured AS NVARCHAR(10)),
        CASE WHEN @Configured >= 2 THEN N'PASS' WHEN @Configured = 1 THEN N'WARN' ELSE N'FAIL' END,
        CASE
            WHEN @Configured >= 2 THEN N'دسترسی کامل پیکربندی شده است (۰=غیرفعال، ۱=فقط T-SQL، ۲=T-SQL + جریان Win32، ۳=Win32 محلی).'
            WHEN @Configured = 1  THEN N'فقط دسترسی T-SQL پیکربندی شده؛ برای جریان (Streaming) دانلود/بارگذاری سطح ۲ توصیه می‌شود. پس از تغییر، RECONFIGURE و ری‌استارت سرویس لازم است.'
            ELSE N'FILESTREAM در سطح نمونه پیکربندی نشده است — مراحل اصلاح دستی در ردیف «سطح مؤثر» آمده است.'
        END);

/* ---------- ۲) سطح مؤثر FILESTREAM (مهم‌ترین بررسی) ---------- */
DECLARE @Effective INT = CAST(SERVERPROPERTY('FilestreamEffectiveLevel') AS INT);

INSERT INTO #Checklist ([بررسی], [مقدار], [Status], [توضیح])
VALUES (N'سطح مؤثر FILESTREAM (FilestreamEffectiveLevel)', CAST(@Effective AS NVARCHAR(10)),
        CASE WHEN @Effective >= 2 THEN N'PASS' WHEN @Effective = 1 THEN N'WARN' ELSE N'FAIL' END,
        CASE
            WHEN @Effective >= 2 THEN N'سطح مؤثر کامل است؛ ساخت فایل‌گروپ FILESTREAM توسط اسکریپت ۰۲ ممکن است.'
            WHEN @Effective = 1  THEN N'فقط دسترسی T-SQL فعال است؛ عملیات پیوست‌ها کار می‌کند اما جریان Win32 (SqlFileStream) غیرفعال است.'
            ELSE N'سطح مؤثر FILESTREAM صفر است؛ امکان ساخت فایل‌گروپ FILESTREAM وجود ندارد و اسکریپت ۰۲ متوقف خواهد شد. اصلاح خودکار انجام نمی‌شود — مراحل دستی: (۱) در SQL Server Configuration Manager زیر SQL Server Services روی سرویس SQL Server راست‌کلیک و Properties → زبانه FILESTREAM → تیک «Enable FILESTREAM for Transact-SQL access» (و در صورت نیاز جریان Win32/I/O) را فعال کنید؛ (۲) اجرای دستور: EXEC sp_configure N''filestream access level'', 2; و سپس RECONFIGURE; (۳) ری‌استارت سرویس SQL Server (و در صورت تغییر سطح مؤثر، ری‌استارت مجدد)؛ (۴) اجرای مجدد همین اسکریپت تا دریافت PASS.'
        END);

/* ---------- ۳) نام Share مربوط به FILESTREAM ---------- */
DECLARE @Share NVARCHAR(128) = CONVERT(NVARCHAR(128), SERVERPROPERTY('FilestreamShareName'));

INSERT INTO #Checklist ([بررسی], [مقدار], [Status], [توضیح])
SELECT N'نام Share فایل‌استریم (FilestreamShareName)',
       CASE WHEN @Share IS NULL OR @Share = N'' THEN N'خالی' ELSE @Share END,
       CASE WHEN @Effective = 0 THEN N'FAIL'
            WHEN @Share IS NULL OR @Share = N'' THEN N'WARN'
            ELSE N'PASS' END,
       CASE
            WHEN @Effective = 0 THEN N'تا زمان فعال‌سازی FILESTREAM، Share معنایی ندارد.'
            WHEN @Share IS NULL OR @Share = N'' THEN N'Share تعیین نشده — در Configuration Manager نام Share را مشخص و سرویس را ری‌استارت کنید (برای دسترسی T-SQL صرف، مانع نیست).'
            ELSE N'Share برای دسترسی جریان Win32 آماده است؛ این نام از بیرون سرور نمایش داده نمی‌شود.'
       END;

/* ---------- ۴) مقدار sp_configure «filestream access level» (با کنترل مجوز) ---------- */
IF HAS_PERMS_BY_NAME(NULL, NULL, 'VIEW SERVER STATE') = 1
BEGIN
    DECLARE @CfgConfigured INT = (SELECT CAST(sc.value AS INT)     FROM sys.configurations AS sc WHERE sc.name = N'filestream access level');
    DECLARE @CfgInUse     INT = (SELECT CAST(sc.value_in_use AS INT) FROM sys.configurations AS sc WHERE sc.name = N'filestream access level');

    INSERT INTO #Checklist ([بررسی], [مقدار], [Status], [توضیح])
    SELECT N'sp_configure (sys.configurations) — filestream access level',
           N'پیکربندی‌شده: ' + ISNULL(CAST(@CfgConfigured AS NVARCHAR(10)), N'؟')
         + N' | در حال استفاده: ' + ISNULL(CAST(@CfgInUse AS NVARCHAR(10)), N'؟'),
           CASE WHEN @CfgConfigured IS NULL OR @CfgInUse IS NULL THEN N'WARN'
                WHEN @CfgInUse = @Effective AND @CfgConfigured = @CfgInUse AND @CfgInUse >= 1 THEN N'PASS'
                ELSE N'WARN' END,
           CASE
                WHEN @CfgConfigured IS NULL OR @CfgInUse IS NULL THEN N'ردیف پیکربندی یافت نشد — بررسی دستی با sp_configure انجام شود.'
                WHEN @CfgInUse = @Effective AND @CfgConfigured = @CfgInUse AND @CfgInUse >= 1
                     THEN N'مقدار sp_configure با سطح مؤثر/پیکربندی‌شده هماهنگ است.'
                ELSE N'ناهماهنگی بین مقدار پیکربندی و مقدار جاری — پس از sp_configure باید RECONFIGURE و در صورت نیاز ری‌استارت سرویس انجام شود.'
           END;
END
ELSE
    INSERT INTO #Checklist ([بررسی], [مقدار], [Status], [توضیح])
    VALUES (N'sp_configure — filestream access level', N'بررسی نشد', N'WARN',
            N'مجوز VIEW SERVER STATE برای خواندن sys.configurations وجود ندارد — DBA با sp_configure مقدار را کنترل کند.');

/* ---------- ۵) پشتیبانی ویرایش SQL Server ---------- */
DECLARE @Edition NVARCHAR(128) = CONVERT(NVARCHAR(128), SERVERPROPERTY('Edition'));

INSERT INTO #Checklist ([بررسی], [مقدار], [Status], [توضیح])
SELECT N'پشتیبانی ویرایش از FILESTREAM', @Edition,
       CASE WHEN @Edition LIKE N'%Standard%' OR @Edition LIKE N'%Enterprise%'
              OR @Edition LIKE N'%Developer%' OR @Edition LIKE N'%Web%'
              OR @Edition LIKE N'%Express%' THEN N'PASS'
            ELSE N'WARN' END,
       CASE
            WHEN @Edition LIKE N'%Standard%' THEN N'ویرایش استاندارد (پیش‌نیاز طراحی) از FILESTREAM کامل پشتیبانی می‌کند.'
            WHEN @Edition LIKE N'%Enterprise%' OR @Edition LIKE N'%Developer%' THEN N'این ویرایش از FILESTREAM پشتیبانی می‌کند (برای محیط عملیاتی، مجوز ویرایش استاندارد لازم است).'
            WHEN @Edition LIKE N'%Express%' THEN N'ویرایش Express از FILESTREAM پشتیبانی می‌کند اما سقف حجم پایگاه‌داده ۱۰ گیگابایت است — فقط برای آزمایش‌های کوچک مناسب است.'
            WHEN @Edition LIKE N'%Web%' THEN N'ویرایش Web از FILESTREAM پشتیبانی می‌کند.'
            ELSE N'ویرایش شناسایی نشد — پشتیبانی FILESTREAM باید دستی کنترل شود.'
       END;

/* ---------- ۶) وجود فایل‌گروپ FILESTREAM در پایگاه‌داده جاری ---------- */
DECLARE @FgCount INT = (SELECT COUNT(*) FROM sys.filegroups WHERE type = N'FD');
DECLARE @FgNames NVARCHAR(400) = (SELECT STRING_AGG(name, N', ') FROM sys.filegroups WHERE type = N'FD');

INSERT INTO #Checklist ([بررسی], [مقدار], [Status], [توضیح])
SELECT N'فایل‌گروپ FILESTREAM در پایگاه‌داده جاری',
       CASE WHEN @FgCount > 0 THEN @FgNames ELSE N'موجود نیست' END,
       CASE WHEN @FgCount > 0 THEN N'PASS' ELSE N'WARN' END,
       CASE WHEN @FgCount > 0
            THEN N'فایل‌گروپ FILESTREAM موجود است؛ اسکریپت ۰۲ فقط در صورت غیبت آن را می‌سازد.'
            ELSE N'هنوز فایل‌گروپ FILESTREAM ساخته نشده — طبیعی است؛ اسکریپت ۰۲ آن را ایجاد می‌کند (به شرط PASS شدن ردیف‌های بالا).' END;

/* ---------- ۷) فضای آزاد ولوم‌های میزبان فایل‌های پایگاه‌داده ---------- */
IF HAS_PERMS_BY_NAME(NULL, NULL, 'VIEW SERVER STATE') = 1
BEGIN
    INSERT INTO #Checklist ([بررسی], [مقدار], [Status], [توضیح])
    SELECT N'فضای آزاد ولوم میزبان فایل‌ها: ' + v.volume_mount_point,
           CAST(v.available_bytes / 1073741824.0 AS DECIMAL(12,1)) AS FreeGB, -- گیگابایت آزاد
           CASE WHEN v.available_bytes >= 10737418240 THEN N'PASS'
                WHEN v.available_bytes >= 1073741824  THEN N'WARN'
                ELSE N'FAIL' END,
           CASE WHEN v.available_bytes >= 10737418240
                THEN N'فضای آزاد کافی است (توصیه: حداقل ۱۰ گیگابایت برای محیط آزمایشی).'
                WHEN v.available_bytes >= 1073741824
                THEN N'فضای آزاد کم است — قبل از استقرار، پاک‌سازی یا افزودن دیسک را برنامه‌ریزی کنید.'
                ELSE N'فضای بحرانی — ادامه استقرار ممنوع است (معیار توقف در Runbook).' END
    FROM (SELECT DISTINCT vs.volume_mount_point, vs.available_bytes
          FROM sys.master_files AS mf
          CROSS APPLY sys.dm_os_volume_stats(mf.database_id, mf.file_id) AS vs
          WHERE mf.database_id = DB_ID() AND mf.type IN (0, 2)) AS v;  -- فایل‌های داده (ROWS) و FILESTREAM
END
ELSE
    INSERT INTO #Checklist ([بررسی], [مقدار], [Status], [توضیح])
    VALUES (N'فضای آزاد ولوم‌ها', N'بررسی نشد', N'WARN',
            N'مجوز VIEW SERVER STATE برای sys.dm_os_volume_stats وجود ندارد — فضای دیسک توسط IT به‌صورت دستی کنترل شود.');

/* ---------- نتیجه نهایی ---------- */
DECLARE @FailCount INT = (SELECT COUNT(*) FROM #Checklist WHERE [Status] = N'FAIL');
DECLARE @WarnCount INT = (SELECT COUNT(*) FROM #Checklist WHERE [Status] = N'WARN');

INSERT INTO #Checklist ([بررسی], [مقدار], [Status], [توضیح])
SELECT N'جمع‌بندی',
       CAST((SELECT COUNT(*) FROM #Checklist) AS NVARCHAR(10)) + N' بررسی انجام شد',
       CASE WHEN @FailCount = 0 THEN N'PASS' ELSE N'FAIL' END,
       CASE WHEN @FailCount = 0
            THEN N'هیچ ردیف FAIL وجود ندارد (تعداد WARN: ' + CAST(@WarnCount AS NVARCHAR(10)) + N') — می‌توان به اسکریپت ۰۲ رفت.'
            ELSE N'تعداد FAIL: ' + CAST(@FailCount AS NVARCHAR(10)) + N' — پیش از اجرای اسکریپت ۰۲ باید ردیف(های) FAIL برطرف شود (اصلاح FILESTREAM صرفاً دستی و توسط IT/DBA انجام می‌شود).' END;

SELECT [بررسی], [مقدار], [Status], [توضیح] FROM #Checklist ORDER BY Id;

DROP TABLE #Checklist;

PRINT N'=== اسکریپت ۰۱ پایان یافت — فقط‌خواندنی؛ هیچ تغییری اعمال نشد. ===';
IF @Effective = 0
BEGIN
    PRINT N'*******************************************************************';
    PRINT N'FAIL: FILESTREAM در سطح نمونه فعال نیست (FilestreamEffectiveLevel = 0).';
    PRINT N'راهنمای اصلاح دستی (بدون اصلاح خودکار):';
    PRINT N'  ۱) SQL Server Configuration Manager → SQL Server Services → Properties → تب FILESTREAM →';
    PRINT N'     تیک Enable FILESTREAM for Transact-SQL access (و در صورت نیاز Enable FILESTREAM for file I/O streaming access).';
    PRINT N'  ۲) اجرای: EXEC sp_configure N''filestream access level'', 2; RECONFIGURE;';
    PRINT N'  ۳) ری‌استارت سرویس SQL Server (مثلاً با net stop MSSQLSERVER و net start MSSQLSERVER یا از خود Configuration Manager).';
    PRINT N'  ۴) اجرای مجدد همین اسکریپت ۰۱ تا دریافت PASS، سپس اسکریپت ۰۲.';
    PRINT N'*******************************************************************';
END
ELSE
    PRINT N'گام بعدی: پشتیبان کامل + اجرای 02-Create-Attachment-Structure.sql';