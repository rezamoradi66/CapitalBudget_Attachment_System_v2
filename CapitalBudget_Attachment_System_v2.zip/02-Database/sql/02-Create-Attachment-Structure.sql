/* =====================================================================
   اسکریپت ۰۲ — ساخت ساختار پیوست‌ها (اسکریپت اصلی ساخت / BUILD)
   پروژه: سامانه مدیریت بودجه سرمایه‌ای (Capital Budget Management System)
   ماژول: مدیریت پیوست‌ها — سند طراحی ۰۳ نسخه ۶ (تصمیم‌های D-08/D-10/D-21)
   ---------------------------------------------------------------------
   هدف:
     ساخت کامل و «امن در اجرای مکرر» ساختار ذخیره‌سازی پیوست‌ها:
       (a) فایل‌گروپ FILESTREAM ($(FGName)) و فایل کانتینر $(FSPath)\AttachmentsFSData
       (b) جدول dbo.RequestAttachments (در صورت غیبت) یا تکمیل ستون‌های غایب آن
       (c) ایندکس‌های Owner/Request/Micro/UploadedAt
       (d) کلیدهای خارجی به dbo.Users / dbo.Requests / dbo.RequestMicros (فقط در صورت وجود جدول پایه)
       (e) قیدهای CHECK (OwnerType، سقف حجم، وضعیت، دقیقاً-یک-مالک)
   ---------------------------------------------------------------------
   الزامات اجرا:
     * SSMS: منوی Query → گزینه SQLCMD Mode باید «فعال» باشد (به دلیل
       دستورهای :setvar و متغیرهای $(FSPath) و ...). بدون SQLCMD Mode اجرا نکنید.
       sqlcmd:  sqlcmd -S <Server> -d CapitalBudgetManagement_Lab -E -f 65001 -i "02-Create-Attachment-Structure.sql"
       (تغییر پارامترها: خطوط :setvar پایین فایل را ویرایش کنید.)
     * دسترسی لازم: sysadmin یا db_owner به‌همراه مجوز ALTER DATABASE.
     * پیش‌نیاز: FILESTREAM باید در سطح نمونه فعال باشد — ابتدا اسکریپت ۰۱ را
       اجرا کنید؛ در صورت FAIL، اصلاح «فقط دستی» است (راهنما در خروجی ۰۱).
   ---------------------------------------------------------------------
   متغیرهای sqlcmd (پیش‌فرض):
     $(FSPath)   = D:\CBM\FS       پوشه «والد» کانتینر FILESTREAM (بدون backslash انتهایی) — باید از قبل وجود داشته باشد؛
                                   خود SQL Server پوشه کانتینر را می‌سازد.
     $(FSSizeMB) = 1024            حجم مطلوب به مگابایت — «اطلاع‌رسانی/سندبندی» است؛ برای فایل‌های FILESTREAM
                                   تعیین SIZE/FILEGROWTH اعمال نمی‌شود و رشد کانتینر پویاست (برای سهمیه‌بندی، Quota
                                   سطح NTFS توصیه می‌شود).
     $(FGName)   = AttachmentsFS   نام فایل‌گروپ FILESTREAM
   ---------------------------------------------------------------------
   نکات ایمنی و ممیزی:
     * Idempotent: اجرای مکرر امن است؛ هر گام با IF NOT EXISTS گارد شده است.
     * هیچ داده‌ای حذف یا بازنویسی نمی‌شود؛ فقط ساختار «اضافه/تکمیل» می‌شود.
     * هیچ تراکنش صریحی (BEGIN TRAN) وجود ندارد؛ DDL فایل‌گروپ باید بیرون
       تراکنش صریح اجرا شود — ایمنی از طریق گاردها تضمین شده است.
     * تبدیل خودکار ستون قدیمی Content (VARBINARY معمولی) به FILESTREAM
       «انجام نمی‌شود» — در صورت وجود چنین ستونی، فقط هشدار چاپ می‌شود و
       مهاجرت داده باید با اسکریپت جداگانه و زیر نظر DBA انجام شود.
     * در صورت ساخت جدول از طریق همین اسکریپت، یک Extended Property
       (CreatedByScript) ثبت می‌شود تا اسکریپت Rollback (99) بتواند
       «جدول ساخته‌شده توسط اسکریپت» را از «جدول از قبل موجود» تشخیص دهد.
   ===================================================================== */

:setvar FSPath "D:\CBM\FS"
:setvar FSSizeMB "1024"
:setvar FGName "AttachmentsFS"
:on error exit

/* ================== گام ۰: پیش‌بررسی‌های ایست ================== */
SET NOCOUNT ON;

PRINT N'=== اسکریپت ۰۲: ساخت ساختار پیوست‌ها — شروع ===';
PRINT N'پایگاه‌داده جاری: ' + DB_NAME() + N' | سرور: ' + @@SERVERNAME;
PRINT N'پارامترها → مسیر: $(FSPath) | نام فایل‌گروپ: $(FGName) | حجم اطلاع‌رسانی: $(FSSizeMB) مگابایت';
PRINT N'یادآوری: این اسکریپت هیچ داده‌ای را حذف نمی‌کند و در محیط آزمایشی (CapitalBudgetManagement_Lab) طراحی شده است.';

IF DB_NAME() IN (N'master', N'model', N'msdb', N'tempdb')
BEGIN
    PRINT N'FAIL: در یک پایگاه‌داده سیستمی هستید؛ اجرا متوقف شد.';
    RETURN;
END

/* پیش‌نیاز سخت: فعال بودن FILESTREAM در سطح نمونه */
IF CAST(SERVERPROPERTY('FilestreamEffectiveLevel') AS INT) = 0
BEGIN
    PRINT N'FAIL: FILESTREAM در سطح نمونه فعال نیست (FilestreamEffectiveLevel = 0).';
    PRINT N'مرحله لازم (بدون اصلاح خودکار):';
    PRINT N'  ۱) SQL Server Configuration Manager → SQL Server Services → Properties → تب FILESTREAM → فعال‌سازی دسترسی T-SQL (و در صورت نیاز Win32).';
    PRINT N'  ۲) اجرای: EXEC sp_configure N''filestream access level'', 2; RECONFIGURE;';
    PRINT N'  ۳) ری‌استارت سرویس SQL Server.';
    PRINT N'  ۴) اجرای مجدد اسکریپت ۰۱ (تا PASS) و سپس این اسکریپت.';
    PRINT N'هیچ تغییری اعمال نشد — اجرا متوقف شد.';
    SET NOEXEC ON;   /* تمام دسته‌های (Batch) بعدی نیز اجرا نخواهند شد */
    RETURN;
END

/* اگر شیئی غیر از جدول با همین نام وجود دارد، ساخت جدول ناممکن است */
IF OBJECT_ID(N'dbo.RequestAttachments') IS NOT NULL AND OBJECT_ID(N'dbo.RequestAttachments', N'U') IS NULL
BEGIN
    PRINT N'FAIL: شیئی غیر از جدول با نام dbo.RequestAttachments موجود است (View/Procedure/...)؛ ساخت جدول ناممکن است — ابتدا آن شیء را با هماهنگی DBA حذف/تغییرنام دهید.';
    SET NOEXEC ON;
    RETURN;
END
GO

/* ================== گام ۱: فایل‌گروپ FILESTREAM و فایل کانتینر ================== */
IF CAST(SERVERPROPERTY('FilestreamEffectiveLevel') AS INT) = 0 RETURN;  /* گارد ایمنی دسته‌های بعدی */

BEGIN TRY
    IF NOT EXISTS (SELECT 1 FROM sys.filegroups WHERE name = N'$(FGName)' AND type = N'FD')
    BEGIN
        PRINT N'ایجاد فایل‌گروپ FILESTREAM با نام [$(FGName)] ...';
        ALTER DATABASE CURRENT ADD FILEGROUP [$(FGName)] CONTAINS FILESTREAM;
        PRINT N'OK: فایل‌گروپ [$(FGName)] ساخته شد.';
    END
    ELSE
        PRINT N'اطلاع: فایل‌گروپ [$(FGName)] از قبل موجود است — تغییر داده نشد.';

    IF NOT EXISTS (SELECT 1 FROM sys.database_files WHERE name = N'AttachmentsFSData')
    BEGIN
        PRINT N'افزودن فایل کانتینر FILESTREAM «AttachmentsFSData» در مسیر $(FSPath)\AttachmentsFSData ...';
        PRINT N'یادآوری: پوشه والد $(FSPath) باید از قبل وجود داشته باشد؛ پوشه کانتینر را خود SQL Server می‌سازد. (حجم اطلاع‌رسانی: $(FSSizeMB) مگابایت — برای فایل FILESTREAM اعمال SIZE/FILEGROWTH موضوعیت ندارد.)';
        ALTER DATABASE CURRENT
            ADD FILE (NAME = N'AttachmentsFSData', FILENAME = N'$(FSPath)\AttachmentsFSData')
            TO FILEGROUP [$(FGName)];
        PRINT N'OK: فایل کانتینر FILESTREAM اضافه شد.';
    END
    ELSE
        PRINT N'اطلاع: فایل AttachmentsFSData از قبل موجود است — تغییر داده نشد.';
END TRY
BEGIN CATCH
    PRINT N'FAIL: ایجاد فایل‌گروپ/فایل FILESTREAM ناموفق بود: ' + ERROR_MESSAGE();
    PRINT N'بررسی کنید: ۱) فعال بودن FILESTREAM در سطح نمونه (اسکریپت ۰۱)؛ ۲) وجود پوشه والد $(FSPath) روی دیسک؛ ۳) مجوز ALTER DATABASE.';
    PRINT N'هیچ گام بعدی اجرا نمی‌شود؛ پس از رفع مشکل، همین اسکریپت را دوباره اجرا کنید (Idempotent است).';
    SET NOEXEC ON;
    RETURN;
END CATCH
GO

/* ================== گام ۲: جدول dbo.RequestAttachments ================== */
IF CAST(SERVERPROPERTY('FilestreamEffectiveLevel') AS INT) = 0 RETURN;

IF NOT EXISTS (SELECT 1 FROM sys.filegroups WHERE name = N'$(FGName)' AND type = N'FD')
BEGIN
    PRINT N'FAIL: فایل‌گروپ FILESTREAM آماده نیست — ساخت جدول متوقف شد (گام ۱ را بررسی کنید).';
    RETURN;
END

IF OBJECT_ID(N'dbo.RequestAttachments', N'U') IS NULL
BEGIN
    BEGIN TRY
        PRINT N'ایجاد جدول dbo.RequestAttachments با ساختار کامل مصوب (سند ۰۳ نسخه ۶) ...';

        CREATE TABLE dbo.RequestAttachments
        (
            Id            BIGINT IDENTITY(1,1) NOT NULL
                          CONSTRAINT PK_Attachments PRIMARY KEY,                       -- شناسه یکتا (خوشه‌ای)
            OwnerType     TINYINT       NOT NULL,                                      -- 1=درخواست/برنامه، 2=خرده‌ریز/ردیف بودجه (D-08)
            OwnerId       BIGINT        NOT NULL,                                      -- شناسه مالک مطابق OwnerType
            RequestId     BIGINT        NULL,                                          -- FK به dbo.Requests (فقط یکی از RequestId/MicroId)
            MicroId       BIGINT        NULL,                                          -- FK به dbo.RequestMicros
            OriginalName  NVARCHAR(260) NOT NULL,                                      -- نام اصلی فایل سمت کاربر
            DisplayName   NVARCHAR(260) NULL,                                          -- عنوان نمایشی اختیاری
            Extension     NVARCHAR(10)  NULL,                                          -- پسوند نرمال‌شده (مثل .pdf)
            ContentType   NVARCHAR(100) NOT NULL,                                      -- MIME type
            SizeBytes     INT           NOT NULL,                                      -- حجم فایل (سقف ۱,۰۴۸,۵۷۶ بایت — D-10)
            Sha256        CHAR(64)      NOT NULL,                                      -- هش محتوا برای صحه‌گذاری بازیابی/یکپارچگی
            Status        NVARCHAR(20)  NOT NULL
                          CONSTRAINT DF_Attachments_Status    DEFAULT (N'active'),     -- active | quarantined
            UploadedById  BIGINT        NOT NULL,                                      -- کاربر بارگذارنده (ممیزی)
            UploadedAt    DATETIME2     NOT NULL
                          CONSTRAINT DF_Attachments_UploadedAt DEFAULT (SYSUTCDATETIME()),  -- زمان بارگذاری (UTC — D-18)
            UploadedAtJ   CHAR(10)      NULL,                                          -- تاریخ شمسی YYYY/MM/DD (تولیدی در همان تراکنش — D-04)
            UploadedTimeJ CHAR(5)       NULL,                                          -- ساعت شمسی HH:MM
            FileGuid      UNIQUEIDENTIFIER NOT NULL ROWGUIDCOL
                          CONSTRAINT DF_Attachments_FileGuid  DEFAULT (NEWSEQUENTIALID())
                          CONSTRAINT UX_Attachments_FileGuid  UNIQUE,                  -- الزامی برای FILESTREAM؛ Sequential برای کاهش تکه‌تکه‌شدگی
            FileContent   VARBINARY(MAX) FILESTREAM NOT NULL                          -- محتوای باینری در کانتینر NTFS (D-21)
        ) FILESTREAM_ON [$(FGName)];

        /* نشانگر ممیزی: جدول توسط این اسکریپت ساخته شده است (برای تشخیص در اسکریپت Rollback 99) */
        EXEC sys.sp_addextendedproperty
             @name = N'CreatedByScript', @value = N'02-Create-Attachment-Structure',
             @level0type = N'SCHEMA', @level0name = N'dbo',
             @level1type = N'TABLE',  @level1name = N'RequestAttachments';

        PRINT N'OK: جدول dbo.RequestAttachments ساخته شد.';
    END TRY
    BEGIN CATCH
        PRINT N'FAIL: ایجاد جدول dbo.RequestAttachments ناموفق بود: ' + ERROR_MESSAGE();
        PRINT N'پس از رفع مشکل، همین اسکریپت را دوباره اجرا کنید.';
        SET NOEXEC ON;
        RETURN;
    END CATCH
END
ELSE
    PRINT N'اطلاع: جدول dbo.RequestAttachments از قبل موجود است — هیچ ساختاری بازنویسی نمی‌شود؛ فقط ستون‌های غایب در گام بعدی تکمیل می‌شوند.';
GO

/* ================== گام ۳: تکمیل ستون‌های غایب روی جدول موجود (مسیر مهاجرت) ================== */
IF OBJECT_ID(N'dbo.RequestAttachments', N'U') IS NULL RETURN;

DECLARE @Tid      INT = OBJECT_ID(N'dbo.RequestAttachments', N'U');
DECLARE @HasRows  BIT = CASE WHEN EXISTS (SELECT 1 FROM sys.partitions
                                          WHERE object_id = @Tid AND index_id IN (0, 1) AND rows > 0)
                             THEN 1 ELSE 0 END;
DECLARE @ColsAdded INT = 0;

IF @HasRows = 1
    PRINT N'هشدار: جدول موجود دارای ردیف است؛ ستون‌های NOT NULL افزوده‌شده با مقدار پیش‌فرض پر می‌شوند — بازبینی داده‌ها پس از اجرا توصیه می‌شود.';

/* --- ستون‌های هسته (در صورت غیبت؛ هرکدام در گارد مستقل) --- */
IF NOT EXISTS (SELECT 1 FROM sys.columns WHERE object_id = @Tid AND name = N'OwnerType')
BEGIN
    ALTER TABLE dbo.RequestAttachments ADD OwnerType TINYINT NOT NULL CONSTRAINT DF_Attachments_OwnerType_Mig DEFAULT (1);
    SET @ColsAdded += 1;
END
IF NOT EXISTS (SELECT 1 FROM sys.columns WHERE object_id = @Tid AND name = N'OwnerId')
BEGIN
    ALTER TABLE dbo.RequestAttachments ADD OwnerId BIGINT NOT NULL CONSTRAINT DF_Attachments_OwnerId_Mig DEFAULT (0);
    SET @ColsAdded += 1;
END
IF NOT EXISTS (SELECT 1 FROM sys.columns WHERE object_id = @Tid AND name = N'RequestId')
BEGIN
    ALTER TABLE dbo.RequestAttachments ADD RequestId BIGINT NULL;
    SET @ColsAdded += 1;
END
IF NOT EXISTS (SELECT 1 FROM sys.columns WHERE object_id = @Tid AND name = N'MicroId')
BEGIN
    ALTER TABLE dbo.RequestAttachments ADD MicroId BIGINT NULL;
    SET @ColsAdded += 1;
END
IF NOT EXISTS (SELECT 1 FROM sys.columns WHERE object_id = @Tid AND name = N'OriginalName')
BEGIN
    ALTER TABLE dbo.RequestAttachments ADD OriginalName NVARCHAR(260) NOT NULL CONSTRAINT DF_Attachments_OriginalName_Mig DEFAULT (N'');
    SET @ColsAdded += 1;
END
IF NOT EXISTS (SELECT 1 FROM sys.columns WHERE object_id = @Tid AND name = N'DisplayName')
BEGIN
    ALTER TABLE dbo.RequestAttachments ADD DisplayName NVARCHAR(260) NULL;
    SET @ColsAdded += 1;
END
IF NOT EXISTS (SELECT 1 FROM sys.columns WHERE object_id = @Tid AND name = N'Extension')
BEGIN
    ALTER TABLE dbo.RequestAttachments ADD Extension NVARCHAR(10) NULL;
    SET @ColsAdded += 1;
END
IF NOT EXISTS (SELECT 1 FROM sys.columns WHERE object_id = @Tid AND name = N'ContentType')
BEGIN
    ALTER TABLE dbo.RequestAttachments ADD ContentType NVARCHAR(100) NOT NULL CONSTRAINT DF_Attachments_ContentType_Mig DEFAULT (N'application/octet-stream');
    SET @ColsAdded += 1;
END
IF NOT EXISTS (SELECT 1 FROM sys.columns WHERE object_id = @Tid AND name = N'SizeBytes')
BEGIN
    ALTER TABLE dbo.RequestAttachments ADD SizeBytes INT NOT NULL CONSTRAINT DF_Attachments_SizeBytes_Mig DEFAULT (1);
    SET @ColsAdded += 1;
END
IF NOT EXISTS (SELECT 1 FROM sys.columns WHERE object_id = @Tid AND name = N'Sha256')
BEGIN
    ALTER TABLE dbo.RequestAttachments ADD Sha256 CHAR(64) NOT NULL CONSTRAINT DF_Attachments_Sha256_Mig DEFAULT (REPLICATE('0', 64));
    SET @ColsAdded += 1;
END
IF NOT EXISTS (SELECT 1 FROM sys.columns WHERE object_id = @Tid AND name = N'Status')
BEGIN
    ALTER TABLE dbo.RequestAttachments ADD Status NVARCHAR(20) NOT NULL CONSTRAINT DF_Attachments_Status DEFAULT (N'active');
    SET @ColsAdded += 1;
END
IF NOT EXISTS (SELECT 1 FROM sys.columns WHERE object_id = @Tid AND name = N'UploadedById')
BEGIN
    ALTER TABLE dbo.RequestAttachments ADD UploadedById BIGINT NOT NULL CONSTRAINT DF_Attachments_UploadedById_Mig DEFAULT (0);
    SET @ColsAdded += 1;
END
IF NOT EXISTS (SELECT 1 FROM sys.columns WHERE object_id = @Tid AND name = N'UploadedAt')
BEGIN
    ALTER TABLE dbo.RequestAttachments ADD UploadedAt DATETIME2 NOT NULL CONSTRAINT DF_Attachments_UploadedAt DEFAULT (SYSUTCDATETIME());
    SET @ColsAdded += 1;
END
IF NOT EXISTS (SELECT 1 FROM sys.columns WHERE object_id = @Tid AND name = N'UploadedAtJ')
BEGIN
    ALTER TABLE dbo.RequestAttachments ADD UploadedAtJ CHAR(10) NULL;
    SET @ColsAdded += 1;
END
IF NOT EXISTS (SELECT 1 FROM sys.columns WHERE object_id = @Tid AND name = N'UploadedTimeJ')
BEGIN
    ALTER TABLE dbo.RequestAttachments ADD UploadedTimeJ CHAR(5) NULL;
    SET @ColsAdded += 1;
END

/* --- FileGuid (ROWGUIDCOL + UNIQUE) — پیش‌نیاز ستون FILESTREAM؛ باید قبل از FileContent اضافه شود --- */
IF NOT EXISTS (SELECT 1 FROM sys.columns WHERE object_id = @Tid AND name = N'FileGuid')
BEGIN
    BEGIN TRY
        ALTER TABLE dbo.RequestAttachments
            ADD FileGuid UNIQUEIDENTIFIER NOT NULL ROWGUIDCOL
                CONSTRAINT DF_Attachments_FileGuid DEFAULT (NEWSEQUENTIALID())
                CONSTRAINT UX_Attachments_FileGuid UNIQUE;
        SET @ColsAdded += 1;
    END TRY
    BEGIN CATCH
        PRINT N'FAIL: افزودن ستون FileGuid ناموفق بود (احتمالاً ROWGUIDCOL دیگری روی جدول موجود است): ' + ERROR_MESSAGE();
    END CATCH
END

/* --- FileContent (FILESTREAM) — فقط برای جدول خالی؛ در غیر این صورت مهاجرت داده دستی است --- */
IF NOT EXISTS (SELECT 1 FROM sys.columns WHERE object_id = @Tid AND name = N'FileContent')
BEGIN
    IF @HasRows = 1
        PRINT N'هشدار: جدول دارای ردیف است و افزودن ستون NOT NULL از نوع FILESTREAM بدون مهاجرت داده امکان‌پذیر نیست — این گام رد شد (مهاجرت باید با اسکریپت جداگانه زیر نظر DBA انجام شود).';
    ELSE
    BEGIN
        BEGIN TRY
            /* توجه: فایل‌گروپ FILESTREAM جدول باید از قبل روی جدول تعیین شده باشد؛
               اگر جدول قدیمی فایل‌گروپ FILESTREAM ندارد، خطا گرفته می‌شود و راهنما چاپ می‌گردد. */
            ALTER TABLE dbo.RequestAttachments ADD FileContent VARBINARY(MAX) FILESTREAM NOT NULL;
            SET @ColsAdded += 1;
        END TRY
        BEGIN CATCH
            PRINT N'FAIL: افزودن ستون FileContent ناموفق بود: ' + ERROR_MESSAGE();
            PRINT N'احتمال زیاد: جدول موجود فایل‌گروپ FILESTREAM ندارد. با DBA بررسی و پس از هماهنگی، ساختار دستی تکمیل شود.';
        END CATCH
    END
END
ELSE IF EXISTS (SELECT 1 FROM sys.columns WHERE object_id = @Tid AND name = N'FileContent' AND is_filestream = 0)
    PRINT N'هشدار: ستون FileContent موجود از نوع FILESTREAM نیست (is_filestream = 0) — تبدیل VARBINARY معمولی به FILESTREAM خودکار انجام نمی‌شود و نیازمند بازسازی جدول است.';

/* --- هشدار ستون قدیمی Content (تبدیل خودکار VARBINARY انجام نمی‌شود) --- */
IF EXISTS (SELECT 1 FROM sys.columns WHERE object_id = @Tid AND name = N'Content')
BEGIN
    PRINT N'هشدار: ستون قدیمی «Content» (VARBINARY معمولی) در جدول یافت شد.';
    IF @HasRows = 1
        PRINT N'هشدار مهم: ستون Content دارای داده است؛ تبدیل خودکار VARBINARY → FILESTREAM انجام نمی‌شود. مهاجرت داده باید با اسکریپت جداگانه، همراه با محاسبه Sha256 هر فایل، اندازه‌گیری SizeBytes و تأیید نهایی DBA انجام شود.';
END

PRINT N'خلاصه گام ۳: تعداد ستون‌های افزوده‌شده: ' + CAST(@ColsAdded AS NVARCHAR(10));
GO

/* ================== گام ۴: ایندکس‌ها (در صورت غیبت) ================== */
IF OBJECT_ID(N'dbo.RequestAttachments', N'U') IS NULL
BEGIN
    PRINT N'اطلاع: جدول dbo.RequestAttachments وجود ندارد — ساخت ایندکس‌ها رد شد.';
    RETURN;
END

/* توجه: عبارات DDL وابسته به «ستون‌های شاید-غایب» به‌صورت Dynamic SQL اجرا می‌شوند تا
   اگر جدول قدیمی ناقص باشد، خطای Bind زمان کامپایل کل دسته رخ ندهد. */
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id = OBJECT_ID(N'dbo.RequestAttachments', N'U') AND name = N'IX_Attachments_Owner')
BEGIN
    EXEC (N'CREATE NONCLUSTERED INDEX IX_Attachments_Owner ON dbo.RequestAttachments (OwnerType, OwnerId);');
    PRINT N'OK: ایندکس IX_Attachments_Owner ساخته شد.';
END
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id = OBJECT_ID(N'dbo.RequestAttachments', N'U') AND name = N'IX_Attachments_Request')
BEGIN
    EXEC (N'CREATE NONCLUSTERED INDEX IX_Attachments_Request ON dbo.RequestAttachments (RequestId);');
    PRINT N'OK: ایندکس IX_Attachments_Request ساخته شد.';
END
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id = OBJECT_ID(N'dbo.RequestAttachments', N'U') AND name = N'IX_Attachments_Micro')
BEGIN
    EXEC (N'CREATE NONCLUSTERED INDEX IX_Attachments_Micro ON dbo.RequestAttachments (MicroId);');
    PRINT N'OK: ایندکس IX_Attachments_Micro ساخته شد.';
END
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id = OBJECT_ID(N'dbo.RequestAttachments', N'U') AND name = N'IX_Attachments_UploadedAt')
BEGIN
    EXEC (N'CREATE NONCLUSTERED INDEX IX_Attachments_UploadedAt ON dbo.RequestAttachments (UploadedAt);');
    PRINT N'OK: ایندکس IX_Attachments_UploadedAt ساخته شد.';
END
GO

/* ================== گام ۵: کلیدهای خارجی (فقط در صورت وجود جدول پایه) ================== */
IF OBJECT_ID(N'dbo.RequestAttachments', N'U') IS NULL
BEGIN
    PRINT N'اطلاع: جدول dbo.RequestAttachments وجود ندارد — ساخت FKها رد شد.';
    RETURN;
END

/* --- FK_Attachments_Request → dbo.Requests --- */
IF OBJECT_ID(N'dbo.Requests', N'U') IS NULL
    PRINT N'اطلاع: جدول dbo.Requests موجود نیست — FK_Attachments_Request ساخته نشد (پس از ساخت جدول پایه، همین اسکریپت را دوباره اجرا کنید).';
ELSE IF NOT EXISTS (SELECT 1 FROM sys.columns WHERE object_id = OBJECT_ID(N'dbo.RequestAttachments', N'U') AND name = N'RequestId')
    PRINT N'اطلاع: ستون RequestId موجود نیست — FK_Attachments_Request ساخته نشد.';
ELSE IF NOT EXISTS (SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_Attachments_Request')
BEGIN
    BEGIN TRY
        EXEC (N'ALTER TABLE dbo.RequestAttachments ADD CONSTRAINT FK_Attachments_Request FOREIGN KEY (RequestId) REFERENCES dbo.Requests (Id);');
        PRINT N'OK: قید FK_Attachments_Request اضافه شد.';
    END TRY
    BEGIN CATCH
        PRINT N'FAIL: افزودن FK_Attachments_Request ناموفق بود (ممکن است داده‌های موجود قید را نقض کنند): ' + ERROR_MESSAGE();
    END CATCH
END
ELSE
    PRINT N'اطلاع: FK_Attachments_Request از قبل موجود است.';

/* --- FK_Attachments_Micro → dbo.RequestMicros --- */
IF OBJECT_ID(N'dbo.RequestMicros', N'U') IS NULL
    PRINT N'اطلاع: جدول dbo.RequestMicros موجود نیست — FK_Attachments_Micro ساخته نشد (پس از ساخت جدول پایه، همین اسکریپت را دوباره اجرا کنید).';
ELSE IF NOT EXISTS (SELECT 1 FROM sys.columns WHERE object_id = OBJECT_ID(N'dbo.RequestAttachments', N'U') AND name = N'MicroId')
    PRINT N'اطلاع: ستون MicroId موجود نیست — FK_Attachments_Micro ساخته نشد.';
ELSE IF NOT EXISTS (SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_Attachments_Micro')
BEGIN
    BEGIN TRY
        EXEC (N'ALTER TABLE dbo.RequestAttachments ADD CONSTRAINT FK_Attachments_Micro FOREIGN KEY (MicroId) REFERENCES dbo.RequestMicros (Id);');
        PRINT N'OK: قید FK_Attachments_Micro اضافه شد.';
    END TRY
    BEGIN CATCH
        PRINT N'FAIL: افزودن FK_Attachments_Micro ناموفق بود (ممکن است داده‌های موجود قید را نقض کنند): ' + ERROR_MESSAGE();
    END CATCH
END
ELSE
    PRINT N'اطلاع: FK_Attachments_Micro از قبل موجود است.';

/* --- FK_Attachments_UploadedBy → dbo.Users --- */
IF OBJECT_ID(N'dbo.Users', N'U') IS NULL
    PRINT N'اطلاع: جدول dbo.Users موجود نیست — FK_Attachments_UploadedBy ساخته نشد (در محیط آزمایشی ابتدا اسکریپت ۰۵ را اجرا کنید).';
ELSE IF NOT EXISTS (SELECT 1 FROM sys.columns WHERE object_id = OBJECT_ID(N'dbo.RequestAttachments', N'U') AND name = N'UploadedById')
    PRINT N'اطلاع: ستون UploadedById موجود نیست — FK_Attachments_UploadedBy ساخته نشد.';
ELSE IF NOT EXISTS (SELECT 1 FROM sys.foreign_keys WHERE name = N'FK_Attachments_UploadedBy')
BEGIN
    BEGIN TRY
        EXEC (N'ALTER TABLE dbo.RequestAttachments ADD CONSTRAINT FK_Attachments_UploadedBy FOREIGN KEY (UploadedById) REFERENCES dbo.Users (Id);');
        PRINT N'OK: قید FK_Attachments_UploadedBy اضافه شد.';
    END TRY
    BEGIN CATCH
        PRINT N'FAIL: افزودن FK_Attachments_UploadedBy ناموفق بود (ممکن است داده‌های موجود قید را نقض کنند): ' + ERROR_MESSAGE();
    END CATCH
END
ELSE
    PRINT N'اطلاع: FK_Attachments_UploadedBy از قبل موجود است.';
GO

/* ================== گام ۶: قیدهای CHECK (در صورت غیبت) ================== */
IF OBJECT_ID(N'dbo.RequestAttachments', N'U') IS NULL
BEGIN
    PRINT N'اطلاع: جدول dbo.RequestAttachments وجود ندارد — ساخت قیدهای CHECK رد شد.';
    RETURN;
END

/* --- CK_Attachments_OwnerType: فقط ۱ یا ۲ --- */
IF NOT EXISTS (SELECT 1 FROM sys.check_constraints WHERE name = N'CK_Attachments_OwnerType')
   AND EXISTS (SELECT 1 FROM sys.columns WHERE object_id = OBJECT_ID(N'dbo.RequestAttachments', N'U') AND name = N'OwnerType')
BEGIN
    BEGIN TRY
        EXEC (N'ALTER TABLE dbo.RequestAttachments ADD CONSTRAINT CK_Attachments_OwnerType CHECK (OwnerType IN (1, 2));');
        PRINT N'OK: قید CK_Attachments_OwnerType اضافه شد.';
    END TRY
    BEGIN CATCH
        PRINT N'FAIL: افزودن CK_Attachments_OwnerType ناموفق بود (داده‌های موجود ممکن است نقض کنند): ' + ERROR_MESSAGE();
    END CATCH
END

/* --- CK_Attachments_Size: سقف ۱,۰۴۸,۵۷۶ بایت (D-10) --- */
IF NOT EXISTS (SELECT 1 FROM sys.check_constraints WHERE name = N'CK_Attachments_Size')
   AND EXISTS (SELECT 1 FROM sys.columns WHERE object_id = OBJECT_ID(N'dbo.RequestAttachments', N'U') AND name = N'SizeBytes')
BEGIN
    BEGIN TRY
        EXEC (N'ALTER TABLE dbo.RequestAttachments ADD CONSTRAINT CK_Attachments_Size CHECK (SizeBytes BETWEEN 1 AND 1048576);');
        PRINT N'OK: قید CK_Attachments_Size اضافه شد.';
    END TRY
    BEGIN CATCH
        PRINT N'FAIL: افزودن CK_Attachments_Size ناموفق بود (داده‌های موجود ممکن است نقض کنند): ' + ERROR_MESSAGE();
    END CATCH
END

/* --- CK_Attachments_Status: فقط active یا quarantined --- */
IF NOT EXISTS (SELECT 1 FROM sys.check_constraints WHERE name = N'CK_Attachments_Status')
   AND EXISTS (SELECT 1 FROM sys.columns WHERE object_id = OBJECT_ID(N'dbo.RequestAttachments', N'U') AND name = N'Status')
BEGIN
    BEGIN TRY
        EXEC (N'ALTER TABLE dbo.RequestAttachments ADD CONSTRAINT CK_Attachments_Status CHECK (Status IN (N''active'', N''quarantined''));');
        PRINT N'OK: قید CK_Attachments_Status اضافه شد.';
    END TRY
    BEGIN CATCH
        PRINT N'FAIL: افزودن CK_Attachments_Status ناموفق بود (داده‌های موجود ممکن است نقض کنند): ' + ERROR_MESSAGE();
    END CATCH
END

/* --- CK_Attachments_ExactlyOneOwner: دقیقاً یکی از RequestId/MicroId پر باشد (D-08)
       فقط زمانی که «هر دو ستون» موجود باشند اضافه می‌شود --- */
IF NOT EXISTS (SELECT 1 FROM sys.check_constraints WHERE name = N'CK_Attachments_ExactlyOneOwner')
   AND EXISTS (SELECT 1 FROM sys.columns WHERE object_id = OBJECT_ID(N'dbo.RequestAttachments', N'U') AND name = N'RequestId')
   AND EXISTS (SELECT 1 FROM sys.columns WHERE object_id = OBJECT_ID(N'dbo.RequestAttachments', N'U') AND name = N'MicroId')
BEGIN
    BEGIN TRY
        EXEC (N'ALTER TABLE dbo.RequestAttachments ADD CONSTRAINT CK_Attachments_ExactlyOneOwner CHECK
                 ((CASE WHEN RequestId IS NOT NULL THEN 1 ELSE 0 END) + (CASE WHEN MicroId IS NOT NULL THEN 1 ELSE 0 END) = 1);');
        PRINT N'OK: قید CK_Attachments_ExactlyOneOwner اضافه شد.';
    END TRY
    BEGIN CATCH
        PRINT N'FAIL: افزودن CK_Attachments_ExactlyOneOwner ناموفق بود (داده‌های موجود ممکن است نقض کنند — ردیف‌های بدون مالک یا با دو مالک): ' + ERROR_MESSAGE();
    END CATCH
END
GO

/* ================== گام ۷: خلاصه نهایی ================== */
IF OBJECT_ID(N'dbo.RequestAttachments', N'U') IS NOT NULL
   AND EXISTS (SELECT 1 FROM sys.filegroups WHERE name = N'$(FGName)' AND type = N'FD')
BEGIN
    PRINT N'=== اسکریپت ۰۲ پایان یافت: ساختار پیوست‌ها آماده است. ===';
    PRINT N'گام بعدی: اجرای 03-Verify-Attachment-Structure.sql برای صحه‌گذاری کامل ساختار.';
END
ELSE
BEGIN
    PRINT N'=== اسکریپت ۰۲ با وضعیت ناقص پایان یافت — بخش‌های FAIL بالا را بررسی کنید. ===';
    PRINT N'پس از رفع مشکل، همین اسکریپت را دوباره اجرا کنید (Idempotent است؛ هیچ داده‌ای حذف نمی‌شود).';
END
GO