/* =====================================================================
   اسکریپت ۰۳ — صحه‌گذاری ساختار پیوست‌ها (فقط‌خواندنی / READ-ONLY)
   پروژه: سامانه مدیریت بودجه سرمایه‌ای (Capital Budget Management System)
   ماژول: مدیریت پیوست‌ها — سند طراحی ۰۳ نسخه ۶
   ---------------------------------------------------------------------
   هدف:
     پس از اجرای اسکریپت ۰۲، تک‌تک موارد مورد انتظار (ستون‌ها/نوع‌ها،
     فایل‌گروپ FILESTREAM، ROWGUIDCOL، مشخصه is_filestream، ایندکس‌ها،
     قیدهای CHECK، قید یکتا و پیش‌فرض‌ها، FKهای مشروط) بررسی و در قالب
     ردیف‌های [Item, Expected, Actual, Result(PASS/FAIL), توضیح]
     گزارش می‌شود؛ در پایان یک ردیف «جمع‌بندی» با شمارش PASS/FAIL.
   ---------------------------------------------------------------------
   نکات ایمنی:
     * فقط‌خواندنی — هیچ تغییرشیء/داده‌ای ایجاد نمی‌کند.
     * قابل اجرای مکرر (Idempotent) است.
     * در پایگاه‌داده هدف (آزمایشی: CapitalBudgetManagement_Lab) اجرا شود.
   ===================================================================== */
SET NOCOUNT ON;

IF DB_NAME() IN (N'master', N'model', N'msdb', N'tempdb')
BEGIN
    PRINT N'FAIL: در یک پایگاه‌داده سیستمی هستید. ابتدا با USE به پایگاه‌داده هدف متصل شوید.';
    RETURN;
END

DECLARE @Tid INT = OBJECT_ID(N'dbo.RequestAttachments', N'U');

CREATE TABLE #Verify
(
    Id        INT IDENTITY(1,1) NOT NULL,
    [Item]    NVARCHAR(150) COLLATE DATABASE_DEFAULT NOT NULL,
    [Expected] NVARCHAR(250) COLLATE DATABASE_DEFAULT NOT NULL,
    [Actual]  NVARCHAR(250) COLLATE DATABASE_DEFAULT NULL,
    [Result]  NVARCHAR(10)  COLLATE DATABASE_DEFAULT NOT NULL,
    [توضیح]   NVARCHAR(600) COLLATE DATABASE_DEFAULT NULL
);

/* ---------- ۰) وجود خود جدول ---------- */
IF @Tid IS NOT NULL
    INSERT INTO #Verify ([Item], [Expected], [Actual], [Result], [توضیح])
    VALUES (N'جدول dbo.RequestAttachments', N'موجود (User Table)', N'موجود', N'PASS',
            N'جدول پیوست‌ها یافت شد.');
ELSE
    INSERT INTO #Verify ([Item], [Expected], [Actual], [Result], [توضیح])
    VALUES (N'جدول dbo.RequestAttachments', N'موجود (User Table)', N'غایب', N'FAIL',
            N'جدول وجود ندارد — ابتدا اسکریپت ۰۲ را اجرا کنید. سایر ردیف‌ها نیز FAIL خواهند بود.');

/* ---------- ۱) ستون‌ها و نوع‌ها (مقایسه نوع پایه + طول) ---------- */
WITH ExpectedCols (ColumnName, ExpectedType) AS
(
    SELECT * FROM (VALUES
        (N'Id',            N'bigint'),
        (N'OwnerType',     N'tinyint'),
        (N'OwnerId',       N'bigint'),
        (N'RequestId',     N'bigint'),
        (N'MicroId',       N'bigint'),
        (N'OriginalName',  N'nvarchar'),
        (N'DisplayName',   N'nvarchar'),
        (N'Extension',     N'nvarchar'),
        (N'ContentType',   N'nvarchar'),
        (N'SizeBytes',     N'int'),
        (N'Sha256',        N'char'),
        (N'Status',        N'nvarchar'),
        (N'UploadedById',  N'bigint'),
        (N'UploadedAt',    N'datetime2'),
        (N'UploadedAtJ',   N'char'),
        (N'UploadedTimeJ', N'char'),
        (N'FileGuid',      N'uniqueidentifier'),
        (N'FileContent',   N'varbinary')
    ) AS v (ColumnName, ExpectedType)
)
INSERT INTO #Verify ([Item], [Expected], [Actual], [Result], [توضیح])
SELECT N'ستون: ' + e.ColumnName,
       e.ExpectedType
         + CASE WHEN e.ExpectedType = N'nvarchar' AND e.ColumnName IN (N'OriginalName', N'DisplayName') THEN N'(260)'
                WHEN e.ExpectedType = N'nvarchar' AND e.ColumnName = N'Extension'        THEN N'(10)'
                WHEN e.ExpectedType = N'nvarchar' AND e.ColumnName IN (N'ContentType', N'Status') THEN N'(100/20)'
                WHEN e.ExpectedType = N'char'     AND e.ColumnName = N'Sha256'           THEN N'(64)'
                WHEN e.ExpectedType = N'char'     AND e.ColumnName = N'UploadedAtJ'      THEN N'(10)'
                WHEN e.ExpectedType = N'char'     AND e.ColumnName = N'UploadedTimeJ'    THEN N'(5)'
                WHEN e.ExpectedType = N'varbinary' THEN N'(MAX) FILESTREAM'
                ELSE N'' END,
       ISNULL(TYPE_NAME(c.user_type_id)
         + CASE WHEN TYPE_NAME(c.user_type_id) = N'nvarchar' AND c.max_length > 0 THEN N'(' + CAST(c.max_length / 2 AS NVARCHAR(10)) + N')'
                WHEN TYPE_NAME(c.user_type_id) IN (N'char', N'nchar', N'varchar') AND c.max_length > 0 THEN N'(' + CAST(c.max_length AS NVARCHAR(10)) + N')'
                WHEN TYPE_NAME(c.user_type_id) = N'varbinary' AND c.max_length = -1 THEN N'(MAX)'
                ELSE N'' END
         + CASE WHEN c.is_filestream = 1 THEN N' FILESTREAM' ELSE N'' END,
         N'«غایب»'),
       CASE WHEN c.user_type_id IS NULL THEN N'FAIL' ELSE N'PASS' END,
       CASE WHEN c.user_type_id IS NULL
            THEN N'ستون مورد انتظار در جدول یافت نشد — اسکریپت ۰۲ را اجرا کنید.'
            ELSE N'نوع ستون با طراحی مطابقت دارد.' END
FROM ExpectedCols AS e
LEFT JOIN sys.columns AS c
       ON c.object_id = OBJECT_ID(N'dbo.RequestAttachments', N'U')
      AND c.name = e.ColumnName;

/* ---------- ۲) کلید اصلی و IDENTITY ---------- */
IF EXISTS (SELECT 1
           FROM sys.key_constraints AS kc
           JOIN sys.index_columns AS ic ON ic.object_id = kc.parent_object_id AND ic.index_id = kc.unique_index_id
           JOIN sys.columns AS c ON c.object_id = ic.object_id AND c.column_id = ic.column_id
           WHERE kc.type = N'PK' AND kc.parent_object_id = @Tid AND c.name = N'Id')
    INSERT INTO #Verify ([Item], [Expected], [Actual], [Result], [توضیح])
    VALUES (N'کلید اصلی روی Id', N'PRIMARY KEY (Id)', N'موجود', N'PASS', N'کلید اصلی (خوشه‌ای) روی ستون Id فعال است.');
ELSE
    INSERT INTO #Verify ([Item], [Expected], [Actual], [Result], [توضیح])
    VALUES (N'کلید اصلی روی Id', N'PRIMARY KEY (Id)', N'غایب', N'FAIL', N'کلید اصلی روی Id یافت نشد.');

IF EXISTS (SELECT 1 FROM sys.columns WHERE object_id = @Tid AND name = N'Id' AND is_identity = 1)
    INSERT INTO #Verify ([Item], [Expected], [Actual], [Result], [توضیح])
    VALUES (N'IDENTITY ستون Id', N'is_identity = 1', N'1', N'PASS', N'مقدار افزایشی خودکار فعال است.');
ELSE
    INSERT INTO #Verify ([Item], [Expected], [Actual], [Result], [توضیح])
    VALUES (N'IDENTITY ستون Id', N'is_identity = 1', N'0/غایب', N'FAIL', N'ستون Id یا مشخصه IDENTITY یافت نشد.');

/* ---------- ۳) ROWGUIDCOL و قید یکتای FileGuid ---------- */
IF EXISTS (SELECT 1 FROM sys.columns WHERE object_id = @Tid AND name = N'FileGuid' AND is_rowguidcol = 1)
    INSERT INTO #Verify ([Item], [Expected], [Actual], [Result], [توضیح])
    VALUES (N'ROWGUIDCOL ستون FileGuid', N'is_rowguidcol = 1', N'1', N'PASS', N'پیش‌نیاز FILESTREAM برقرار است.');
ELSE
    INSERT INTO #Verify ([Item], [Expected], [Actual], [Result], [توضیح])
    VALUES (N'ROWGUIDCOL ستون FileGuid', N'is_rowguidcol = 1', N'0/غایب', N'FAIL', N'ROWGUIDCOL روی FileGuid تنظیم نشده است.');

IF EXISTS (SELECT 1 FROM sys.key_constraints WHERE type = N'U' AND name = N'UX_Attachments_FileGuid' AND parent_object_id = @Tid)
    INSERT INTO #Verify ([Item], [Expected], [Actual], [Result], [توضیح])
    VALUES (N'قید یکتای UX_Attachments_FileGuid', N'UNIQUE (FileGuid)', N'موجود', N'PASS', N'الزام یکتایی ROWGUIDCOL برقرار است.');
ELSE
    INSERT INTO #Verify ([Item], [Expected], [Actual], [Result], [توضیح])
    VALUES (N'قید یکتای UX_Attachments_FileGuid', N'UNIQUE (FileGuid)', N'غایب', N'FAIL', N'قید یکتای FileGuid یافت نشد.');

/* ---------- ۴) مشخصه FILESTREAM ستون FileContent ---------- */
IF EXISTS (SELECT 1 FROM sys.columns WHERE object_id = @Tid AND name = N'FileContent' AND is_filestream = 1)
    INSERT INTO #Verify ([Item], [Expected], [Actual], [Result], [توضیح])
    VALUES (N'is_filestream ستون FileContent', N'is_filestream = 1', N'1', N'PASS', N'ستون محتوا واقعاً از نوع FILESTREAM است (D-21).');
ELSE
    INSERT INTO #Verify ([Item], [Expected], [Actual], [Result], [توضیح])
    VALUES (N'is_filestream ستون FileContent', N'is_filestream = 1', N'0/غایب', N'FAIL', N'ستون FileContent FILESTREAM نیست یا وجود ندارد.');

/* ---------- ۵) سطح مؤثر FILESTREAM در نمونه ---------- */
DECLARE @FsLevel INT = CAST(SERVERPROPERTY('FilestreamEffectiveLevel') AS INT);
INSERT INTO #Verify ([Item], [Expected], [Actual], [Result], [توضیح])
SELECT N'سطح مؤثر FILESTREAM (نمونه)', N'> 0', CAST(@FsLevel AS NVARCHAR(10)),
       CASE WHEN @FsLevel > 0 THEN N'PASS' ELSE N'FAIL' END,
       CASE WHEN @FsLevel > 0
            THEN N'FILESTREAM در نمونه فعال است (۰=غیرفعال، ۱=فقط T-SQL، ۲=کامل).'
            ELSE N'FILESTREAM فعال نیست — اصلاح دستی طبق راهنمای اسکریپت ۰۱ لازم است.' END;

/* ---------- ۶) فایل‌گروپ FILESTREAM ---------- */
DECLARE @FgCount INT = (SELECT COUNT(*) FROM sys.filegroups WHERE type = N'FD');
DECLARE @FgNames NVARCHAR(400) = (SELECT STRING_AGG(name, N', ') FROM sys.filegroups WHERE type = N'FD');
INSERT INTO #Verify ([Item], [Expected], [Actual], [Result], [توضیح])
SELECT N'فایل‌گروپ FILESTREAM', N'حداقل یک فایل‌گروپ نوع FD (ترجیحاً AttachmentsFS)',
       CASE WHEN @FgCount > 0 THEN @FgNames ELSE N'غایب' END,
       CASE WHEN @FgCount > 0 THEN N'PASS' ELSE N'FAIL' END,
       CASE WHEN @FgCount > 0
            THEN N'فایل‌گروپ FILESTREAM موجود است (اگر نام آن غیر از AttachmentsFS است، پارامتر $(FGName) اسکریپت ۰۲ را کنترل کنید).'
            ELSE N'هیچ فایل‌گروپ FILESTREAM وجود ندارد — اسکریپت ۰۲ اجرا نشده یا ناموفق بوده است.' END;

DECLARE @FsFileCount INT = (SELECT COUNT(*) FROM sys.database_files WHERE type = 2);
DECLARE @FsFileName NVARCHAR(128) = (SELECT TOP (1) name FROM sys.database_files WHERE type = 2);
DECLARE @FsFileState NVARCHAR(60) = (SELECT TOP (1) state_desc FROM sys.database_files WHERE type = 2);
INSERT INTO #Verify ([Item], [Expected], [Actual], [Result], [توضیح])
SELECT N'فایل کانتینر FILESTREAM', N'فایل type=2 با وضعیت ONLINE',
       CASE WHEN @FsFileCount > 0 THEN @FsFileName + N' (' + @FsFileState + N')' ELSE N'غایب' END,
       CASE WHEN @FsFileCount > 0 AND @FsFileState = N'ONLINE' THEN N'PASS' ELSE N'FAIL' END,
       CASE WHEN @FsFileCount > 0 AND @FsFileState = N'ONLINE'
            THEN N'فایل کانتینر FILESTREAM آنلاین است.'
            ELSE N'فایل کانتینر FILESTREAM یافت نشد یا آنلاین نیست.' END;

/* ---------- ۷) پیش‌فرض‌ها ---------- */
IF EXISTS (SELECT 1 FROM sys.default_constraints WHERE name = N'DF_Attachments_Status' AND parent_object_id = @Tid)
    INSERT INTO #Verify ([Item], [Expected], [Actual], [Result], [توضیح])
    VALUES (N'پیش‌فرض DF_Attachments_Status', N'DEFAULT (''active'')', N'موجود', N'PASS', N'وضعیت پیش‌فرض ردیف فعال است.');
ELSE
    INSERT INTO #Verify ([Item], [Expected], [Actual], [Result], [توضیح])
    VALUES (N'پیش‌فرض DF_Attachments_Status', N'DEFAULT (''active'')', N'غایب', N'FAIL', N'پیش‌فرض Status یافت نشد.');

IF EXISTS (SELECT 1 FROM sys.default_constraints WHERE name = N'DF_Attachments_UploadedAt' AND parent_object_id = @Tid)
    INSERT INTO #Verify ([Item], [Expected], [Actual], [Result], [توضیح])
    VALUES (N'پیش‌فرض DF_Attachments_UploadedAt', N'DEFAULT (SYSUTCDATETIME())', N'موجود', N'PASS', N'زمان بارگذاری خودکار با UTC ثبت می‌شود (D-18).');
ELSE
    INSERT INTO #Verify ([Item], [Expected], [Actual], [Result], [توضیح])
    VALUES (N'پیش‌فرض DF_Attachments_UploadedAt', N'DEFAULT (SYSUTCDATETIME())', N'غایب', N'FAIL', N'پیش‌فرض UploadedAt یافت نشد.');

IF EXISTS (SELECT 1 FROM sys.default_constraints WHERE name = N'DF_Attachments_FileGuid' AND parent_object_id = @Tid)
    INSERT INTO #Verify ([Item], [Expected], [Actual], [Result], [توضیح])
    VALUES (N'پیش‌فرض DF_Attachments_FileGuid', N'DEFAULT (NEWSEQUENTIALID())', N'موجود', N'PASS', N'GUID ترتیبی برای کاهش تکه‌تکه‌شدگی کانتینر.');
ELSE
    INSERT INTO #Verify ([Item], [Expected], [Actual], [Result], [توضیح])
    VALUES (N'پیش‌فرض DF_Attachments_FileGuid', N'DEFAULT (NEWSEQUENTIALID())', N'غایب', N'FAIL', N'پیش‌فرض FileGuid یافت نشد.');

/* ---------- ۸) ایندکس‌ها (نام + ستون‌های کلید به ترتیب) ---------- */
DECLARE @Ix NVARCHAR(200);
DECLARE @IxName NVARCHAR(128), @IxExpected NVARCHAR(200);

DECLARE ix_cur CURSOR LOCAL FAST_FORWARD FOR
    SELECT N'IX_Attachments_Owner',     N'(OwnerType, OwnerId)'
    UNION ALL SELECT N'IX_Attachments_Request',  N'(RequestId)'
    UNION ALL SELECT N'IX_Attachments_Micro',    N'(MicroId)'
    UNION ALL SELECT N'IX_Attachments_UploadedAt', N'(UploadedAt)';

OPEN ix_cur;
FETCH NEXT FROM ix_cur INTO @IxName, @IxExpected;
WHILE @@FETCH_STATUS = 0
BEGIN
    SET @Ix = (SELECT STRING_AGG(c.name, N', ') WITHIN GROUP (ORDER BY ic.key_ordinal)
               FROM sys.indexes AS i
               JOIN sys.index_columns AS ic ON ic.object_id = i.object_id AND ic.index_id = i.index_id AND ic.is_included_column = 0
               JOIN sys.columns AS c ON c.object_id = ic.object_id AND c.column_id = ic.column_id
               WHERE i.object_id = @Tid AND i.name = @IxName);

    IF @Ix = @IxExpected
        INSERT INTO #Verify ([Item], [Expected], [Actual], [Result], [توضیح])
        VALUES (N'ایندکس: ' + @IxName, @IxExpected, @Ix, N'PASS', N'ایندکس با ستون‌های کلید صحیح موجود است.');
    ELSE
        INSERT INTO #Verify ([Item], [Expected], [Actual], [Result], [توضیح])
        VALUES (N'ایندکس: ' + @IxName, @IxExpected, ISNULL(@Ix, N'«غایب»'), N'FAIL',
                N'ایندکس یافت نشد یا ستون‌های کلید آن متفاوت است — اسکریپت ۰۲ را دوباره اجرا کنید.');

    FETCH NEXT FROM ix_cur INTO @IxName, @IxExpected;
END
CLOSE ix_cur;
DEALLOCATE ix_cur;

/* ---------- ۹) قیدهای CHECK ---------- */
DECLARE @CkName NVARCHAR(128), @CkDesc NVARCHAR(120), @CkDisabled INT;
DECLARE ck_cur CURSOR LOCAL FAST_FORWARD FOR
    SELECT N'CK_Attachments_OwnerType',       N'OwnerType IN (1,2)'
    UNION ALL SELECT N'CK_Attachments_Size',  N'SizeBytes BETWEEN 1 AND 1048576'
    UNION ALL SELECT N'CK_Attachments_Status',N'Status IN (active, quarantined)'
    UNION ALL SELECT N'CK_Attachments_ExactlyOneOwner', N'دقیقاً یکی از RequestId/MicroId پر باشد (D-08)';

OPEN ck_cur;
FETCH NEXT FROM ck_cur INTO @CkName, @CkDesc;
WHILE @@FETCH_STATUS = 0
BEGIN
    SELECT @CkDisabled = cc.is_disabled
    FROM sys.check_constraints AS cc
    WHERE cc.name = @CkName AND cc.parent_object_id = @Tid;

    IF @CkDisabled IS NOT NULL
        INSERT INTO #Verify ([Item], [Expected], [Actual], [Result], [توضیح])
        VALUES (N'قید CHECK: ' + @CkName, @CkDesc,
                CASE WHEN @CkDisabled = 0 THEN N'موجود و فعال' ELSE N'موجود اما غیرفعال' END,
                CASE WHEN @CkDisabled = 0 THEN N'PASS' ELSE N'FAIL' END,
                CASE WHEN @CkDisabled = 0 THEN N'قید صحت با موفقیت اعمال شده است.'
                     ELSE N'قید غیرفعال شده است — با ALTER TABLE ... CHECK CONSTRAINT فعال شود.' END);
    ELSE
        INSERT INTO #Verify ([Item], [Expected], [Actual], [Result], [توضیح])
        VALUES (N'قید CHECK: ' + @CkName, @CkDesc, N'«غایب»', N'FAIL',
                N'قید یافت نشد — اسکریپت ۰۲ را دوباره اجرا کنید (برای ExactlyOneOwner، وجود هر دو ستون RequestId و MicroId لازم است).');

    FETCH NEXT FROM ck_cur INTO @CkName, @CkDesc;
END
CLOSE ck_cur;
DEALLOCATE ck_cur;

/* ---------- ۱۰) کلیدهای خارجی مشروط به وجود جدول پایه ---------- */
DECLARE @BaseExists BIT, @FkName NVARCHAR(128), @FkBase NVARCHAR(128), @FkDesc NVARCHAR(300);
DECLARE fk_cur CURSOR LOCAL FAST_FORWARD FOR
    SELECT N'FK_Attachments_Request',    N'dbo.Requests',      N'RequestId → dbo.Requests(Id)'
    UNION ALL SELECT N'FK_Attachments_Micro',   N'dbo.RequestMicros', N'MicroId → dbo.RequestMicros(Id)'
    UNION ALL SELECT N'FK_Attachments_UploadedBy', N'dbo.Users',      N'UploadedById → dbo.Users(Id)';

OPEN fk_cur;
FETCH NEXT FROM fk_cur INTO @FkName, @FkBase, @FkDesc;
WHILE @@FETCH_STATUS = 0
BEGIN
    SET @BaseExists = CASE WHEN OBJECT_ID(@FkBase, N'U') IS NOT NULL THEN 1 ELSE 0 END;

    IF EXISTS (SELECT 1 FROM sys.foreign_keys WHERE name = @FkName AND parent_object_id = @Tid)
        INSERT INTO #Verify ([Item], [Expected], [Actual], [Result], [توضیح])
        VALUES (N'کلید خارجی: ' + @FkName, @FkDesc, N'موجود', N'PASS', N'ارتباط مرجعی برقرار است.');
    ELSE IF @BaseExists = 0
        INSERT INTO #Verify ([Item], [Expected], [Actual], [Result], [توضیح])
        VALUES (N'کلید خارجی: ' + @FkName, @FkDesc, N'ساخته نشد', N'PASS',
                N'جدول پایه ' + @FkBase + N' موجود نیست؛ طبق طراحی، ساخت FK مشروط است و غیبت آن در این حالت طبیعی است (در استقرار واقعی، برنامه DB-01…DB-13 جدول پایه را می‌سازد).');
    ELSE
        INSERT INTO #Verify ([Item], [Expected], [Actual], [Result], [توضیح])
        VALUES (N'کلید خارجی: ' + @FkName, @FkDesc, N'«غایب»', N'FAIL',
                N'جدول پایه موجود است اما FK ساخته نشده — اسکریپت ۰۲ را دوباره اجرا کنید و پیام‌های FAIL را بررسی کنید.');

    FETCH NEXT FROM fk_cur INTO @FkName, @FkBase, @FkDesc;
END
CLOSE fk_cur;
DEALLOCATE fk_cur;

/* ---------- جمع‌بندی ---------- */
DECLARE @PassCount INT = (SELECT COUNT(*) FROM #Verify WHERE [Result] = N'PASS');
DECLARE @FailCount INT = (SELECT COUNT(*) FROM #Verify WHERE [Result] = N'FAIL');

INSERT INTO #Verify ([Item], [Expected], [Actual], [Result], [توضیح])
VALUES (N'جمع‌بندی', N'همه موارد باید PASS باشند',
        CAST(@PassCount AS NVARCHAR(10)) + N' مورد PASS / ' + CAST(@FailCount AS NVARCHAR(10)) + N' مورد FAIL',
        CASE WHEN @FailCount = 0 THEN N'PASS' ELSE N'FAIL' END,
        N'تعداد کل بررسی‌ها: ' + CAST((@PassCount + @FailCount) AS NVARCHAR(10)));

SELECT [Item], [Expected], [Actual], [Result], [توضیح] FROM #Verify ORDER BY Id;

DROP TABLE #Verify;

IF @FailCount = 0
    PRINT N'=== نتیجه: ساختار پیوست‌ها کاملاً منطبق بر طراحی است — می‌توانید ادامه دهید (اسکریپت ۰۵ در آزمایش، سپس اجرای API). ===';
ELSE
    PRINT N'=== نتیجه: ' + CAST(@FailCount AS NVARCHAR(10)) + N' مورد FAIL وجود دارد — طبق Runbook پیش از ادامه برطرف شود. ===';