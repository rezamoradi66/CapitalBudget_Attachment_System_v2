// ============================================================================
// مولد اعتبارنامه اولیه آزمایشی (LAB) — نسخه v2
// ============================================================================
// هدف: تولید رمز اولیه «تصادفی و امن» برای کاربر admin آزمایشی + هش ذخیره‌سازی
// آن در قالب استاندارد ماژول پیوست‌ها (PBKDF2$100000$<salt>$<hash> — D-01).
//
// ★ هیچ رمز ثابتی در اسکریپت‌ها/مستندات وجود ندارد — این ابزار در هر اجرا
//   یک رمز کاملاً تصادفی (CSPRNG) می‌سازد و همان را یک‌بار چاپ می‌کند.
//
// خروجی:
//   PASSWORD = <رمز تصادفی ۲۰ نویسه‌ای — فقط همین یک‌بار نمایش داده می‌شود>
//   HASH     = <مقدار PasswordHash برای اسکریپت 05-Seed-Lab-Minimal.sql>
//
// استفاده:
//   dotnet run --project 02-Database/tools/LabCredentialGenerator -c Release
//
// گام‌های توصیه‌شده:
//   ۱) خروجی را بلافاصله در «مدیریت‌کننده گذرواژه» سازمان ثبت کنید؛
//   ۲) HASH را به اسکریپت ۰۵ بدهید:  sqlcmd -v InitialPasswordHash="PBKDF2$100000$..."
//   ۳) پس از اولین ورود، سامانه تغییر اجباری رمز را اعمال می‌کند (MustChangePassword=1)
//      و رمز اولیه از کار می‌افتد — نسخه ثبت‌شده در مدیر گذرواژه را باطل کنید.
// ============================================================================
using Attachments.Core.Services;

var (password, hash) = InitialPasswordGenerator.GenerateWithHash();

Console.WriteLine("=== Lab Initial Credential Generator (v2) ===");
Console.WriteLine();
Console.WriteLine($"PASSWORD={password}");
Console.WriteLine($"HASH={hash}");
Console.WriteLine();
Console.WriteLine("REMINDERS:");
Console.WriteLine("  * PASSWORD is shown ONCE — store it in the organizational password manager now.");
Console.WriteLine("  * Pass HASH to 05-Seed-Lab-Minimal.sql via: sqlcmd -v InitialPasswordHash=\"" + hash + "\"");
Console.WriteLine("  * MustChangePassword=1 forces a change at first login; discard the recorded initial password afterwards.");
Console.WriteLine("  * Console must use UTF-8 (chcp 65001 / sqlcmd -f 65001) when pasting values.");
