# مستند ساختار پایگاه‌داده ماژول پیوست‌ها (Database-Structure)

**پروژه:** سامانه مدیریت بودجه سرمایه‌ای (Capital Budget Management System)
**ماژول:** مدیریت پیوست‌ها (Attachment Management)
**مبنای طراحی:** سند ۰۳ — طراحی پایگاه‌داده، نسخه ۶ (و سند برنامه ساخت DB-01…DB-13)
**محل ذخیره‌سازی باینری:** SQL Server FILESTREAM (تصمیم D-21)
**نسخه سند:** ۱.۰ — همراه بسته `02-Database`

> این سند ساختار مصوب جدول `dbo.RequestAttachments`، چیدمان ذخیره‌سازی، ایندکس‌ها، روابط، رفتار حذف، الزامات پشتیبانی‌گیری و پیش‌نیازهای دقیق IT را مستند می‌کند. پیاده‌سازی عملی در اسکریپت‌های `sql/02-Create-Attachment-Structure.sql` (ساخت) و `sql/03-Verify-Attachment-Structure.sql` (صحه‌گذاری) انجام شده است.

---

## ۱. دامنه و تصمیم‌های مرجع

| شناسه تصمیم | عنوان | اثر بر این ماژول |
|---|---|---|
| **D-08** | حذف فیزیکی مجاز؛ بدون قابلیت undelete | حذف پیوست = حذف فیزیکی ردیف متادیتا؛ پاک‌سازی بایت‌ها با GC داخلی FILESTREAM (بخش ۶) |
| **D-10** | سقف‌های مصوب پیوست | حداکثر **۱۰ فایل به ازای هر مالک** (کنترل در لایه برنامه) و حداکثر **۱,۰۴۸,۵۷۶ بایت (۱MB) به ازای هر فایل** (قید پایگاه‌داده `CK_Attachments_Size`) |
| **D-21** | محل ذخیره پیوست‌ها | بایت‌ها بیرون از فایل‌های داده، در کانتینر NTFS ولی «درون مدل تراکنشی/پشتیبانی دیتابیس» — یعنی FILESTREAM (بخش ۳) |

توجه: داده نمونه فقط در محیط آزمایشی مجاز است (D-12)؛ اسکریپت `05-Seed-Lab-Minimal.sql` صراحتاً LAB-ONLY است.

## ۲. جدول `dbo.RequestAttachments` — ستون‌ها

| ستون | نوع | تهی‌پذیر | قید / پیش‌فرض | توضیح |
|---|---|---|---|---|
| `Id` | `BIGINT IDENTITY(1,1)` | خیر | `PRIMARY KEY` (خوشه‌ای، نام: `PK_Attachments`) | شناسه یکتا و افزایشی رکورد پیوست |
| `OwnerType` | `TINYINT` | خیر | `CHECK: IN (1,2)` — نام: `CK_Attachments_OwnerType` | مالکیت چندریختی: `1`=درخواست/برنامه، `2`=خرده‌ریز/ردیف بودجه (D-08) |
| `OwnerId` | `BIGINT` | خیر | — | شناسه مالک مطابق `OwnerType`؛ برای پرس‌وجوی یکنواخت «پیوست‌های یک مالک» بدون JOIN |
| `RequestId` | `BIGINT` | بله | `FK_Attachments_Request → dbo.Requests(Id)` | شناسه درخواست؛ دقیقاً یکی از `RequestId`/`MicroId` باید پر باشد |
| `MicroId` | `BIGINT` | بله | `FK_Attachments_Micro → dbo.RequestMicros(Id)` | شناسه ردیف (خرده‌ریز) بودجه |
| `OriginalName` | `NVARCHAR(260)` | خیر | — | نام اصلی فایل سمت کاربر (شامل پسوند)؛ ۲۶۰ مطابق سقف MAX_PATH ویندوز |
| `DisplayName` | `NVARCHAR(260)` | بله | — | عنوان نمایشی اختیاری (مثلاً «مصوبه کمیته فنی.pdf») |
| `Extension` | `NVARCHAR(10)` | بله | — | پسوند نرمال‌شده (مثل `.pdf`) برای گزارش و فیلتر |
| `ContentType` | `NVARCHAR(100)` | خیر | — | نوع MIME (مثل `application/pdf`) برای هدر `Content-Type` هنگام دانلود |
| `SizeBytes` | `INT` | خیر | `CHECK: BETWEEN 1 AND 1048576` — نام: `CK_Attachments_Size` | حجم فایل به بایت؛ سقف ۱ مگابایت (D-10)؛ صفر و مقدار منفی رد می‌شود |
| `Sha256` | `CHAR(64)` | خیر | — | هش SHA-256 محتوای فایل (۶۴ کاراکتر هگز) — هدف: **صحه‌گذاری بازیابی** (بخش ۸) |
| `Status` | `NVARCHAR(20)` | خیر | `DEFAULT('active')` — نام: `DF_Attachments_Status`؛ `CHECK: IN ('active','quarantined')` — نام: `CK_Attachments_Status` | وضعیت منطقی: فعال یا قرنطینه (پیش از حذف/بررسی) |
| `UploadedById` | `BIGINT` | خیر | `FK_Attachments_UploadedBy → dbo.Users(Id)` | کاربر بارگذارنده (ممیزی) |
| `UploadedAt` | `DATETIME2` | خیر | `DEFAULT(SYSUTCDATETIME())` — نام: `DF_Attachments_UploadedAt` | زمان بارگذاری به وقت UTC (مرجع زمانی سرور — D-18) |
| `UploadedAtJ` | `CHAR(10)` | بله | — | تاریخ شمسی تولیدی در همان تراکنش، قالب `YYYY/MM/DD` (D-04) |
| `UploadedTimeJ` | `CHAR(5)` | بله | — | ساعت شمسی تولیدی، قالب `HH:MM` (D-04) |
| `FileGuid` | `UNIQUEIDENTIFIER` | خیر | `ROWGUIDCOL`؛ `DEFAULT(NEWSEQUENTIALID())` — نام: `DF_Attachments_FileGuid`؛ `UNIQUE` — نام: `UX_Attachments_FileGuid` | شناسه ردیف، الزامی برای FILESTREAM؛ `NEWSEQUENTIALID()` برای کاهش تکه‌تکه‌شدگی کانتینر |
| `FileContent` | `VARBINARY(MAX)` | خیر | `FILESTREAM` روی فایل‌گروپ `AttachmentsFS` | محتوای باینری فایل؛ خارج از صفحات داده، در کانتینر NTFS (D-21) |

### قید ترکیبی «دقیقاً یک مالک» (D-08)

علاوه بر دو ستون واقعی FK، قید زیر یکپارچگی مالکیت چندریختی را تضمین می‌کند:

```sql
CK_Attachments_ExactlyOneOwner CHECK
(
    (CASE WHEN RequestId IS NOT NULL THEN 1 ELSE 0 END)
  + (CASE WHEN MicroId  IS NOT NULL THEN 1 ELSE 0 END) = 1
)
```

یعنی هر ردیف باید «دقیقاً یکی» از دو مالک را داشته باشد؛ هر دو NULL یا هر دو پر → خطا (مطابق آزمون DB-06 در سند ۰۶).

## ۳. چیدمان ذخیره‌سازی و فایل‌گروپ (نمودار متنی)

```
Windows Server 2019 — NTFS (ولوم D:)
│
├── D:\CBM\FS\                        ← پوشه والد (باید از قبل توسط IT ساخته شود)
│   └── AttachmentsFSData\            ← «کانتینر FILESTREAM» (خودش را SQL Server می‌سازد)
│       ├── filestream.hdr            ← فراداده کانتینر (مدیریت‌شده توسط موتور؛ دست‌نخورده!)
│       └── <پوشه‌های GUID>\...       ← فایل‌های BLOB واقعی — هر پیوست یک فایل NTFS مستقل
│
└── (در سطح Instance)  Share نام‌گذاری‌شده FILESTREAM برای دسترسی جریان Win32

SQL Server 2022 Standard — پایگاه‌داده: CapitalBudgetManagement_Lab
│
├── Filegroup [PRIMARY]               ← ردیف‌ها: همه ستون‌های متادیتا + اشاره‌گر FileGuid
│                                        (فایل‌های mdf/ndf معمولی)
├── Filegroup [AttachmentsFS]  CONTAINS FILESTREAM
│     └── AttachmentsFSData  →  D:\CBM\FS\AttachmentsFSData
│                                        (حجم/رشد پویاست؛ SIZE/FILEGROWTH برای فایل
│                                         FILESTREAM اعمال نمی‌شود — سهمیه‌بندی با Quota NTFS)
└── Log file (*.ldf)                  ← گزارش تراکنش؛ یکپارچگی تراکنشی INSERT/UPDATE/DELETE
                                        متادیتا با بایت‌های FILESTREAM را تضمین می‌کند
```

**چگونه کار می‌کند:** ستون `FileContent` در ردیف، فقط یک اشاره‌گر نگه می‌دارد؛ بایت‌های واقعی به‌عنوان فایل NTFS داخل کانتینر ذخیره می‌شوند. موتور SQL Server یکپارچگی تراکنشی بین ردیف و فایل را تضمین می‌کند (کامیت/برگشت مشترک). دسترسی از دو مسیر ممکن است: (۱) T-SQL معمولی (همیشه کار می‌کند) و (۲) جریان Win32 با `SqlFileStream` برای انتقال بهینه (نیازمند سطح FILESTREAM ≥ 2).

**ملاحظات اندازه:** با سقف ۱ مگابایت و حداکثر ۱۰ فایل به ازای هر مالک (D-10)، بیشینه حجم منطقی هر مالک ۱۰ مگابایت است. اگر در آینده سقف فایل افزایش یابد، FILESTREAM بدون تغییر ساختار مقیاس‌پذیر می‌ماند (استدلال D-21).

## ۴. ایندکس‌ها

| نام | نوع | ستون‌ها | هدف |
|---|---|---|---|
| `PK_Attachments` | CLUSTERED PK | `(Id)` | دسترسی نقطه‌ای به رکورد و پشتیبانی شناسه افزایشی |
| `UX_Attachments_FileGuid` | UNIQUE (NONCLUSTERED) | `(FileGuid)` | الزام FILESTREAM برای ROWGUIDCOL + جلوگیری از GUID تکراری |
| `IX_Attachments_Owner` | NONCLUSTERED | `(OwnerType, OwnerId)` | مسیر اصلی: فهرست پیوست‌های یک مالک + کنترل سقف ۱۰ فایل (D-10) |
| `IX_Attachments_Request` | NONCLUSTERED | `(RequestId)` | پشتیبان FK و پرس‌وجوهای سمت درخواست |
| `IX_Attachments_Micro` | NONCLUSTERED | `(MicroId)` | پشتیبان FK و پرس‌وجوهای سمت ردیف بودجه |
| `IX_Attachments_UploadedAt` | NONCLUSTERED | `(UploadedAt)` | گزارش‌های زمانی، پایش و جاب‌های نگهداری |

## ۵. روابط (Relationships)

```
dbo.Users          1 ──────── *  dbo.RequestAttachments   (UploadedById — FK_Attachments_UploadedBy)
dbo.Requests       1 ──────── *  dbo.RequestAttachments   (RequestId    — FK_Attachments_Request)
dbo.RequestMicros  1 ──────── *  dbo.RequestAttachments   (MicroId      — FK_Attachments_Micro)
                                        └── CK_Attachments_ExactlyOneOwner: دقیقاً یکی از دو مالک
```

- FKها «مشروط» ساخته می‌شوند: فقط اگر جدول پایه موجود باشد (برای انعطاف محیط آزمایشی). در استقرار واقعی، برنامه DB-01…DB-13 همه جدول‌های پایه را می‌سازد و سپس اجرای مجدد `02` هر سه FK را تضمین می‌کند.
- مطابق قاعده D-06، همه FKهای کاربران به `Users.Id` اشاره می‌کنند.

## ۶. رفتار حذف (Delete Behavior)

1. **حذف منطقی:** با `Status = 'quarantined'` ردیف از دید کاربر عادی خارج می‌شود اما داده باقی است (بدون تغییر ساختار).
2. **حذف فیزیکی (D-08):** `DELETE` ردیف = حذف فیزیکی متادیتا؛ قابل بازگشت نیست (بدون undelete — عین کد مرجع).
3. **پاک‌سازی بایت‌ها (FILESTREAM GC):** پس از DELETE، فایل NTFS مربوطه بلافاصله حذف نمی‌شود؛ «جمع‌کننده زباله» داخلی FILESTREAM پس از گذر Checkpoint/چرخه GC آن را بازپس می‌گیرد. یعنی:
   - فضای دیسک با تأخیر آزاد می‌شود (برای پایش ظرفیت لحاظ شود)؛
   - اگر در لحظه DELETE پشتیبان‌گیری فعال باشد، فایل حذف‌شده تا پایان آن عملیات قابل ردیابی است؛
   - هرگز فایل‌های داخل کانتینر را **دستی** حذف/جابه‌جا نکنید — GC و کاتالوگ خراب می‌شود.
4. **حفاظت مرجعی:** به دلیل FKها، حذف درخواست/ردیفی که پیوست فعال دارد خطا می‌دهد (مطابق آزمون DB-06)؛ حذف باید اول روی پیوست‌ها انجام شود.

## ۷. ملاحظات پشتیبانی‌گیری (Backup)

| نوع پشتیبان | وضعیت داده FILESTREAM | توضیح |
|---|---|---|
| **Full (کامل)** | شامل می‌شود | کانتینر FILESTREAM جزو پشتیبان پایگاه‌داده است؛ BLOBها به‌صورت تراکنشی-سازگار کپی می‌شوند |
| **Differential (تفاضلی)** | شامل می‌شود | فقط تغییرات از آخرین Full — از جمله بایت‌های FILESTREAM تغییرکرده |
| **Log (لاگ)** | در ادامه زنجیره ضروری | برای بازیابی نقطه‌زمانی متادیتا؛ هماهنگی نهایی کانتینر پس از RESTORE با سازوکار GC انجام می‌شود (فایل‌های یتیم پاک می‌شوند) |

**نکات عملیاتی:**
- کپی دستی پوشه کانتینر، «پشتیبان معتبر» نیست؛ فقط BACKUP/RESTORE یا VSS مبتنی بر SQL Server مجاز است.
- حجم پشتیبان با رشد پیوست‌ها رشد می‌کند (سقف نرمال: ۱۰ × ۱ مگابایت به ازای هر مالک — D-10).
- مدل بازیابی `FULL` برای RTO/RPO مصوب توصیه می‌شود؛ در `SIMPLE` بازیابی فقط تا آخرین Full/Diff ممکن است.
- بازیابی آزمایشی دوره‌ای (بند D-11) شامل تأیید سالم بودن کانتینر FILESTREAM است.
- برای زنجیره لاگ، زمان‌بندی Log Backup (مثلاً هر ۱۵ دقیقه) با DBA هماهنگ شود.

## ۸. هدف ستون `Sha256` — صحه‌گذاری بازیابی

`Sha256` هش SHA-256 محتوای بارگذاری‌شده است و کاربرد آن «صحه‌گذاری بازیابی/یکپارچگی» است، نه امنیت:

- پس از هر **RESTORE** (به‌ویژه در بازیابی آزمایشی ماهانه)، نمونه‌گیری از فایل‌ها خوانده و هش مجدد محاسبه می‌شود؛ مطابقت با مقدار ذخیره‌شده یعنی کانتینر FILESTREAM سالم بازگردانده شده است.
- در ممیزی دوره‌ای، مغایرت هش = خرابی فایل/دستکاری خارج از موتور را علامت می‌دهد.
- این مقدار توسط سرویس در زمان بارگذاری محاسبه و در همان تراکنش ذخیره می‌شود؛ قیاس با رمز عبور ندارد و رمزنگاری نمی‌شود.

## ۹. پیش‌نیازهای دقیق IT (چک‌لیست اجرا)

| # | پیش‌نیاز | مسئول | کنترل |
|---|---|---|---|
| ۱ | Windows Server 2019 + SQL Server 2022 **Standard** | IT | اسکریپت `00` (ردیف ویرایش) |
| ۲ | فعال‌سازی FILESTREAM در SQL Server Configuration Manager (حداقل T-SQL access؛ توصیه: سطح کامل برای جریان Win32) | IT/DBA | اسکریپت `01` (PASS سطح مؤثر) |
| ۳ | `sp_configure 'filestream access level', 2` + `RECONFIGURE` + ری‌استارت سرویس SQL Server | DBA | اسکریپت `01` (ردیف sp_configure) |
| ۴ | ساخت پوشه والد `D:\CBM\FS` روی دیسک NTFS با فضای آزاد کافی (آزمایش: ≥ ۱۰ گیگابایت؛ عملیاتی: برآورد ظرفیت × حاشیه) | IT | اسکریپت `01`/`04` (فضای ولوم) |
| ۵ | سهمیه‌بندی در صورت نیاز با Quota سطح NTFS (چون SIZE/FILEGROWTH برای فایل FILESTREAM اعمال نمی‌شود) | IT | — |
| ۶ | دسترسی sysadmin/db_owner + مجوز ALTER DATABASE برای اجرای اسکریپت `02` | DBA | Runbook |
| ۷ | اجرای اسکریپت‌ها با SQLCMD Mode (SSMS) یا `sqlcmd -f 65001` برای متن فارسی صحیح | DBA | Runbook |
| ۸ | پشتیبان کامل پیش از ساخت و پس از ساخت + زمان‌بندی Log Backup (مدل FULL) | DBA | اسکریپت `00` (زمان آخرین پشتیبان‌ها) |
| ۹ | پایش دیسک کانتینر و در نظر گرفتن تأخیر آزادسازی GC | IT/DBA | اسکریپت `04` |
| ۱۰ | هماهنگی با امنیت IT درباره آنتی‌ویروس روی کانتینر (الگوی مایکروسافت: بررسی راهبرد اسکن، نه حذف کورکورانه) | IT Security | — |

## ۱۰. نگاشت اسکریپت‌ها به این سند

| اسکریپت | نقش |
|---|---|
| `sql/00-Check-Database-State.sql` | ارزیابی وضعیت پایگاه‌داده (فقط‌خواندنی) |
| `sql/01-Check-Filestream-Prerequisites.sql` | چک‌لیست پیش‌نیاز FILESTREAM (فقط‌خواندنی) |
| `sql/02-Create-Attachment-Structure.sql` | ساخت/تکمیل ساختار (فایل‌گروپ، جدول، ایندکس، FK، CHECK) — Idempotent |
| `sql/03-Verify-Attachment-Structure.sql` | صحه‌گذاری کامل ساختار (PASS/FAIL) |
| `sql/04-Health-Check.sql` | پایش عملیاتی داده‌ها و کانتینر |
| `sql/05-Seed-Lab-Minimal.sql` | داده نمونه — فقط LAB (D-12) |
| `sql/99-Rollback-Attachment-Structure.sql` | بازگردانی ساختار با حفاظت داده |
| `Runbook-Lab-Deployment.md` | راهنمای گام‌به‌گام استقرار آزمایشی |
