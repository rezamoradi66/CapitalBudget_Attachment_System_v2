# مستندات API پیوست‌ها (API-SPEC) — نسخه v1

قراردادها مطابق سند ۰۵ مصوب: پیشوند `/api/v1/`، پاسخ موفق `{success:true, data:…}`، خطا `ProblemDetails` (RFC 7807) با `errorCode` پایدار و `title` فارسی، احراز هویت Cookie امن (`CBM.Attach.Session` — HttpOnly, SameSite=Lax)، نشست ۳۰ دقیقه لغزشی سمت سرور (D-03)، قفل ورود ۵ تلاش → ۱۵ دقیقه (D-02).

## ۱. نقشه Endpointها

| مسیر | متد | هدف | مجوز |
|---|---|---|---|
| `/api/v1/auth/login` | POST | ورود — `{username,password}` → `{id,username,fullName,roles[],mustChangePassword}` | عمومی (Rate Limit ۱۰/دقیقه/IP) |
| `/api/v1/auth/logout` | POST | ابطال نشست + رویداد | نشست‌دار |
| `/api/v1/auth/me` | GET | کاربر جاری + نقش‌ها | نشست‌دار |
| `/api/v1/auth/change-password` | POST | تغییر رمز (D-01: حداقل ۸، فهرست رایج، ≠نام کاربری؛ رفع `mustChangePassword`) | نشست‌دار |
| `/api/v1/requests/by-code/{code}` | GET | حل کد برنامه → شناسه سرور + ریزتقاضاها (برای آداپتور HTML) | scoped |
| `/api/v1/requests/{id}/attachments` | GET | فهرست پیوست‌های برنامه | مشاهده مالک |
| `/api/v1/requests/{id}/attachments` | POST | بارگذاری (multipart: `file`، `displayName?`، هدر `X-Request-Id?`) | ویرایش مالک |
| `/api/v1/micros/{id}/attachments` | GET / POST | فهرست / بارگذاری پیوست ردیف | مشاهده / ویرایش مالک |
| `/api/v1/attachments/{id}/info` | GET | متادیتای یک پیوست | مشاهده مالک |
| `/api/v1/attachments/{id}` | GET | دانلود استریم (Content-Type سفیدلیستی + `attachment` + nosniff) | مشاهده مالک |
| `/api/v1/attachments/{id}` | DELETE | حذف فیزیکی + رویداد (D-08) | ویرایش مالک |
| `/health` | GET | سلامت — `{"status":"Healthy"}` فقط | عمومی |

## ۲. نمونه پاسخ بارگذاری موفق (201)

```json
{ "success": true, "data": {
  "id": 12, "ownerType": 1, "ownerId": 3,
  "originalName": "پیش‌فاکتور سامانه.pdf", "displayName": "پیش‌فاکتور رسمی",
  "extension": ".pdf", "contentType": "application/pdf", "sizeBytes": 184320,
  "sha256": "3f7a…", "status": "active",
  "uploadedById": 2, "uploadedByName": "علی محمدی",
  "uploadedAt": "2026-10-24T09:41:00", "uploadedAtJ": "1405/08/02", "uploadedTimeJ": "09:41"
}}
```
> هیچ مسیر فیزیکی، FileGuid یا مسیر FILESTREAM در پاسخ‌ها نمی‌آید (بند ۶ مأموریت + امنیت).

## ۳. کدهای خطای پایدار

| errorCode | HTTP | پیام فارسی |
|---|---|---|
| `UNAUTHENTICATED` | 401 | برای این عملیات باید وارد سامانه شوید. |
| `INVALID-CREDENTIALS` | 401 | نام کاربری یا رمز عبور نادرست است یا حساب کاربری غیرفعال می‌باشد. |
| `LOGIN-LOCKED` | 401 | به دلیل تلاش‌های ناموفق، حساب تا مدتی قفل شده است. |
| `RATE-LIMITED` | 429 | تعداد درخواست‌ها بیش از حد مجاز است. لطفاً کمی بعد دوباره تلاش کنید. |
| `PASSWORD-CHANGE-REQUIRED` | 403 | پیش از ادامه، تغییر رمز عبور الزامی است. |
| `PASSWORD-POLICY` | 400 | رمز عبور با سیاست امنیتی هم‌خوان نیست. |
| `FORBIDDEN` | 403 | شما مجوز این عملیات را ندارید. |
| `NOT-FOUND` | 404 | مورد درخواستی یافت نشد یا خارج از محدوده دید شماست. |
| `FILE-TOO-LARGE` | 413 | حجم فایل بیش از سقف مجاز (۱ مگابایت) است. در v2 چهار لایه سقف دارد: IIS/Kestrel (سقف بدنه) → Middleware (رد پیش از خواندن بدنه) → سقف multipart فریم‌ورک → خواندن قطع‌شدنی؛ پاسخ در همه لایه‌ها همان ProblemDetails قراردادی است. |
| `FILE-EMPTY` | 422 | فایل خالی قابل بارگذاری نیست. |
| `FILE-COUNT-EXCEEDED` | 422 | حداکثر ۱۰ پیوست برای هر بخش مجاز است. |
| `FILE-TYPE-NOT-ALLOWED` | 415 | این نوع فایل مجاز نیست. |
| `FILE-CONTENT-MISMATCH` | 415 | محتوای فایل با پسوند اعلام‌شده هم‌خوان نیست. |
| `FILENAME-INVALID` | 422 | نام فایل معتبر نیست. |
| `IDEMPOTENCY-CONFLICT` | 409 | این شناسه درخواست قبلاً با محتوای دیگری استفاده شده است. |
| `INTERNAL` | 500 | خطای داخلی سرور. با مدیر سامانه تماس بگیرید. |

## ۴. قواعد مجوز (عین کد مرجع — شواهد خط ۱۸۳۷/۱۸۸۳)

- مشاهده/دانلود = محدوده دید: مدیر/مدیرعامل همه؛ کنترل بودجه هم‌نوع (رکورد بدون نوع فقط مشاهده)؛ متقاضی برنامه‌های خودش؛ متعهد واحد؛ مدیر ارشد مدیریت.
- افزودن/حذف = مجوز ویرایش همان مالک (وضعیت‌های عین کد) + برای ردیف: `AhpStatus != approved` (قفل تصمیم نهایی؛ مدیر مستثنا طبق کد مرجع).
- همه محاسبات روی داده سمت سرور انجام می‌شود (SEC-004).

## ۵. اعتبارسنجی فایل (بند ۷ مأموریت)

1. پسوند ∈ فهرست مجاز عین کد (ATT_ACCEPT — خط ۷۸۸ کد مرجع)؛ 2. امضای باینری (magic number) هم‌خوان؛ 3. اندازه ۱..۱٬۰۴۸٬۵۷۶ بایت + CHECK دیتابیس؛ 4. حداکثر ۱۰ فایل برای هر مالک؛ 5. نرمال‌سازی امن نام (Path Traversal/نام‌های رزرو ویندوز/نویسه کنترلی)؛ 6. SHA-256 محاسبه و ذخیره (مبنای آزمون بازیابی).

## ۶. درخواست‌های نمونه

فایل `sample-requests.http` (کنار همین سند) سناریوی کامل ورود → بارگذاری → فهرست → دانلود → حذف را دارد.
