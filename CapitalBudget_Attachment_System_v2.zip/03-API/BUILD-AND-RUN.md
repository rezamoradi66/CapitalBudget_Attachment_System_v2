# راهنمای ساخت، اجرا و استقرار API پیوست‌ها (BUILD-AND-RUN)

## ۱. پیش‌نیازها

| مورد | مقدار | یادداشت |
|---|---|---|
| SDK ساخت | .NET 10 (در این بسته با **10.0.402** ساخته و آزمون شد) | فقط ماشین Build به SDK نیاز دارد |
| سرور | Windows Server 2019 + IIS | ANCM v2 In-Process |
| Runtime سرور | **ASP.NET Core Hosting Bundle 10.0** (نصب آفلاین با نصاب جداگانه — نیازی به اینترنت ندارد) | نسخه اعلامی سرور 10.0.13 هم‌خوان است |
| دیتابیس | SQL Server 2022 Standard + FILESTREAM فعال (دستورالعمل `05-Operations/FILESTREAM-Configuration-Guide.md`) | اسکریپت‌های `02-Database/` |

## ۲. نسخه دقیق بسته‌های NuGet (برای شبکه آفلاین)

```text
Microsoft.Data.SqlClient 7.1.1
Microsoft.EntityFrameworkCore 10.0.13
Microsoft.EntityFrameworkCore.SqlServer 10.0.13
Serilog.AspNetCore 10.0.0
Serilog.Sinks.File 7.0.0
```
> برای Build آفلاین: پوشه publish نیازی به NuGet ندارد؛ فقط ماشین Build در صورت نبود اینترنت باید از یک فید محلی (paket/`nuget locals`) استفاده کند.

## ۳. دستورهای ساخت و آزمون (اجرا شده واقعی در محیط توسعه — نسخه v2)

```bash
dotnet build -c Release     # موفق — 0 خطا / 0 هشدار (v2)
dotnet test  -c Release     # موفق — 108/108 قبول (89 v1 + 19 v2 — گزارش: 06-Tests/Test-Report-Executed.md)
dotnet publish src/Attachments.Api -c Release -o publish
```

## ۴. متغیرهای محیطی استقرار (هیچ رمزی در فایل‌ها نیست — D-09)

| متغیر | نمونه | توضیح |
|---|---|---|
| `ConnectionStrings__Default` | `Server=.;Database=CapitalBudgetDB;Trusted_Connection=True;TrustServerCertificate=True` | اتصال Windows Auth توصیه می‌شود (الزام SqlFileStream)؛ **v2: بدون این مقدار، استارتاپ Fail-Fast می‌شود — دیگر هیچ fallback پیش‌فرض خاموشی وجود ندارد** |
| `ASPNETCORE_ENVIRONMENT` | `Production` | در Production حالت InMemory ممنوع (Startup Guard) |
| `Attachments__BinaryStore` | `Filestream` | مقادیر: `Filestream` (SqlFileStream) / `FilestreamViaSql` (انتقال بایت با T-SQL در همان تراکنش — هر دو ستون FILESTREAM واقعی را پر می‌کنند) |
| سقف حجم درخواست (v2) | سقف فایل + ۶۴KB | به‌طور خودکار از `Attachments__MaxFileSizeBytes` مشتق و روی چهار لایه اعمال می‌شود: IISServerOptions / Kestrel / Middleware Content-Length / MultipartBodyLengthLimit — برای تغییر سقف فقط همان متغیر را تنظیم کنید |

## ۵. استقرار در IIS (خلاصه — راهنمای کامل: `05-Operations/IIS-Deployment-Guide.md`)

1. پوشه `publish/` را روی سرور کپی کنید (مثلاً `C:\Apps\CBMAttachments`).
2. App Pool اختصاصی بدون Identity مدیریت (No Managed Code) + هویت سرویس/Account مجازی.
3. مجوز NTFS فقط روی پوشه publish (Read/Execute) و پوشه لاگ و **FILESTREAM container** (Read/Write برای حساب App Pool).
4. Site/Application جدید → مسیر publish → Binding مناسب (ترجیحاً هم‌مبدأ با HTML طبق D-22).
5. سلامت: `GET /health` باید `{"status":"Healthy"}` برگرداند.

## ۶. اجرای محلی برای آزمایش

```bash
export ConnectionStrings__Default="Server=.;Database=CapitalBudgetManagement_Lab;Trusted_Connection=True;TrustServerCertificate=True"
dotnet src/Attachments.Api/bin/Release/net10.0/Attachments.Api.dll
```

## ۷. نکته راه‌حل (Solution)

فایل راه‌حل به‌صورت **AttachmentsModule.slnx** (قالب جدید .NET 10) تولید شده است؛ Visual Studio 2022 17.10+ و `dotnet build` آن را می‌شناسند. در صورت نیاز به قالب کلاسیک: `dotnet sln` پشتیبانی می‌کند یا پروژه‌ها مستقیم قابل Build هستند.
