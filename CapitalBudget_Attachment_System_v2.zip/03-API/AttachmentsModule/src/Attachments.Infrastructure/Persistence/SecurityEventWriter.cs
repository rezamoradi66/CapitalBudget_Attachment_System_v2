using Attachments.Core.Application;
using Attachments.Core.Domain.Entities;

namespace Attachments.Infrastructure.Persistence;

/// <summary>Appends rows to dbo.SecurityEvents. Details are compact JSON produced by callers.</summary>
public class SecurityEventWriter(AppDbContext db) : ISecurityEventWriter
{
    public async Task WriteAsync(
        string eventType, int? userId, string? username, string ip, string userAgent, string detailsJson,
        CancellationToken ct = default)
    {
        db.SecurityEvents.Add(new SecurityEvent
        {
            EventType = eventType,
            UserId = userId,
            Username = username,
            Ip = Truncate(ip, 64),
            UserAgent = Truncate(userAgent, 400),
            Details = detailsJson,
            CreatedAt = DateTime.UtcNow
        });
        await db.SaveChangesAsync(ct);
    }

    private static string Truncate(string? value, int maxLength) =>
        string.IsNullOrEmpty(value) ? "" : (value.Length <= maxLength ? value : value[..maxLength]);
}
