using Attachments.Core.Application;
using Attachments.Core.Domain.Entities;
using Microsoft.EntityFrameworkCore;

namespace Attachments.Infrastructure.Persistence;

public class UserAuthStore(AppDbContext db) : IUserAuthStore
{
    public Task<User?> FindUserByUsernameAsync(string username, CancellationToken ct = default) =>
        db.Users.FirstOrDefaultAsync(u => u.Username == username, ct);

    public Task<User?> FindUserByIdAsync(int id, CancellationToken ct = default) =>
        db.Users.FirstOrDefaultAsync(u => u.Id == id, ct);

    public Task<List<string>> GetRolesAsync(int userId, CancellationToken ct = default) =>
        db.UserRoles.AsNoTracking()
            .Where(r => r.UserId == userId)
            .Select(r => r.RoleCode)
            .ToListAsync(ct);

    public Task<LoginLockout?> FindLockoutAsync(string username, CancellationToken ct = default) =>
        db.LoginLockouts.FirstOrDefaultAsync(l => l.Username == username, ct);

    public async Task SaveLockoutAsync(string username, int failedCount, DateTime? lockedUntilUtc, DateTime lastFailedAtUtc, CancellationToken ct = default)
    {
        var row = await db.LoginLockouts.FirstOrDefaultAsync(l => l.Username == username, ct);
        if (row is null)
        {
            db.LoginLockouts.Add(new LoginLockout
            {
                Username = username,
                FailedCount = failedCount,
                LockedUntilUtc = lockedUntilUtc,
                LastFailedAtUtc = lastFailedAtUtc
            });
        }
        else
        {
            row.FailedCount = failedCount;
            row.LockedUntilUtc = lockedUntilUtc;
            row.LastFailedAtUtc = lastFailedAtUtc;
        }

        await db.SaveChangesAsync(ct);
    }

    public async Task ClearLockoutAsync(string username, CancellationToken ct = default)
    {
        var row = await db.LoginLockouts.FirstOrDefaultAsync(l => l.Username == username, ct);
        if (row is not null)
        {
            db.LoginLockouts.Remove(row);
            await db.SaveChangesAsync(ct);
        }
    }

    public async Task SaveUserAsync(User user, CancellationToken ct = default)
    {
        db.Users.Update(user);
        await db.SaveChangesAsync(ct);
    }

    public async Task<AuthSession> CreateSessionAsync(AuthSession session, CancellationToken ct = default)
    {
        db.AuthSessions.Add(session);
        await db.SaveChangesAsync(ct);
        return session;
    }

    public Task<AuthSession?> FindSessionAsync(Guid id, CancellationToken ct = default) =>
        db.AuthSessions.FirstOrDefaultAsync(s => s.Id == id, ct);

    public async Task TouchSessionAsync(Guid id, DateTime lastSeenAtUtc, CancellationToken ct = default)
    {
        var session = await db.AuthSessions.FirstOrDefaultAsync(s => s.Id == id, ct);
        if (session is not null)
        {
            session.LastSeenAtUtc = lastSeenAtUtc;
            await db.SaveChangesAsync(ct);
        }
    }

    public async Task RevokeSessionAsync(Guid id, DateTime revokedAtUtc, CancellationToken ct = default)
    {
        var session = await db.AuthSessions.FirstOrDefaultAsync(s => s.Id == id, ct);
        if (session is not null)
        {
            session.RevokedAtUtc = revokedAtUtc;
            await db.SaveChangesAsync(ct);
        }
    }
}
