using Attachments.Core.Application;
using Attachments.Core.Domain;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

namespace Attachments.Infrastructure.Storage;

/// <summary>
/// Registers exactly one IAttachmentBinaryStore, chosen from the Attachments:BinaryStore
/// configuration key. Default = «Filestream». Modes:
///   Filestream       → SqlFilestreamBinaryStore (native SqlFileStream API)
///   FilestreamViaSql → SqlByteTransferBinaryStore (parameterized VARBINARY transfer)
///   InMemory         → InMemoryBinaryStore (tests/dev only; rejected in Production at startup)
/// </summary>
public static class AttachmentBinaryStoreRegistration
{
    public static IServiceCollection AddAttachmentBinaryStore(this IServiceCollection services, IConfiguration configuration)
    {
        var mode = configuration["Attachments:BinaryStore"];

        if (string.IsNullOrWhiteSpace(mode) ||
            string.Equals(mode, AttachmentBinaryStoreModes.Filestream, StringComparison.OrdinalIgnoreCase))
        {
            return services.AddSingleton<IAttachmentBinaryStore, SqlFilestreamBinaryStore>();
        }

        if (string.Equals(mode, AttachmentBinaryStoreModes.FilestreamViaSql, StringComparison.OrdinalIgnoreCase))
        {
            return services.AddSingleton<IAttachmentBinaryStore, SqlByteTransferBinaryStore>();
        }

        if (string.Equals(mode, AttachmentBinaryStoreModes.InMemory, StringComparison.OrdinalIgnoreCase))
        {
            return services.AddSingleton<IAttachmentBinaryStore, InMemoryBinaryStore>();
        }

        throw new InvalidOperationException(
            $"مقدار «Attachments:BinaryStore» نامعتبر است: «{mode}». مقادیر مجاز: " +
            $"{AttachmentBinaryStoreModes.Filestream}, {AttachmentBinaryStoreModes.FilestreamViaSql}, {AttachmentBinaryStoreModes.InMemory}.");
    }
}
