using System.Collections.Concurrent;
using Attachments.Core.Application;
using Attachments.Core.Domain;

namespace Attachments.Infrastructure.Storage;

/// <summary>
/// Volatile binary store for unit/integration tests and local development only.
/// Keeps attachment bytes in a per-process dictionary keyed by the attachment id.
/// Program.cs refuses to start with this mode when the environment is Production.
/// </summary>
public sealed class InMemoryBinaryStore : IAttachmentBinaryStore
{
    private readonly ConcurrentDictionary<long, byte[]> _blobs = new();

    public string Mode => AttachmentBinaryStoreModes.InMemory;

    public Task WriteAsync(BinaryStoreContext context, long attachmentId, Stream content, CancellationToken cancellationToken = default)
    {
        using var buffer = new MemoryStream();
        content.CopyTo(buffer);
        _blobs[attachmentId] = buffer.ToArray();
        return Task.CompletedTask;
    }

    public Task<Stream?> OpenReadAsync(BinaryStoreContext context, long attachmentId, CancellationToken cancellationToken = default)
    {
        return Task.FromResult<Stream?>(
            _blobs.TryGetValue(attachmentId, out var bytes)
                ? new MemoryStream(bytes, writable: false)
                : null);
    }
}
