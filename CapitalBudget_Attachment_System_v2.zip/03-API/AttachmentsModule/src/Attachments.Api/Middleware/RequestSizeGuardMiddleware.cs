using Attachments.Core.Domain;
using Attachments.Core.Services;
using Attachments.Api.Http;

namespace Attachments.Api.Middleware;

/// <summary>
/// Pre-body request-size guard (v2 review, item 4): when a request announces a
/// Content-Length above the configured cap, it is rejected with a stable 413
/// FILE-TOO-LARGE ProblemDetails BEFORE any body byte is read — nothing is
/// buffered, parsed or authenticated first. Chunked bodies (no Content-Length)
/// remain covered by the multipart section limit and the bounded upload reader.
/// </summary>
public sealed class RequestSizeGuardMiddleware(RequestDelegate next, long maxRequestBodyBytes)
{
    public async Task InvokeAsync(HttpContext context)
    {
        var contentLength = context.Request.ContentLength;
        if (contentLength is > 0 && contentLength.Value > maxRequestBodyBytes)
        {
            await ProblemResults.WriteAsync(
                context, StatusCodes.Status413RequestEntityTooLarge,
                ErrorCodes.FileTooLarge, UploadLimitsGuard.FileTooLargeMessage(maxRequestBodyBytes));
            return;
        }

        await next(context);
    }
}
