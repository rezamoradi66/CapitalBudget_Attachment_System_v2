namespace Attachments.Api.Middleware;

/// <summary>
/// Baseline security headers on every response (including attachment downloads):
///  - X-Content-Type-Options: nosniff (mandatory for the download endpoint);
///  - X-Frame-Options: DENY, Referrer-Policy: no-referrer, Permitted-Cross-Domain: none;
///  - Cache-Control: no-store — attachment bytes and user data must never be cached.
/// </summary>
public sealed class SecurityHeadersMiddleware(RequestDelegate next)
{
    public async Task InvokeAsync(HttpContext context)
    {
        context.Response.OnStarting(() =>
        {
            var headers = context.Response.Headers;
            headers["X-Content-Type-Options"] = "nosniff";
            headers["X-Frame-Options"] = "DENY";
            headers["Referrer-Policy"] = "no-referrer";
            headers["X-Permitted-Cross-Domain-Policies"] = "none";
            headers["Cache-Control"] = "no-store";
            return Task.CompletedTask;
        });

        await next(context);
    }
}
