using System.Globalization;
using System.Security.Claims;
using Attachments.Api.Auth;
using Attachments.Api.Http;
using Attachments.Core.Application;
using Attachments.Core.Domain.Entities;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.RateLimiting;

namespace Attachments.Api.Controllers;

/// <summary>Authentication endpoints: login / logout / me / change-password.</summary>
[ApiController]
[Route("api/v1/auth")]
public sealed class AuthController(AuthService authService) : ControllerBase
{
    /// <summary>200 → {success,data:{id,username,fullName,roles[],mustChangePassword}} + session cookie. 401 LOGIN-INVALID / LOGIN-LOCKED.</summary>
    [HttpPost("login")]
    [AllowAnonymous]
    [EnableRateLimiting(AuthSchemes.LoginRateLimitPolicy)]
    public async Task<IActionResult> Login([FromBody] LoginRequest request, CancellationToken cancellationToken)
    {
        var result = await authService.LoginAsync(
            request.Username, request.Password, HttpContext.GetClientContext(), cancellationToken);

        var principal = PrincipalFactory.Build(result.User, result.Roles, result.SessionId);
        await HttpContext.SignInAsync(AuthSchemes.SessionCookie, principal);

        return Ok(ApiEnvelope.Ok(ToMe(result.User, result.Roles)));
    }

    [HttpPost("logout")]
    [Authorize]
    public async Task<IActionResult> Logout(CancellationToken cancellationToken)
    {
        var sessionId = GetSessionId();
        await authService.LogoutAsync(sessionId, HttpContext.GetClientContext(), cancellationToken);
        await HttpContext.SignOutAsync(AuthSchemes.SessionCookie);
        return Ok(ApiEnvelope.Ok(true));
    }

    [HttpGet("me")]
    [Authorize]
    public async Task<IActionResult> Me(CancellationToken cancellationToken) =>
        Ok(ApiEnvelope.Ok(await authService.MeAsync(HttpContext.User.ToUserContext(), cancellationToken)));

    [HttpPost("change-password")]
    [Authorize]
    public async Task<IActionResult> ChangePassword([FromBody] ChangePasswordRequest request, CancellationToken cancellationToken)
    {
        await authService.ChangePasswordAsync(
            HttpContext.User.ToUserContext(),
            request.CurrentPassword,
            request.NewPassword,
            HttpContext.GetClientContext(),
            cancellationToken);

        return Ok(ApiEnvelope.Ok(true));
    }

    private Guid GetSessionId() =>
        Guid.TryParse(User.FindFirstValue(PrincipalFactory.ClaimSessionId), out var sessionId)
            ? sessionId
            : Guid.Empty;

    private static UserMeDto ToMe(User user, IReadOnlyList<string> roles) =>
        new(user.Id, user.Username, DisplayName(user), roles, user.MustChangePassword);

    private static string DisplayName(User user)
    {
        var full = string.Join(" ", new[] { user.FirstName, user.LastName }
            .Where(part => !string.IsNullOrWhiteSpace(part))
            .Select(part => part!.Trim()));
        return full.Length > 0 ? full : user.Username;
    }
}
