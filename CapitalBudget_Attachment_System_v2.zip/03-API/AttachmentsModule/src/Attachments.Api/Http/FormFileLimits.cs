using Attachments.Core.Domain;
using Attachments.Core.Services;

namespace Attachments.Api.Http;

/// <summary>
/// Api-layer wrapper around <see cref="UploadLimitsGuard"/> for multipart form files:
/// a cheap header-based pre-check (multipart length, zero body read) followed by the
/// chunked, limit-aborting copy — an oversized body is never fully read into memory.
/// </summary>
public static class FormFileLimits
{
    public static async Task<byte[]> ReadBoundedAsync(IFormFile file, long maxBytes, CancellationToken cancellationToken = default)
    {
        ArgumentNullException.ThrowIfNull(file);
        // Pre-check from multipart metadata — costs no body read at all.
        if (file.Length > maxBytes)
            throw new FileRuleException(413, ErrorCodes.FileTooLarge, UploadLimitsGuard.FileTooLargeMessage(maxBytes));

        await using var stream = file.OpenReadStream();
        return await UploadLimitsGuard.ReadStreamAsync(stream, maxBytes, cancellationToken);
    }
}
