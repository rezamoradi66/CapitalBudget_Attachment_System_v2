using System.Security.Claims;
using Attachments.Core.Application;
using Attachments.Core.Domain;
using Attachments.Core.Services;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.Extensions.DependencyInjection;

namespace Attachments.Api.Auth;

/// <summary>
/// Server-side session validation for every request carrying the CBM.Attach.Session cookie:
/// the session row must exist, be non-revoked and within the sliding idle window
/// (LastSeenAtUtc + SessionIdleMinutes). On success the principal is rebuilt from the fresh
/// user row (roles / MustChangePassword always current) and the session is touched (sliding).
/// </summary>
public static class SessionPrincipalValidator
{
    public static async Task ValidateAsync(CookieValidatePrincipalContext context)
    {
        var requestServices = context.HttpContext.RequestServices;
        var clock = requestServices.GetRequiredService<IClock>();
        var settings = requestServices.GetRequiredService<SessionSettings>();
        var store = requestServices.GetRequiredService<IUserAuthStore>();

        if (!Guid.TryParse(context.Principal?.FindFirstValue(PrincipalFactory.ClaimSessionId), out var sessionId))
        {
            context.RejectPrincipal();
            return;
        }

        var session = await store.FindSessionAsync(sessionId);
        if (session is null || session.RevokedAtUtc is not null ||
            session.LastSeenAtUtc.AddMinutes(settings.SessionIdleMinutes) <= clock.UtcNow)
        {
            context.RejectPrincipal();
            return;
        }

        var user = await store.FindUserByIdAsync(session.UserId);
        if (user is null || !user.IsActive)
        {
            context.RejectPrincipal();
            return;
        }

        var roles = await store.GetRolesAsync(user.Id);
        await store.TouchSessionAsync(session.Id, clock.UtcNow);

        context.ReplacePrincipal(PrincipalFactory.Build(user, roles, session.Id));
        context.ShouldRenew = true;
    }
}
