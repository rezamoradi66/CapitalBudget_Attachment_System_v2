using System.Threading.RateLimiting;
using Attachments.Api.Auth;
using Attachments.Api.Http;
using Attachments.Api.Idempotency;
using Attachments.Api.Middleware;
using Attachments.Core.Application;
using Attachments.Core.Domain;
using Attachments.Core.Services;
using Attachments.Infrastructure.Persistence;
using Attachments.Infrastructure.Storage;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Http.Features;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.RateLimiting;
using Microsoft.AspNetCore.Server.IIS;
using Microsoft.EntityFrameworkCore;
using Serilog;
using Serilog.Events;

var builder = WebApplication.CreateBuilder(args);
var environment = builder.Environment;
var configuration = builder.Configuration;

// ------------------------------------------------------------------ settings (built once at startup)

var attachmentsSection = configuration.GetSection("Attachments");
var sessionSettings = new SessionSettings
{
    SessionIdleMinutes = attachmentsSection.GetValue("SessionIdleMinutes", 30),
    MaxFailedLogins = attachmentsSection.GetValue("MaxFailedLogins", 5),
    LockoutMinutes = attachmentsSection.GetValue("LockoutMinutes", 15),
    LoginRateLimitPerMinute = attachmentsSection.GetValue("LoginRateLimitPerMinute", 10)
};

var configuredExtensions = attachmentsSection.GetSection("AllowedExtensions").GetChildren()
    .Select(child => child.Value)
    .Where(value => !string.IsNullOrWhiteSpace(value))
    .Select(value => value!.StartsWith('.') ? value.ToLowerInvariant() : $".{value.ToLowerInvariant()}")
    .ToHashSet(StringComparer.OrdinalIgnoreCase);
IReadOnlySet<string> allowedExtensions = configuredExtensions.Count > 0
    ? configuredExtensions
    : FileTypeRules.AllowedExtensions;

var limits = new AttachmentLimits
{
    MaxFileSizeBytes = attachmentsSection.GetValue("MaxFileSizeBytes", 1_048_576L),
    MaxFilesPerOwner = attachmentsSection.GetValue("MaxFilesPerOwner", 10),
    AllowedExtensions = allowedExtensions
};

// ------------------------------------------------------------------ startup safety guards

var binaryStoreMode = configuration["Attachments:BinaryStore"] ?? AttachmentBinaryStoreModes.Filestream;
if (environment.IsProduction() &&
    string.Equals(binaryStoreMode, AttachmentBinaryStoreModes.InMemory, StringComparison.OrdinalIgnoreCase))
{
    throw new InvalidOperationException(
        "ذخیره‌ساز «InMemory» فقط برای توسعه و آزمون مجاز است. در محیط عملیاتی مقدار «Attachments:BinaryStore» " +
        $"باید «{AttachmentBinaryStoreModes.Filestream}» یا «{AttachmentBinaryStoreModes.FilestreamViaSql}» باشد.");
}

// ------------------------------------------------------------------ transport/body size caps (v2 review, item 4)
// Every layer caps the request below the next one, so an oversized upload is stopped as
// early as possible: transport (Kestrel) → pre-body guard middleware (Content-Length) →
// multipart section limit → bounded read in the controller (abort at the file limit).
const long MultipartOverheadBytes = 64 * 1024;          // boundaries + part headers headroom
var maxRequestBodyBytes = limits.MaxFileSizeBytes + MultipartOverheadBytes;

builder.Services.Configure<FormOptions>(formOptions =>
{
    // Hard cap per multipart section: stops framework-level buffering (memory or disk spool)
    // at ≈ the file limit instead of the 128 MB default.
    formOptions.MultipartBodyLengthLimit = maxRequestBodyBytes;
    // Keep multipart buffering in memory only up to the cap (larger would spool to temp disk).
    formOptions.MemoryBufferThreshold = (int)Math.Min(maxRequestBodyBytes, int.MaxValue);
});

// Kestrel transport cap: requests above this are rejected before reaching the app
// (no-op under the test server; enforced on every real deployment).
builder.WebHost.ConfigureKestrel(kestrel =>
    kestrel.Limits.MaxRequestBodySize = maxRequestBodyBytes);

// IIS in-process hosting (ANCM) ignores Kestrel limits — cap the request there too,
// otherwise a mis-sized upload would stop at IIS defaults (30 MB) instead of ours.
builder.Services.Configure<IISServerOptions>(iis =>
    iis.MaxRequestBodySize = maxRequestBodyBytes);

// ------------------------------------------------------------------ logging (Serilog console + rolling file)

var logFilePath = Path.Combine(environment.ContentRootPath, "logs", "app-.log");
builder.Host.UseSerilog((context, loggerConfiguration) => loggerConfiguration
    .MinimumLevel.Information()
    .MinimumLevel.Override("Microsoft.AspNetCore", LogEventLevel.Warning)
    .MinimumLevel.Override("Microsoft.EntityFrameworkCore", LogEventLevel.Warning)
    .Enrich.FromLogContext()
    .WriteTo.Console()
    .WriteTo.File(
        logFilePath,
        rollingInterval: RollingInterval.Day,
        retainedFileCountLimit: 30,
        shared: true));

// ------------------------------------------------------------------ application services

builder.Services.AddSingleton(sessionSettings);
builder.Services.AddSingleton(limits);
builder.Services.AddSingleton<IClock, SystemClock>();
builder.Services.AddSingleton<IPasswordHasher, Pbkdf2PasswordHasher>();
builder.Services.AddSingleton<PermissionService>();
builder.Services.AddSingleton<FileTypeDetector>();
builder.Services.AddMemoryCache();
builder.Services.AddSingleton<IIdempotencyCache, MemoryCacheIdempotencyCache>();
builder.Services.AddScoped<AuthService>();
builder.Services.AddScoped<AttachmentService>();

// ------------------------------------------------------------------ persistence

// Fail-fast (v2 review, item 5): evaluated at STARTUP, not on first DB access.
// When a real database provider is configured and the connection string is
// missing/blank, the process must refuse to start — never continue silently on
// an unintended default connection.
var databaseProvider = configuration["Database:Provider"] ?? "SqlServer";
string? sqlConnectionString = null;
if (!string.Equals(databaseProvider, "InMemory", StringComparison.OrdinalIgnoreCase))
{
    sqlConnectionString = configuration.GetConnectionString("Default");
    if (string.IsNullOrWhiteSpace(sqlConnectionString))
        throw new InvalidOperationException(
            "رشته اتصال پایگاه‌داده پیکربندی نشده است. کلید «ConnectionStrings:Default» " +
            "(یا متغیر محیطی ConnectionStrings__Default) را تنظیم کنید — اجرا بدون پیکربندی صریح ادامه نمی‌یابد.");
}

builder.Services.AddDbContext<AppDbContext>(options =>
{
    if (string.Equals(databaseProvider, "InMemory", StringComparison.OrdinalIgnoreCase))
    {
        // Lab/test provider only (Database:Provider=InMemory) — never used in Production.
        options.UseInMemoryDatabase(configuration["Database:Name"] ?? "AttachmentsLab");
    }
    else
    {
        options.UseSqlServer(sqlConnectionString!);
    }
});

builder.Services.AddScoped<IAttachmentRepository, AttachmentRepository>();
builder.Services.AddScoped<IUserAuthStore, UserAuthStore>();
builder.Services.AddScoped<ISecurityEventWriter, SecurityEventWriter>();
builder.Services.AddScoped<IAttachmentWriteSessionFactory, AttachmentWriteSessionFactory>();
builder.Services.AddScoped<IAttachmentReadScopeFactory, BinaryReadScopeFactory>();
builder.Services.AddAttachmentBinaryStore(configuration); // Attachments:BinaryStore → Filestream | FilestreamViaSql | InMemory

// ------------------------------------------------------------------ MVC + uniform 400 ProblemDetails

builder.Services.AddControllers();
builder.Services.Configure<ApiBehaviorOptions>(options =>
{
    options.InvalidModelStateResponseFactory = context =>
    {
        var problem = new ProblemDetails
        {
            Type = $"https://cbm.capitalbudget/errors/{ErrorCodes.Validation}",
            Title = ErrorMessages.For(ErrorCodes.Validation),
            Status = StatusCodes.Status400BadRequest,
            Detail = "داده‌های ورودی نامعتبر است. موارد زیر را بررسی و اصلاح کنید.",
            Instance = context.HttpContext.Request.Path
        };
        problem.Extensions["errorCode"] = ErrorCodes.Validation;
        return new BadRequestObjectResult(problem);
    };
});

// ------------------------------------------------------------------ cookie session authentication

builder.Services
    .AddAuthentication(AuthSchemes.SessionCookie)
    .AddCookie(AuthSchemes.SessionCookie, options =>
    {
        options.Cookie.Name = AuthSchemes.SessionCookie;
        options.Cookie.HttpOnly = true;
        options.Cookie.SameSite = SameSiteMode.Lax;
        options.Cookie.IsEssential = true;
        options.Cookie.SecurePolicy = environment.IsProduction()
            ? CookieSecurePolicy.Always
            : CookieSecurePolicy.SameAsRequest;
        options.ExpireTimeSpan = TimeSpan.FromMinutes(sessionSettings.SessionIdleMinutes);
        options.SlidingExpiration = false; // sliding happens server-side via LastSeenAtUtc + ShouldRenew
        options.Events.OnValidatePrincipal = SessionPrincipalValidator.ValidateAsync;
        options.Events.OnRedirectToLogin = context =>
            ProblemResults.WriteAsync(
                context.HttpContext, StatusCodes.Status401Unauthorized,
                ErrorCodes.Unauthenticated, ErrorMessages.For(ErrorCodes.Unauthenticated));
        options.Events.OnRedirectToAccessDenied = context =>
            ProblemResults.WriteAsync(
                context.HttpContext, StatusCodes.Status403Forbidden,
                ErrorCodes.Forbidden, ErrorMessages.For(ErrorCodes.Forbidden));
    });
builder.Services.AddAuthorization();

// ------------------------------------------------------------------ login rate limiting (10/min per IP)

builder.Services.AddRateLimiter(options =>
{
    options.RejectionStatusCode = StatusCodes.Status429TooManyRequests;
    options.OnRejected = async (context, _) =>
        await ProblemResults.WriteAsync(
            context.HttpContext, StatusCodes.Status429TooManyRequests,
            ErrorCodes.RateLimited, ErrorMessages.For(ErrorCodes.RateLimited));
    options.AddPolicy(AuthSchemes.LoginRateLimitPolicy, httpContext =>
    {
        var partitionKey = httpContext.Connection.RemoteIpAddress?.ToString() ?? "unknown";
        var settings = httpContext.RequestServices.GetRequiredService<SessionSettings>();
        return RateLimitPartition.GetFixedWindowLimiter(partitionKey, _ => new FixedWindowRateLimiterOptions
        {
            PermitLimit = settings.LoginRateLimitPerMinute,
            Window = TimeSpan.FromMinutes(1),
            QueueLimit = 0
        });
    });
});

// ------------------------------------------------------------------ pipeline

var app = builder.Build();

app.UseSerilogRequestLogging();
app.UseMiddleware<SecurityHeadersMiddleware>();
app.UseMiddleware<ExceptionHandlingMiddleware>();
app.UseMiddleware<RequestSizeGuardMiddleware>(maxRequestBodyBytes);
app.UseAuthentication();
app.UseMiddleware<PasswordChangeRequiredMiddleware>();
app.UseRateLimiter();
app.UseAuthorization();

app.MapControllers();

// Anonymous health probe for load balancers / monitoring.
app.MapGet("/health", () => Results.Json(new { status = "Healthy" })).AllowAnonymous();

// Unmatched routes → uniform ProblemDetails (401 when anonymous, else 404).
app.MapFallback(async context =>
{
    if (context.User.Identity?.IsAuthenticated != true)
    {
        await ProblemResults.WriteAsync(
            context, StatusCodes.Status401Unauthorized,
            ErrorCodes.Unauthenticated, ErrorMessages.For(ErrorCodes.Unauthenticated));
        return;
    }

    await ProblemResults.WriteAsync(
        context, StatusCodes.Status404NotFound,
        ErrorCodes.NotFound, "مسیر درخواستی یافت نشد.");
});

Log.Information("Attachments API starting. Environment={Environment} BinaryStore={BinaryStore} MaxFileSizeBytes={MaxFileSizeBytes} MaxRequestBodyBytes={MaxRequestBodyBytes}",
    environment.EnvironmentName, binaryStoreMode, limits.MaxFileSizeBytes, maxRequestBodyBytes);

await app.RunAsync();

// Exposes the implicit Program class to WebApplicationFactory in the test project.
public partial class Program { }
