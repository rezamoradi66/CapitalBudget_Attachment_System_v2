using System.Text.Json;
using Attachments.Core.Domain;
using Attachments.Core.Domain.Entities;
using Attachments.Core.Services;

namespace Attachments.Core.Application;

/// <summary>
/// Authentication application service: login (+ lockouts), logout, me, change-password.
/// Sessions are server-side rows (dbo.AuthSessions) behind the CBM.Attach.Session cookie.
/// </summary>
public sealed class AuthService(
    IUserAuthStore store,
    IPasswordHasher hasher,
    ISecurityEventWriter events,
    IClock clock,
    SessionSettings settings)
{
    public async Task<LoginResult> LoginAsync(string? username, string? password, ClientContext client, CancellationToken ct = default)
    {
        if (string.IsNullOrWhiteSpace(username) || string.IsNullOrWhiteSpace(password))
            throw new ApiException(400, ErrorCodes.Validation, "نام کاربری و گذرواژه الزامی است.");

        username = username.Trim();
        // Lockout rows are keyed by a case/whitespace-normalized identity so that
        // “Admin”/“admin”/“ Admin ” permutations cannot bypass or fragment the counter
        // (multi-IP password spraying hardening — v2 review, item 2).
        var lockoutKey = username.ToLowerInvariant();
        var now = clock.UtcNow;
        var user = await store.FindUserByUsernameAsync(username, ct);
        var lockout = await store.FindLockoutAsync(lockoutKey, ct);

        // Already locked? Even correct credentials are rejected until the lock expires.
        if (lockout?.LockedUntilUtc is { } lockedUntil && lockedUntil > now)
        {
            await events.WriteAsync(EventTypes.LoginFailed, user?.Id, username, client.Ip, client.UserAgent,
                Json(new Dictionary<string, object?> { ["errorCode"] = ErrorCodes.LoginLocked, ["lockedUntilUtc"] = lockedUntil }), ct);
            throw new ApiException(401, ErrorCodes.LoginLocked, LockoutMessage(lockedUntil, now));
        }

        var valid = user is not null && user.IsActive && hasher.Verify(password, user.PasswordHash);
        if (!valid)
        {
            // Uniform failure response — never reveal whether the username exists.
            var failedCount = (lockout?.FailedCount ?? 0) + 1;
            var engagesLock = failedCount >= settings.MaxFailedLogins;
            var newLockedUntil = engagesLock ? now.AddMinutes(settings.LockoutMinutes) : lockout?.LockedUntilUtc;

            await store.SaveLockoutAsync(lockoutKey, failedCount, newLockedUntil, now, ct);
            await events.WriteAsync(EventTypes.LoginFailed, user?.Id, username, client.Ip, client.UserAgent,
                Json(new Dictionary<string, object?> { ["errorCode"] = ErrorCodes.InvalidCredentials, ["failedCount"] = failedCount }), ct);

            if (engagesLock && newLockedUntil is { } justLocked)
            {
                await events.WriteAsync(EventTypes.LoginLockout, user?.Id, username, client.Ip, client.UserAgent,
                    Json(new Dictionary<string, object?> { ["lockedUntilUtc"] = justLocked, ["failedCount"] = failedCount }), ct);
                throw new ApiException(401, ErrorCodes.LoginLocked, LockoutMessage(justLocked, now));
            }

            throw new ApiException(401, ErrorCodes.InvalidCredentials, ErrorMessages.For(ErrorCodes.InvalidCredentials));
        }

        // Success: reset lockout counter, create server-side session, emit cookie value via controller.
        await store.ClearLockoutAsync(lockoutKey, ct);
        var roles = await store.GetRolesAsync(user!.Id, ct);
        var session = new AuthSession
        {
            Id = Guid.NewGuid(),
            UserId = user.Id,
            Username = user.Username,
            CreatedAtUtc = now,
            LastSeenAtUtc = now
        };
        await store.CreateSessionAsync(session, ct);
        await events.WriteAsync(EventTypes.LoginSuccess, user.Id, user.Username, client.Ip, client.UserAgent,
            Json(new Dictionary<string, object?> { ["sessionId"] = session.Id }), ct);

        return new LoginResult(user, roles, session.Id);
    }

    public async Task LogoutAsync(Guid sessionId, ClientContext client, CancellationToken ct = default)
    {
        var session = await store.FindSessionAsync(sessionId, ct);
        if (session is not null && session.RevokedAtUtc is null)
        {
            await store.RevokeSessionAsync(sessionId, clock.UtcNow, ct);
            await events.WriteAsync(EventTypes.Logout, session.UserId, session.Username, client.Ip, client.UserAgent,
                Json(new Dictionary<string, object?> { ["sessionId"] = sessionId }), ct);
        }
    }

    public async Task<UserMeDto> MeAsync(UserContext user, CancellationToken ct = default)
    {
        var found = await store.FindUserByIdAsync(user.Id, ct)
            ?? throw new ApiException(401, ErrorCodes.Unauthenticated, ErrorMessages.For(ErrorCodes.Unauthenticated));
        var roles = await store.GetRolesAsync(found.Id, ct);
        return new UserMeDto(found.Id, found.Username, DisplayName(found), roles, found.MustChangePassword);
    }

    public async Task ChangePasswordAsync(
        UserContext actor, string? currentPassword, string? newPassword, ClientContext client, CancellationToken ct = default)
    {
        if (string.IsNullOrWhiteSpace(currentPassword) || string.IsNullOrWhiteSpace(newPassword))
            throw new ApiException(400, ErrorCodes.Validation, "گذرواژه فعلی و گذرواژه جدید الزامی است.");

        var user = await store.FindUserByIdAsync(actor.Id, ct)
            ?? throw new ApiException(401, ErrorCodes.Unauthenticated, ErrorMessages.For(ErrorCodes.Unauthenticated));

        if (!hasher.Verify(currentPassword, user.PasswordHash))
            throw new ApiException(400, ErrorCodes.CurrentPasswordInvalid, ErrorMessages.For(ErrorCodes.CurrentPasswordInvalid));

        PasswordPolicy.Enforce(newPassword, user.Username);

        user.PasswordHash = hasher.Hash(newPassword);
        user.MustChangePassword = false;
        await store.SaveUserAsync(user, ct);

        await events.WriteAsync(EventTypes.PasswordChanged, user.Id, user.Username, client.Ip, client.UserAgent,
            Json(new Dictionary<string, object?> { ["userId"] = user.Id }), ct);
    }

    private static string DisplayName(User user)
    {
        var full = string.Join(" ", new[] { user.FirstName, user.LastName }
            .Where(part => !string.IsNullOrWhiteSpace(part))
            .Select(part => part!.Trim()));
        return full.Length > 0 ? full : user.Username;
    }

    private string LockoutMessage(DateTime lockedUntilUtc, DateTime nowUtc)
    {
        var minutes = Math.Max(1, (int)Math.Ceiling((lockedUntilUtc - nowUtc).TotalMinutes));
        var clockTime = JalaliService.FormatTimeFromUtc(lockedUntilUtc);
        return $"{ErrorMessages.For(ErrorCodes.LoginLocked)} حدود {minutes} دقیقه دیگر (ساعت {clockTime} به وقت تهران) دوباره تلاش کنید.";
    }

    private static string Json(Dictionary<string, object?> details) =>
        JsonSerializer.Serialize(details, AttachmentsJson.Web);
}
