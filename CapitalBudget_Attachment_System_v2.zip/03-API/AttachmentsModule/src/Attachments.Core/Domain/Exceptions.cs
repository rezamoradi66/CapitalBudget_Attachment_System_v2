namespace Attachments.Core.Domain;

/// <summary>
/// HTTP-facing exceptions carrying a stable errorCode + HTTP status + Persian message.
/// The ExceptionHandlingMiddleware converts these into RFC 7807 ProblemDetails responses.
/// </summary>
public class ApiException : Exception
{
    public int StatusCode { get; }
    public string ErrorCode { get; }

    public ApiException(int statusCode, string errorCode, string message) : base(message)
    {
        StatusCode = statusCode;
        ErrorCode = errorCode;
    }
}

/// <summary>404 — resource missing (or intentionally not revealed to the caller).</summary>
public sealed class NotFoundException(string message)
    : ApiException(404, ErrorCodes.NotFound, message);

/// <summary>403 — the owner resource is visible/editable-restricted for this user.</summary>
public sealed class PermissionDeniedException(string message)
    : ApiException(403, ErrorCodes.PermissionDenied, message);

/// <summary>File rule violations: 413 FILE-TOO-LARGE, 415 type/mismatch, 422 empty/count/filename.</summary>
public sealed class FileRuleException(int statusCode, string errorCode, string message)
    : ApiException(statusCode, errorCode, message);
