namespace Attachments.Core.Domain;

/// <summary>Owner kinds for attachments. 1 = Request, 2 = Micro (ریزفهرست).</summary>
public enum OwnerType
{
    Request = 1,
    Micro = 2
}

/// <summary>Stable string codes for roles stored in dbo.UserRoles.RoleCode.</summary>
public static class RoleCodes
{
    public const string Admin = "admin";
    public const string Ceo = "ceo";
    public const string Budget = "budget";         // capital budget role (عمرانی)
    public const string BudgetCur = "budget_cur";  // current budget role (جاری)
    public const string Applicant = "applicant";
    public const string Committer = "committer";
    public const string Senior = "senior";
}

/// <summary>Request.BudKind values (nullable in DB: NULL means "kind not decided yet").</summary>
public static class BudKinds
{
    public const string Capital = "capital";
    public const string Current = "current";
}

/// <summary>Known request workflow statuses used by the permission rules.</summary>
public static class RequestStatuses
{
    public const string Draft = "draft";
    public const string Returned = "returned";
    public const string PendingCommitter = "pending_committer";
    public const string PendingSenior = "pending_senior";
}

/// <summary>Micro (ریزفهرست) AHP workflow statuses.</summary>
public static class AhpStatuses
{
    public const string Draft = "draft";
    public const string Pending = "pending";
    public const string Approved = "approved";
}

/// <summary>Allowed values for the Attachments:BinaryStore configuration key.</summary>
public static class AttachmentBinaryStoreModes
{
    public const string Filestream = "Filestream";             // SqlFileStream (PathName + transaction context)
    public const string FilestreamViaSql = "FilestreamViaSql"; // parameterized VARBINARY transfer (robust fallback)
    public const string InMemory = "InMemory";                 // tests/dev only — rejected in Production at startup
}

/// <summary>SecurityEvents.EventType values (see dbo.SecurityEvents).</summary>
public static class EventTypes
{
    public const string LoginSuccess = "login_success";
    public const string LoginFailed = "login_failed";
    public const string LoginLockout = "login_lockout";
    public const string Logout = "logout";
    public const string PasswordChanged = "password_changed";
    public const string AttachmentUpload = "attachment_upload";
    public const string AttachmentDownload = "attachment_download";
    public const string AttachmentDelete = "attachment_delete";
    public const string PermissionDenied = "permission_denied";
}
