using Attachments.Core.Domain.Entities;

namespace Attachments.Core.Domain;

/// <summary>Immutable view of the authenticated caller needed by the permission rules.</summary>
public sealed record UserContext(
    int Id,
    string Username,
    int? UnitId,
    int? ManagementId,
    IReadOnlySet<string> Roles);

/// <summary>Immutable snapshot of dbo.Requests used by the permission rules.</summary>
public sealed record RequestSnapshot(
    string? BudKind,
    string Status,
    int ApplicantId,
    int CreatedById,
    int? CommitterId,
    int? ManagementId,
    int? UnitId);

/// <summary>Immutable snapshot of dbo.RequestMicros used by the permission rules.</summary>
public sealed record MicroSnapshot(string? AhpStatus);

/// <summary>Client correlation info (IP + user agent) used for SecurityEvents.</summary>
public sealed record ClientContext(string Ip, string UserAgent);

public static class DomainMapper
{
    public static RequestSnapshot ToSnapshot(this Request request) =>
        new(request.BudKind, request.Status, request.ApplicantId, request.CreatedById,
            request.CommitterId, request.ManagementId, request.UnitId);

    public static MicroSnapshot ToSnapshot(this RequestMicro micro) => new(micro.AhpStatus);
}
