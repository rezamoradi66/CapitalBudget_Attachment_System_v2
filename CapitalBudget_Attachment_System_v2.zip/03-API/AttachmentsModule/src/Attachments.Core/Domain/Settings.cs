using Attachments.Core.Services;

namespace Attachments.Core.Domain;

/// <summary>Runtime limits snapshot built once at startup from the Attachments configuration section.</summary>
public sealed class AttachmentLimits
{
    /// <summary>Maximum attachment size in bytes (default 1 MiB = 1,048,576).</summary>
    public long MaxFileSizeBytes { get; init; } = 1_048_576;

    /// <summary>Maximum number of attachments per owner (request or micro).</summary>
    public int MaxFilesPerOwner { get; init; } = 10;

    /// <summary>Allowed extensions (operator-narrowable subset of the built-in whitelist).</summary>
    public IReadOnlySet<string> AllowedExtensions { get; init; } = FileTypeRules.AllowedExtensions;
}

/// <summary>Session / login-hardening settings snapshot built once at startup.</summary>
public sealed class SessionSettings
{
    /// <summary>Server-side sliding idle expiration for AuthSessions (minutes).</summary>
    public int SessionIdleMinutes { get; init; } = 30;

    /// <summary>Failed logins before the account locks.</summary>
    public int MaxFailedLogins { get; init; } = 5;

    /// <summary>Lock duration in minutes once MaxFailedLogins is reached.</summary>
    public int LockoutMinutes { get; init; } = 15;

    /// <summary>Fixed-window login rate limit per IP (logins per minute).</summary>
    public int LoginRateLimitPerMinute { get; init; } = 10;
}
