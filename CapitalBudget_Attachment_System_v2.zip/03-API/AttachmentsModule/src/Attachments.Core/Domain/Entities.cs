using System.ComponentModel.DataAnnotations.Schema;

namespace Attachments.Core.Domain.Entities;

/// <summary>dbo.Users</summary>
[Table("Users", Schema = "dbo")]
public class User
{
    public int Id { get; set; }
    public string Username { get; set; } = "";
    public string PasswordHash { get; set; } = "";
    public string? FirstName { get; set; }
    public string? LastName { get; set; }
    public bool IsActive { get; set; }
    public bool MustChangePassword { get; set; }
    public int? ManagementId { get; set; }
    public int? UnitId { get; set; }
}

/// <summary>dbo.UserRoles (composite key UserId + RoleCode)</summary>
[Table("UserRoles", Schema = "dbo")]
public class UserRole
{
    public int UserId { get; set; }
    public string RoleCode { get; set; } = "";
}

/// <summary>dbo.Requests</summary>
[Table("Requests", Schema = "dbo")]
public class Request
{
    public int Id { get; set; }
    public string Code { get; set; } = "";
    public string Title { get; set; } = "";
    public string? BudKind { get; set; }
    public string Status { get; set; } = "";
    public int ApplicantId { get; set; }
    public int? CommitterId { get; set; }
    public int? SeniorManagerId { get; set; }
    public int? ManagementId { get; set; }
    public int? UnitId { get; set; }
    public int CreatedById { get; set; }
}

/// <summary>dbo.RequestMicros</summary>
[Table("RequestMicros", Schema = "dbo")]
public class RequestMicro
{
    public int Id { get; set; }
    public int RequestId { get; set; }
    public int SeqNo { get; set; }
    public string Title { get; set; } = "";
    public string? AhpStatus { get; set; }
}

/// <summary>
/// dbo.RequestAttachments — metadata is mapped through EF Core.
/// IMPORTANT: <c>FileGuid</c> (UNIQUEIDENTIFIER, default NEWSEQUENTIALID(), ROWGUIDCOL) and
/// <c>FileContent</c> (VARBINARY(MAX) FILESTREAM) are intentionally NOT mapped. EF Core cannot
/// map FILESTREAM columns; both columns are handled exclusively by raw SQL inside the
/// IAttachmentBinaryStore implementations, within the very same database transaction used for
/// this metadata row. FileGuid is filled by the SQL Server default constraint on INSERT.
/// </summary>
[Table("RequestAttachments", Schema = "dbo")]
public class RequestAttachment
{
    public long Id { get; set; }
    public int OwnerType { get; set; }        // 1 = Request, 2 = Micro
    public long OwnerId { get; set; }
    public int? RequestId { get; set; }
    public int? MicroId { get; set; }
    public string OriginalName { get; set; } = "";
    public string? DisplayName { get; set; }
    public string Extension { get; set; } = "";
    public string ContentType { get; set; } = "";
    public long SizeBytes { get; set; }
    public string Sha256 { get; set; } = "";
    public string Status { get; set; } = "active";
    public int UploadedById { get; set; }
    public DateTime UploadedAt { get; set; }
    public string? UploadedAtJ { get; set; }
    public string? UploadedTimeJ { get; set; }

    // Not mapped (FILESTREAM / NEWSEQUENTIALID handled by raw SQL only):
    // public Guid FileGuid { get; set; }
    // public byte[] FileContent { get; set; }
}

/// <summary>dbo.SecurityEvents — audit trail. Details must never contain file content or physical paths.</summary>
[Table("SecurityEvents", Schema = "dbo")]
public class SecurityEvent
{
    public long Id { get; set; }
    public string EventType { get; set; } = "";
    public int? UserId { get; set; }
    public string? Username { get; set; }
    public string Ip { get; set; } = "";
    public string UserAgent { get; set; } = "";
    public string Details { get; set; } = "";
    public DateTime CreatedAt { get; set; }
}

/// <summary>dbo.LoginLockouts — upserted by Username; 5 failures → LockedUntil = now + 15 minutes.</summary>
[Table("LoginLockouts", Schema = "dbo")]
public class LoginLockout
{
    public string Username { get; set; } = "";
    public int FailedCount { get; set; }
    public DateTime? LockedUntilUtc { get; set; }
    public DateTime? LastFailedAtUtc { get; set; }
}

/// <summary>dbo.AuthSessions — server-side sessions backing the CBM.Attach.Session cookie.</summary>
[Table("AuthSessions", Schema = "dbo")]
public class AuthSession
{
    public Guid Id { get; set; }
    public int UserId { get; set; }
    public string Username { get; set; } = "";
    public DateTime CreatedAtUtc { get; set; }
    public DateTime LastSeenAtUtc { get; set; }
    public DateTime? RevokedAtUtc { get; set; }
}
