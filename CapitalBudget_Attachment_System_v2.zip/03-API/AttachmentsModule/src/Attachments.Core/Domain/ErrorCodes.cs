namespace Attachments.Core.Domain;

/// <summary>
/// Stable error codes + Persian user-facing messages. Every API error is emitted as an
/// RFC 7807 ProblemDetails whose "errorCode" extension is one of these constants and whose
/// "title"/"detail" are Persian professional texts.
/// </summary>
public static class ErrorCodes
{
    public const string Unauthenticated = "UNAUTHENTICATED";
    public const string InvalidCredentials = "INVALID-CREDENTIALS";
    public const string LoginLocked = "LOGIN-LOCKED";
    public const string SessionExpired = "SESSION-EXPIRED";
    public const string Forbidden = "FORBIDDEN";
    public const string PermissionDenied = "PERMISSION-DENIED";
    public const string PasswordChangeRequired = "PASSWORD-CHANGE-REQUIRED";
    public const string PasswordWeak = "PASSWORD-WEAK";
    public const string CurrentPasswordInvalid = "CURRENT-PASSWORD-INVALID";
    public const string FileEmpty = "FILE-EMPTY";
    public const string FileTooLarge = "FILE-TOO-LARGE";
    public const string FileTypeNotAllowed = "FILE-TYPE-NOT-ALLOWED";
    public const string FileContentMismatch = "FILE-CONTENT-MISMATCH";
    public const string FileCountExceeded = "FILE-COUNT-EXCEEDED";
    public const string FilenameInvalid = "FILENAME-INVALID";
    public const string NotFound = "NOT-FOUND";
    public const string Validation = "VALIDATION";
    public const string RateLimited = "RATE-LIMITED";
    public const string Internal = "INTERNAL";

    public static readonly IReadOnlyDictionary<string, string> PersianMessages = new Dictionary<string, string>
    {
        [Unauthenticated] = "احراز هویت انجام نشده است. لطفاً وارد سامانه شوید.",
        [InvalidCredentials] = "نام کاربری یا گذرواژه نادرست است.",
        [LoginLocked] = "به دلیل تلاش‌های ناموفق مکرر، ورود به حساب موقتاً مسدود شده است.",
        [SessionExpired] = "نشست کاری شما منقضی شده است. لطفاً دوباره وارد سامانه شوید.",
        [Forbidden] = "دسترسی به این عملیات برای شما مجاز نیست.",
        [PermissionDenied] = "شما مجوز لازم برای این عملیات را روی این مورد ندارید.",
        [PasswordChangeRequired] = "پیش از ادامه باید گذرواژه خود را تغییر دهید.",
        [PasswordWeak] = "گذرواژه جدید با سیاست امنیتی سامانه مطابقت ندارد.",
        [CurrentPasswordInvalid] = "گذرواژه فعلی نادرست است.",
        [FileEmpty] = "فایل پیوست خالی است و قابل بارگذاری نیست.",
        [FileTooLarge] = "حجم فایل از حد مجاز بیشتر است.",
        [FileTypeNotAllowed] = "نوع یا پسوند فایل در فهرست مجاز نیست.",
        [FileContentMismatch] = "محتوای فایل با پسوند اعلام‌شده مطابقت ندارد.",
        [FileCountExceeded] = "تعداد پیوست‌های مجاز برای این مورد به پایان رسیده است.",
        [FilenameInvalid] = "نام فایل نامعتبر است و قابل پاک‌سازی نیست.",
        [NotFound] = "مورد درخواستی یافت نشد.",
        [Validation] = "داده‌های ورودی نامعتبر است.",
        [RateLimited] = "تعداد درخواست‌ها بیش از حد مجاز است. لطفاً کمی بعد دوباره تلاش کنید.",
        [Internal] = "خطای داخلی سرور. با مدیر سامانه تماس بگیرید."
    };
}

/// <summary>Convenience accessor for the Persian message map.</summary>
public static class ErrorMessages
{
    public static string For(string errorCode) =>
        ErrorCodes.PersianMessages.TryGetValue(errorCode, out var message)
            ? message
            : ErrorCodes.PersianMessages[ErrorCodes.Internal];
}
