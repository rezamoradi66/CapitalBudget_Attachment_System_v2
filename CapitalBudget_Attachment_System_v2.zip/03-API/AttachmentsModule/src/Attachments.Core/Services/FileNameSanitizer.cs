using System.Text;
using System.Text.RegularExpressions;
using Attachments.Core.Domain;

namespace Attachments.Core.Services;

/// <summary>
/// Sanitizes user-provided file names for safe storage on Windows/SQL Server while
/// preserving Persian (and other Unicode) characters.
/// Rules implemented:
///  - strips any path components ("/", "\\", drive prefixes, ".." traversal segments);
///  - removes control characters and Windows-invalid characters (&lt; &gt; : " | ? *);
///  - renames reserved Windows device names (CON, PRN, AUX, NUL, COM1-9, LPT1-9) — with or
///    without extension — by prefixing an underscore;
///  - trims leading/trailing dots and spaces, collapses whitespace runs to a single space;
///  - enforces the 260-character limit while preserving the extension;
///  - throws (FILENAME-INVALID, 422) when nothing usable remains.
/// </summary>
public static partial class FileNameSanitizer
{
    public const int MaxLength = 260;

    private static readonly HashSet<string> ReservedNames = new(StringComparer.OrdinalIgnoreCase)
    {
        "CON", "PRN", "AUX", "NUL",
        "COM1", "COM2", "COM3", "COM4", "COM5", "COM6", "COM7", "COM8", "COM9",
        "LPT1", "LPT2", "LPT3", "LPT4", "LPT5", "LPT6", "LPT7", "LPT8", "LPT9"
    };

    private const string WindowsInvalidChars = "<>:\"|?*";

    [GeneratedRegex(@"\s+")]
    private static partial Regex WhitespaceRegex();

    /// <summary>Sanitizes a required file name; throws ApiException(422 FILENAME-INVALID) when unsanitizable.</summary>
    public static string Sanitize(string? rawFileName)
    {
        var result = SanitizeOrNull(rawFileName);
        if (string.IsNullOrWhiteSpace(result))
            throw new FileRuleException(422, ErrorCodes.FilenameInvalid, ErrorMessages.For(ErrorCodes.FilenameInvalid));
        return result;
    }

    /// <summary>Lenient variant for optional display names: returns null when nothing usable remains.</summary>
    public static string? SanitizeOrNull(string? rawFileName)
    {
        if (string.IsNullOrWhiteSpace(rawFileName))
            return null;

        // 1) Keep the bare file name only (defeats "../", "C:\..", "..\.." traversal).
        var name = rawFileName.Replace('\\', '/');
        var lastSlash = name.LastIndexOf('/');
        if (lastSlash >= 0)
            name = name[(lastSlash + 1)..];

        // 2) Remove control characters and Windows-invalid characters.
        var sb = new StringBuilder(name.Length);
        foreach (var ch in name)
        {
            if (char.IsControl(ch) || ch == 0x7F) continue;
            if (WindowsInvalidChars.Contains(ch)) continue;
            sb.Append(ch);
        }
        name = sb.ToString();

        // 3) Collapse whitespace runs and trim outer dots/spaces (Windows convention).
        name = WhitespaceRegex().Replace(name, " ").Trim(' ', '.');
        if (name.Length == 0)
            return null;

        // 4) Reserved device names (with or without extension) get an underscore prefix.
        var dot = name.LastIndexOf('.');
        var stem = dot > 0 ? name[..dot] : name;
        if (ReservedNames.Contains(stem))
            name = "_" + name;

        // 5) Enforce the 260-char cap while preserving the extension.
        if (name.Length > MaxLength)
        {
            dot = name.LastIndexOf('.');
            var hasSaneExtension = dot > 0 && name.Length - dot <= 21 && name.Length - dot > 1;
            if (hasSaneExtension)
            {
                var extension = name[dot..];
                var maxStem = MaxLength - extension.Length;
                var truncatedStem = name[..maxStem].TrimEnd(' ', '.');
                if (truncatedStem.Length == 0)
                    return null;
                name = truncatedStem + extension;
            }
            else
            {
                name = name[..MaxLength].TrimEnd(' ', '.');
            }
        }

        return name.Length == 0 ? null : name;
    }
}
