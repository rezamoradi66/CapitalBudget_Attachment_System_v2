using System.Globalization;
using System.Security.Cryptography;
using Attachments.Core.Domain;

namespace Attachments.Core.Services;

/// <summary>PBKDF2-SHA256 password hashing with the mandated storage format.</summary>
public interface IPasswordHasher
{
    /// <summary>Produces "PBKDF2$100000$&lt;saltB64&gt;$&lt;hashB64&gt;" (SHA-256, 100,000 iterations).</summary>
    string Hash(string password);

    bool Verify(string password, string storedHash);
}

public sealed class Pbkdf2PasswordHasher : IPasswordHasher
{
    public const int Iterations = 100_000;
    public const int SaltSizeBytes = 16;
    public const int KeySizeBytes = 32;

    public string Hash(string password)
    {
        var salt = RandomNumberGenerator.GetBytes(SaltSizeBytes);
        var key = Rfc2898DeriveBytes.Pbkdf2(password, salt, Iterations, HashAlgorithmName.SHA256, KeySizeBytes);
        return $"PBKDF2${Iterations}${Convert.ToBase64String(salt)}${Convert.ToBase64String(key)}";
    }

    public bool Verify(string password, string storedHash)
    {
        try
        {
            var parts = storedHash.Split('$');
            if (parts.Length != 4 || !string.Equals(parts[0], "PBKDF2", StringComparison.Ordinal))
                return false;
            var iterations = int.Parse(parts[1], CultureInfo.InvariantCulture);
            var salt = Convert.FromBase64String(parts[2]);
            var expected = Convert.FromBase64String(parts[3]);
            var actual = Rfc2898DeriveBytes.Pbkdf2(password, salt, iterations, HashAlgorithmName.SHA256, expected.Length);
            return CryptographicOperations.FixedTimeEquals(actual, expected);
        }
        catch (Exception ex) when (ex is FormatException or ArgumentOutOfRangeException)
        {
            return false;
        }
    }
}

/// <summary>
/// Password policy for change-password: min 8 chars, reject small built-in common-password
/// list (~30+ obvious ones), reject when equal to the username.
/// </summary>
public static class PasswordPolicy
{
    public static readonly IReadOnlySet<string> CommonPasswords =
        new HashSet<string>(StringComparer.OrdinalIgnoreCase)
        {
            "123456", "1234567", "12345678", "123456789", "1234567890", "12345",
            "112233", "121212", "123123", "123321", "111111", "000000", "654321", "666666", "888888",
            "password", "password1", "password123", "passw0rd", "p@ssword", "pass123", "pass1234",
            "qwerty", "qweerty", "qwerty123", "q1w2e3r4", "1q2w3e4r", "1qaz2wsx", "zaq12wsx",
            "abc123", "abcd1234", "abcdef", "abcdefg", "123qwe", "qwe123",
            "letmein", "welcome", "welcome1", "monkey", "dragon", "sunshine", "princess",
            "football", "iloveyou", "admin", "admin123", "admin1234", "root", "toor",
            "guest", "test", "test123", "user", "user123"
        };

    public static void Enforce(string? newPassword, string username)
    {
        var violations = new List<string>();
        if (string.IsNullOrWhiteSpace(newPassword) || newPassword.Length < 8)
            violations.Add("حداقل ۸ نویسه");
        if (!string.IsNullOrWhiteSpace(newPassword) && CommonPasswords.Contains(newPassword.Trim()))
            violations.Add("نباید گذرواژه‌ای بسیار رایج باشد");
        if (!string.IsNullOrWhiteSpace(newPassword)
            && !string.IsNullOrWhiteSpace(username)
            && string.Equals(newPassword.Trim(), username.Trim(), StringComparison.OrdinalIgnoreCase))
            violations.Add("نباید با نام کاربری یکسان باشد");

        if (violations.Count > 0)
            throw new ApiException(400, ErrorCodes.PasswordWeak,
                $"{ErrorMessages.For(ErrorCodes.PasswordWeak)} ({string.Join("، ", violations)})");
    }
}
