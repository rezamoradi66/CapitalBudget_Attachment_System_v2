using Attachments.Core.Domain;

namespace Attachments.Core.Services;

/// <summary>
/// Faithful implementation of the client-approved permission rules (reference app):
///
///  scopeAll(user)            = admin OR ceo role.
///  admin                     → view + edit everything.
///  ceo                       → view everything, edit nothing.
///  budget (capital)          → view all requests whose BudKind is NULL or 'capital';
///                              edit only kind-matching (BudKind not null and equal).
///  budget_cur (current)      → same with 'current'.
///  applicant                 → view/edit where ApplicantId==u.Id || CreatedById==u.Id;
///                              edit only while Status ∈ {draft, returned}.
///  committer                 → view where UnitId==u.UnitId;
///                              edit only when CommitterId==u.Id and Status=='pending_committer'.
///  senior                    → view where ManagementId==u.ManagementId; edit never.
///  MICRO                     → view = view(request);
///                              edit = edit(request) AND micro.AhpStatus != 'approved' (final decision lock).
///  Attachments               → download/view = visible(owner); upload/delete = editable(owner).
/// </summary>
public sealed class PermissionService
{
    public bool ScopeAll(UserContext user) =>
        Has(user, RoleCodes.Admin) || Has(user, RoleCodes.Ceo);

    public bool CanViewRequest(UserContext user, RequestSnapshot request)
    {
        if (ScopeAll(user))
            return true;

        foreach (var role in user.Roles)
        {
            switch (role)
            {
                case RoleCodes.Admin:
                case RoleCodes.Ceo:
                    return true;

                case RoleCodes.Budget
                    when request.BudKind is null || string.Equals(request.BudKind, BudKinds.Capital, StringComparison.OrdinalIgnoreCase):
                    return true;

                case RoleCodes.BudgetCur
                    when request.BudKind is null || string.Equals(request.BudKind, BudKinds.Current, StringComparison.OrdinalIgnoreCase):
                    return true;

                case RoleCodes.Applicant
                    when request.ApplicantId == user.Id || request.CreatedById == user.Id:
                    return true;

                case RoleCodes.Committer
                    when request.UnitId is not null && user.UnitId == request.UnitId:
                    return true;

                case RoleCodes.Senior
                    when request.ManagementId is not null && user.ManagementId == request.ManagementId:
                    return true;
            }
        }

        return false;
    }

    public bool CanEditRequest(UserContext user, RequestSnapshot request)
    {
        foreach (var role in user.Roles)
        {
            switch (role)
            {
                case RoleCodes.Admin:
                    return true;

                case RoleCodes.Budget
                    when request.BudKind is not null && string.Equals(request.BudKind, BudKinds.Capital, StringComparison.OrdinalIgnoreCase):
                    return true;

                case RoleCodes.BudgetCur
                    when request.BudKind is not null && string.Equals(request.BudKind, BudKinds.Current, StringComparison.OrdinalIgnoreCase):
                    return true;

                case RoleCodes.Applicant
                    when (request.ApplicantId == user.Id || request.CreatedById == user.Id)
                         && (string.Equals(request.Status, RequestStatuses.Draft, StringComparison.OrdinalIgnoreCase)
                             || string.Equals(request.Status, RequestStatuses.Returned, StringComparison.OrdinalIgnoreCase)):
                    return true;

                case RoleCodes.Committer
                    when request.CommitterId == user.Id
                         && string.Equals(request.Status, RequestStatuses.PendingCommitter, StringComparison.OrdinalIgnoreCase):
                    return true;

                // ceo / senior grant no edit rights by design.
            }
        }

        return false;
    }

    public bool CanViewMicro(UserContext user, RequestSnapshot request, MicroSnapshot micro) =>
        CanViewRequest(user, request);

    /// <summary>
    /// Micro edit requires the AHP final decision not to be 'approved' (final-decision lock) —
    /// EXCEPT admin, mirroring the reference app's admin-first rule (canEditProgram, line 1884:
    /// «hasRole(u,'admin') → return true» bypasses every state condition).
    /// </summary>
    public bool CanEditMicro(UserContext user, RequestSnapshot request, MicroSnapshot micro)
    {
        if (Has(user, RoleCodes.Admin))
            return CanEditRequest(user, request);

        return CanEditRequest(user, request) &&
               !string.Equals(micro.AhpStatus, AhpStatuses.Approved, StringComparison.OrdinalIgnoreCase);
    }

    private static bool Has(UserContext user, string role) => user.Roles.Contains(role);
}
