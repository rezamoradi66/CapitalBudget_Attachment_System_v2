using System.Security.Cryptography;

namespace Attachments.Core.Services;

/// <summary>
/// Cryptographically secure initial-password generator (CSPRNG, no fixed/seeded values).
/// Used to create the first credential of a user (e.g. the lab admin seed) as a random
/// secret that is shown ONCE to the operator and must be changed at first login
/// (MustChangePassword = 1 — decision D-01). Nothing here is deterministic and no
/// default password exists anywhere in code, scripts or documentation.
/// </summary>
public static class InitialPasswordGenerator
{
    /// <summary>Generated password length (20 chars).</summary>
    public const int Length = 20;

    /// <summary>
    /// 68-character alphabet: digits, lower/upper ASCII letters and the symbols !@#$%^&amp;*.
    /// Ambiguous glyphs (0/O, 1/l/I, 5/S, 8/B) are excluded so the printed password can be
    /// read aloud or re-typed without confusion.
    /// </summary>
    public const string Alphabet =
        "234679ACDEFGHJKLMNPQRTUVWXYacdefghjkmnpqrtuvwxy" +
        "ABCDEFGHJKLMNPQRSTUVWXYZ!@#$%^&*";

    /// <summary>Generates a random password: <see cref="Length"/> chars drawn by CSPRNG from <see cref="Alphabet"/>.</summary>
    public static string Generate() => new(RandomNumberGenerator.GetItems<char>(Alphabet, Length));

    /// <summary>
    /// Generates a random password AND its storage hash in one call
    /// ("PBKDF2$100000$&lt;saltB64&gt;$&lt;hashB64&gt;" — the only accepted storage format, D-01).
    /// The password is returned exactly once; only the salted PBKDF2 hash is persisted.
    /// </summary>
    public static (string Password, string Hash) GenerateWithHash()
    {
        var password = Generate();
        return (password, new Pbkdf2PasswordHasher().Hash(password));
    }
}
