using Attachments.Core.Domain;

namespace Attachments.Core.Services;

/// <summary>
/// Size-control guard for uploads: enforces <see cref="AttachmentLimits.MaxFileSizeBytes"/>
/// DURING the read, not after it. The stream is consumed in 64 KB chunks and aborted as soon
/// as the limit is exceeded, so an oversized body is never fully read into memory
/// (application memory stays bounded at ≈ limit + one chunk, reviewed in v2).
/// </summary>
public static class UploadLimitsGuard
{
    /// <summary>Chunk size used for the bounded copy (64 KB).</summary>
    public const int CopyChunkBytes = 64 * 1024;

    /// <summary>Uniform Persian message for every FILE-TOO-LARGE path (controller guard + service check).</summary>
    public static string FileTooLargeMessage(long maxBytes) =>
        $"{ErrorMessages.For(ErrorCodes.FileTooLarge)} حداکثر حجم مجاز: {maxBytes:N0} بایت.";

    /// <summary>Chunked, limit-aborting copy of any stream (unit-testable core). The ASP.NET
    /// IFormFile wrapper that calls this lives in the Api layer (Core stays framework-free).</summary>
    public static async Task<byte[]> ReadStreamAsync(Stream stream, long maxBytes, CancellationToken cancellationToken = default)
    {
        ArgumentNullException.ThrowIfNull(stream);
        var capacity = maxBytes is > 0 and <= int.MaxValue ? (int)maxBytes : 0;
        await using var bounded = new MemoryStream(capacity);
        var chunk = new byte[CopyChunkBytes];
        long total = 0;
        int read;
        while ((read = await stream.ReadAsync(chunk.AsMemory(0, chunk.Length), cancellationToken)) > 0)
        {
            total += read;
            if (total > maxBytes)
                throw new FileRuleException(413, ErrorCodes.FileTooLarge, FileTooLargeMessage(maxBytes));
            bounded.Write(chunk, 0, read);
        }

        return bounded.ToArray();
    }
}
