using Attachments.Core.Domain;
using Attachments.Core.Services;

using Xunit;

namespace Attachments.Tests;

public class FileTypeDetectorTests
{
    private readonly FileTypeDetector _detector = new();

    [Theory]
    [InlineData(".pdf")]
    [InlineData(".png")]
    [InlineData(".jpg")]
    [InlineData(".webp")]
    [InlineData(".docx")]
    [InlineData(".txt")]
    public void ValidSignaturePasses(string extension)
    {
        var bytes = TestFiles.For(extension);

        _detector.EnsureExtensionAllowed($"report{extension}");
        _detector.EnsureSignatureMatches($"report{extension}", bytes);
    }

    [Fact]
    public void ExeContentNamedPdf_IsRejectedWithContentMismatch()
    {
        var exception = Assert.Throws<FileRuleException>(
            () => _detector.EnsureSignatureMatches("setup.pdf", TestFiles.Exe()));

        Assert.Equal(415, exception.StatusCode);
        Assert.Equal(ErrorCodes.FileContentMismatch, exception.ErrorCode);
    }

    [Fact]
    public void UnknownExtension_IsRejectedWithTypeNotAllowed()
    {
        var exception = Assert.Throws<FileRuleException>(
            () => _detector.EnsureExtensionAllowed("virus.exe"));

        Assert.Equal(415, exception.StatusCode);
        Assert.Equal(ErrorCodes.FileTypeNotAllowed, exception.ErrorCode);
    }

    [Fact]
    public void TxtWithNullBytes_IsRejectedWithContentMismatch()
    {
        var exception = Assert.Throws<FileRuleException>(
            () => _detector.EnsureSignatureMatches("notes.txt", TestFiles.TxtWithNullByte()));

        Assert.Equal(415, exception.StatusCode);
        Assert.Equal(ErrorCodes.FileContentMismatch, exception.ErrorCode);
    }

    [Fact]
    public void EmptyPdfBytes_AreRejected()
    {
        var exception = Assert.Throws<FileRuleException>(
            () => _detector.EnsureSignatureMatches("empty.pdf", []));

        Assert.Equal(415, exception.StatusCode);
        Assert.Equal(ErrorCodes.FileContentMismatch, exception.ErrorCode);
    }

    [Fact]
    public void PngBytesDeclaredAsPdf_AreRejected()
    {
        var exception = Assert.Throws<FileRuleException>(
            () => _detector.EnsureSignatureMatches("image.pdf", TestFiles.Png()));

        Assert.Equal(ErrorCodes.FileContentMismatch, exception.ErrorCode);
    }
}
