using Attachments.Core.Services;

using Xunit;

namespace Attachments.Tests;

public class JalaliServiceTests
{
    [Theory]
    [InlineData(2026, 10, 24, "1405/08/02")]   // task-mandated anchor
    [InlineData(2025, 3, 21, "1404/01/01")]    // Nowruz of 1404 (1403 is a leap year)
    [InlineData(2024, 3, 20, "1403/01/01")]    // Nowruz of 1403
    [InlineData(2025, 9, 23, "1404/07/01")]    // Mehr 1st = day 187
    [InlineData(2026, 3, 20, "1404/12/29")]    // ordinary Esfand end (1404 not leap)
    public void FormatDate_ConvertsGregorianToJalali(int gy, int gm, int gd, string expected)
    {
        Assert.Equal(expected, JalaliService.FormatDate(new DateTime(gy, gm, gd)));
    }

    [Fact]
    public void FormatTime_ProducesHHmm()
    {
        Assert.Equal("14:05", JalaliService.FormatTime(new DateTime(2026, 10, 24, 14, 5, 9)));
        Assert.Equal("00:07", JalaliService.FormatTime(new DateTime(2026, 10, 24, 0, 7, 0)));
    }

    [Fact]
    public void FormatTimeFromUtc_ConvertsToTehranTime()
    {
        // 09:30 UTC = 13:00 Tehran (+03:30, no DST since 2022)
        Assert.Equal("13:00", JalaliService.FormatTimeFromUtc(new DateTime(2026, 10, 24, 9, 30, 0, DateTimeKind.Utc)));
    }

    [Fact]
    public void FormatDateFromUtc_RollsOverAtTehranMidnight()
    {
        // 2026-10-24T20:30Z = 2026-10-25T00:00 Tehran → 1405/08/03
        Assert.Equal("1405/08/03", JalaliService.FormatDateFromUtc(new DateTime(2026, 10, 24, 20, 30, 0, DateTimeKind.Utc)));
    }

    [Fact]
    public void ToJalali_RoundTripsThroughKnownPairs()
    {
        var (year, month, day) = JalaliService.ToJalali(2026, 10, 24);
        Assert.Equal((1405, 8, 2), (year, month, day));
    }
}
