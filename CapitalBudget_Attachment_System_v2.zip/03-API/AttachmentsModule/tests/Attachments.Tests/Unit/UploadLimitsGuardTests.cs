using Attachments.Core.Domain;
using Attachments.Core.Services;
using Xunit;

namespace Attachments.Tests.Unit;

/// <summary>
/// Tests for the v2 bounded upload reader (review item 4): the stream is consumed in
/// chunks and ABORTED as soon as the configured limit is exceeded — an oversized body
/// is never fully read/buffered, and the failure surfaces as the stable 413
/// FILE-TOO-LARGE contract.
/// </summary>
public class UploadLimitsGuardTests
{
    private const long OneMiB = 1_048_576;

    private static byte[] Bytes(long size)
    {
        var data = new byte[size];
        new Random(42).NextBytes(data); // deterministic content for comparisons
        return data;
    }

    [Fact]
    public async Task ReadStream_ExactlyAtLimit_ReadsEverything()
    {
        var data = Bytes(OneMiB);
        await using var stream = new MemoryStream(data);

        var result = await UploadLimitsGuard.ReadStreamAsync(stream, OneMiB);

        Assert.Equal(data, result);
    }

    [Fact]
    public async Task ReadStream_OneByteBeyondLimit_Throws413FileTooLarge()
    {
        var data = Bytes(OneMiB + 1);
        await using var stream = new MemoryStream(data);

        var exception = await Assert.ThrowsAsync<FileRuleException>(
            () => UploadLimitsGuard.ReadStreamAsync(stream, OneMiB));

        Assert.Equal(413, exception.StatusCode);
        Assert.Equal(ErrorCodes.FileTooLarge, exception.ErrorCode);
        Assert.Contains("1,048,576", exception.Message); // uniform Persian message carries the limit
    }

    [Fact]
    public async Task ReadStream_FarBeyondLimit_AbortsEarly_WithoutBufferingWholeBody()
    {
        // 8 MiB source vs a 1 MiB limit: the guard must stop reading around the limit
        // instead of consuming the entire 8 MiB (the v1 behavior this review fixes).
        var data = Bytes(8 * OneMiB);
        await using var countingStream = new CountingStream(new MemoryStream(data));

        await Assert.ThrowsAsync<FileRuleException>(
            () => UploadLimitsGuard.ReadStreamAsync(countingStream, OneMiB));

        // At most limit + one 64 KB chunk was ever pulled from the source.
        Assert.True(countingStream.BytesRead <= OneMiB + UploadLimitsGuard.CopyChunkBytes,
            $"guard read {countingStream.BytesRead:N0} bytes — must abort near the limit, not read the whole body.");
    }

    [Fact]
    public async Task ReadStream_EmptyInput_ReturnsEmptyArray()
    {
        await using var stream = new MemoryStream([]);

        var result = await UploadLimitsGuard.ReadStreamAsync(stream, OneMiB);

        Assert.Empty(result);
    }

    [Fact]
    public async Task ReadStream_SmallBody_ReadsExactly()
    {
        var data = Bytes(123_456);
        await using var stream = new MemoryStream(data);

        var result = await UploadLimitsGuard.ReadStreamAsync(stream, OneMiB);

        Assert.Equal(data, result);
    }

    /// <summary>Wrapper that counts how many bytes were pulled from the source stream.</summary>
    private sealed class CountingStream(Stream inner) : Stream
    {
        public long BytesRead { get; private set; }

        public override bool CanRead => inner.CanRead;
        public override bool CanSeek => inner.CanSeek;
        public override bool CanWrite => inner.CanWrite;
        public override long Length => inner.Length;
        public override long Position { get => inner.Position; set => inner.Position = value; }

        public override int Read(byte[] buffer, int offset, int count)
        {
            var read = inner.Read(buffer, offset, count);
            BytesRead += read;
            return read;
        }

        public override async ValueTask<int> ReadAsync(Memory<byte> buffer, CancellationToken cancellationToken = default)
        {
            var read = await inner.ReadAsync(buffer, cancellationToken);
            BytesRead += read;
            return read;
        }

        public override void Flush() => inner.Flush();
        public override long Seek(long offset, SeekOrigin origin) => inner.Seek(offset, origin);
        public override void SetLength(long value) => inner.SetLength(value);
        public override void Write(byte[] buffer, int offset, int count) => inner.Write(buffer, offset, count);
    }
}
