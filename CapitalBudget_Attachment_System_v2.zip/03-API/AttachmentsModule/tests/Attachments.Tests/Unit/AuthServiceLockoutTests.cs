using Attachments.Core.Application;
using Attachments.Core.Domain;
using Attachments.Core.Domain.Entities;
using Attachments.Core.Services;
using Xunit;

namespace Attachments.Tests.Unit;

/// <summary>
/// Service-level lockout tests (v2 review, item 2): the 5-failures → 15-minute lockout
/// must be enforced PER ACCOUNT — independent of how many different client IPs the
/// attempts come from — and the counter must be keyed by a normalized username so
/// case/whitespace permutations cannot bypass or fragment it.
/// Uses the real Pbkdf2PasswordHasher with an in-memory fake store (no HTTP, no DB).
/// </summary>
public class AuthServiceLockoutTests
{
    private static readonly DateTime BaseTime = new(2026, 1, 1, 8, 0, 0, DateTimeKind.Utc);

    private sealed class FixedClock(DateTime utcNow) : IClock
    {
        public DateTime UtcNow => utcNow;
    }

    private sealed class SilentEventWriter : ISecurityEventWriter
    {
        public List<string> Events { get; } = [];

        public Task WriteAsync(string eventType, int? userId, string? username, string ip, string userAgent,
            string detailsJson, CancellationToken cancellationToken = default)
        {
            Events.Add(eventType);
            return Task.CompletedTask;
        }
    }

    /// <summary>In-memory IUserAuthStore backed by a dictionary — no database involved.</summary>
    private sealed class FakeUserAuthStore : IUserAuthStore
    {
        public Dictionary<string, User> Users { get; } = new();
        public Dictionary<string, LoginLockout> Lockouts { get; } = new(StringComparer.Ordinal);
        public List<AuthSession> Sessions { get; } = [];

        public Task<User?> FindUserByUsernameAsync(string username, CancellationToken cancellationToken = default) =>
            Task.FromResult(Users.TryGetValue(username, out var user) ? user : null);

        public Task<User?> FindUserByIdAsync(int id, CancellationToken cancellationToken = default) =>
            Task.FromResult(Users.Values.FirstOrDefault(u => u.Id == id));

        public Task<List<string>> GetRolesAsync(int userId, CancellationToken cancellationToken = default) =>
            Task.FromResult(new List<string> { RoleCodes.Applicant });

        public Task<LoginLockout?> FindLockoutAsync(string username, CancellationToken cancellationToken = default) =>
            Task.FromResult(Lockouts.TryGetValue(username, out var row) ? row : null);

        public Task SaveLockoutAsync(string username, int failedCount, DateTime? lockedUntilUtc,
            DateTime lastFailedAtUtc, CancellationToken cancellationToken = default)
        {
            Lockouts[username] = new LoginLockout
            {
                Username = username,
                FailedCount = failedCount,
                LockedUntilUtc = lockedUntilUtc,
                LastFailedAtUtc = lastFailedAtUtc
            };
            return Task.CompletedTask;
        }

        public Task ClearLockoutAsync(string username, CancellationToken cancellationToken = default)
        {
            Lockouts.Remove(username);
            return Task.CompletedTask;
        }

        public Task SaveUserAsync(User user, CancellationToken cancellationToken = default) => Task.CompletedTask;

        public Task<AuthSession> CreateSessionAsync(AuthSession session, CancellationToken cancellationToken = default)
        {
            Sessions.Add(session);
            return Task.FromResult(session);
        }

        public Task<AuthSession?> FindSessionAsync(Guid id, CancellationToken cancellationToken = default) =>
            Task.FromResult(Sessions.FirstOrDefault(s => s.Id == id));

        public Task TouchSessionAsync(Guid id, DateTime lastSeenAtUtc, CancellationToken cancellationToken = default) => Task.CompletedTask;

        public Task RevokeSessionAsync(Guid id, DateTime revokedAtUtc, CancellationToken cancellationToken = default) => Task.CompletedTask;
    }

    private static (FakeUserAuthStore Store, AuthService Service, SilentEventWriter Events) Build()
    {
        var store = new FakeUserAuthStore();
        var events = new SilentEventWriter();
        var clock = new FixedClock(BaseTime);
        var service = new AuthService(store, new Pbkdf2PasswordHasher(), events, clock, new SessionSettings());
        store.Users["admin"] = new User
        {
            Id = 7, Username = "admin", PasswordHash = new Pbkdf2PasswordHasher().Hash("S3cure!Pass-2026"),
            IsActive = true
        };
        return (store, service, events);
    }

    [Fact]
    public async Task Lockout_EngagesAtFifthFailure_ForFifteenMinutes()
    {
        var (store, service, events) = Build();

        for (var attempt = 1; attempt <= 4; attempt++)
            await Assert.ThrowsAsync<ApiException>(() =>
                service.LoginAsync("admin", $"wrong-{attempt}", new ClientContext("10.0.0.1", "test")));

        var fifth = await Assert.ThrowsAsync<ApiException>(() =>
            service.LoginAsync("admin", "wrong-5", new ClientContext("10.0.0.1", "test")));
        Assert.Equal(ErrorCodes.LoginLocked, fifth.ErrorCode);

        var row = Assert.Single(store.Lockouts.Values);
        Assert.Equal("admin", row.Username);                       // normalized key == lowercase username
        Assert.Equal(5, row.FailedCount);
        Assert.Equal(BaseTime.AddMinutes(15), row.LockedUntilUtc); // SessionSettings defaults: 5 / 15
        Assert.Contains(events.Events, e => e == EventTypes.LoginLockout); // lockout event emitted
    }

    [Fact]
    public async Task Lockout_RejectsEvenCorrectPassword_UntilLockExpires()
    {
        var (store, service, _) = Build();
        await FailFiveTimes(service);

        var locked = await Assert.ThrowsAsync<ApiException>(() =>
            service.LoginAsync("admin", "S3cure!Pass-2026", new ClientContext("10.0.0.2", "test")));
        Assert.Equal(ErrorCodes.LoginLocked, locked.ErrorCode);

        // Simulate the passage of the 15-minute window.
        store.Lockouts["admin"].LockedUntilUtc = BaseTime.AddMinutes(-1);
        var ok = await service.LoginAsync("admin", "S3cure!Pass-2026", new ClientContext("10.0.0.2", "test"));
        Assert.Equal(7, ok.User.Id);
    }

    [Fact]
    public async Task Lockout_CountsAttempts_AcrossDifferentClientIps()
    {
        var (_, service, _) = Build();

        // Each attempt comes from a DIFFERENT source IP — the per-account counter must still accumulate.
        var ips = new[] { "10.0.0.1", "10.0.0.2", "172.16.0.9", "192.168.1.77", "88.15.200.3" };
        for (var attempt = 0; attempt < 4; attempt++)
        {
            var ex = await Assert.ThrowsAsync<ApiException>(() =>
                service.LoginAsync("admin", $"spray-{attempt}", new ClientContext(ips[attempt], "test")));
            Assert.Equal(ErrorCodes.InvalidCredentials, ex.ErrorCode);
        }

        var fifth = await Assert.ThrowsAsync<ApiException>(() =>
            service.LoginAsync("admin", "spray-4", new ClientContext(ips[4], "test")));
        Assert.Equal(ErrorCodes.LoginLocked, fifth.ErrorCode);
    }

    [Fact]
    public async Task Lockout_Key_IsCaseAndWhitespaceInsensitive()
    {
        var (store, service, _) = Build();

        // Fail 3 times with one spelling…
        for (var attempt = 1; attempt <= 3; attempt++)
            await Assert.ThrowsAsync<ApiException>(() =>
                service.LoginAsync("admin", $"bad-{attempt}", new ClientContext("10.0.0.1", "test")));

        // …and twice with case/whitespace permutations — the lock must still engage.
        await Assert.ThrowsAsync<ApiException>(() =>
            service.LoginAsync("ADMIN", "bad-4", new ClientContext("10.0.0.2", "test")));
        var fifth = await Assert.ThrowsAsync<ApiException>(() =>
            service.LoginAsync(" Admin ", "bad-5", new ClientContext("10.0.0.3", "test")));
        Assert.Equal(ErrorCodes.LoginLocked, fifth.ErrorCode);

        // Exactly ONE normalized lockout row exists for the account.
        var row = Assert.Single(store.Lockouts.Values);
        Assert.Equal("admin", row.Username);
        Assert.Equal(5, row.FailedCount);
    }

    [Fact]
    public async Task SuccessfulLogin_ResetsTheFailedCounter()
    {
        var (store, service, _) = Build();

        for (var attempt = 1; attempt <= 4; attempt++)
            await Assert.ThrowsAsync<ApiException>(() =>
                service.LoginAsync("admin", $"bad-{attempt}", new ClientContext("10.0.0.1", "test")));

        await service.LoginAsync("admin", "S3cure!Pass-2026", new ClientContext("10.0.0.1", "test"));
        Assert.Empty(store.Lockouts); // counter cleared on success
    }

    private static async Task FailFiveTimes(AuthService service)
    {
        for (var attempt = 1; attempt <= 5; attempt++)
            await Assert.ThrowsAsync<ApiException>(() =>
                service.LoginAsync("admin", $"wrong-{attempt}", new ClientContext("10.0.0.1", "test")));
    }
}
