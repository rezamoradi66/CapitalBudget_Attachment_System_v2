using System.Text.RegularExpressions;
using Attachments.Core.Services;
using Xunit;

namespace Attachments.Tests.Unit;

/// <summary>
/// Tests for the v2 secure initial-password generator (review item 1):
/// every generated credential must satisfy the password policy, use only the
/// documented alphabet, carry the exact storage-hash format, verify against the
/// real hasher, and never repeat (no fixed/seeded values anywhere).
/// </summary>
public class InitialPasswordGeneratorTests
{
    private const int PasswordLength = InitialPasswordGenerator.Length;
    private static readonly Regex HashFormat =
        new(@"^PBKDF2\$100000\$[A-Za-z0-9+/]{22}==\$[A-Za-z0-9+/]{43}=$", RegexOptions.Compiled);

    [Fact]
    public void GeneratedPassword_HasDocumentedLength_AndAlphabetOnly()
    {
        for (var i = 0; i < 100; i++)
        {
            var password = InitialPasswordGenerator.Generate();
            Assert.Equal(PasswordLength, password.Length);
            Assert.All(password, c => Assert.Contains(c, InitialPasswordGenerator.Alphabet));
        }
    }

    [Fact]
    public void GeneratedPasswords_SatisfyPasswordPolicy()
    {
        var hasher = new Pbkdf2PasswordHasher();
        for (var i = 0; i < 100; i++)
        {
            var (password, _) = InitialPasswordGenerator.GenerateWithHash();

            var exception = Record.Exception(() => PasswordPolicy.Enforce(password, "admin"));
            Assert.Null(exception);                     // ≥8 chars, not in the common list, ≠ username
            Assert.True(hasher.Verify(password, hasher.Hash(password)));
        }
    }

    [Fact]
    public void GeneratedHash_MatchesTheExactStorageFormat_AndVerifies()
    {
        var hasher = new Pbkdf2PasswordHasher();
        for (var i = 0; i < 25; i++)
        {
            var (password, hash) = InitialPasswordGenerator.GenerateWithHash();

            Assert.Matches(HashFormat, hash);           // PBKDF2$100000$<24-char salt>==$<44-char key>=
            Assert.True(hasher.Verify(password, hash)); // real hasher accepts it
            Assert.False(hasher.Verify("wrong-password", hash));
        }
    }

    [Fact]
    public void GeneratedCredentials_AreUniqueAcrossCalls()
    {
        var hashes = new HashSet<string>();
        for (var i = 0; i < 200; i++)
            Assert.True(hashes.Add(InitialPasswordGenerator.Generate()),
                "CSPRNG generator produced a duplicate password — must never happen.");
    }
}
