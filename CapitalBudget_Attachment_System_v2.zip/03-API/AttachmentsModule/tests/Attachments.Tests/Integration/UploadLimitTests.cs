using System.Net;
using Attachments.Core.Domain;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.AspNetCore.Mvc.Testing;
using Microsoft.AspNetCore.TestHost;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Xunit;

namespace Attachments.Tests.Integration;

/// <summary>
/// Dedicated factory with a 4 KB upload limit (own host + own InMemory database)
/// to exercise the layered upload size guards quickly. Login rate limit is raised so
/// the limiter never interferes; lockout defaults (5/15) remain untouched.
/// </summary>
public sealed class UploadLimitFactory : WebApplicationFactory<Program>, IAsyncLifetime
{
    public const string DatabaseName = "attachments-it-ul";
    public const int SmallLimitBytes = 4096;

    protected override void ConfigureWebHost(IWebHostBuilder builder)
    {
        builder.UseEnvironment("Development");
        builder.UseSetting("Database:Provider", "InMemory");
        builder.UseSetting("Database:Name", DatabaseName);
        builder.UseSetting("Attachments:BinaryStore", "InMemory");
        builder.UseSetting("Attachments:LoginRateLimitPerMinute", "10000");
        builder.UseSetting("Attachments:MaxFileSizeBytes", SmallLimitBytes.ToString());
        builder.ConfigureAppConfiguration((_, configuration) =>
        {
            configuration.AddInMemoryCollection(new Dictionary<string, string?>
            {
                ["Database:Provider"] = "InMemory",
                ["Database:Name"] = DatabaseName,
                ["Attachments:BinaryStore"] = "InMemory",
                ["Attachments:LoginRateLimitPerMinute"] = "10000",
                ["Attachments:MaxFileSizeBytes"] = SmallLimitBytes.ToString()
            });
        });
    }

    public new Task DisposeAsync() => Task.CompletedTask; // host disposal is owned by WebApplicationFactory

    Task IAsyncLifetime.InitializeAsync() => SeedAsync();

    private async Task SeedAsync()
    {
        using var scope = Services.CreateScope();
        await DbSeed.SeedAsync(scope.ServiceProvider);
    }
}

[CollectionDefinition("UploadLimit")]
public sealed class UploadLimitCollection : ICollectionFixture<UploadLimitFactory>;

/// <summary>
/// v2 review, item 4 — end-to-end upload size enforcement with a SMALL configured limit
/// (4 KB instead of 1 MiB, keeping tests fast). Both rejection layers must return the
/// same stable 413 FILE-TOO-LARGE ProblemDetails and must never persist an attachment:
///   1. the pre-body Content-Length guard middleware (rejects before any body read),
///   2. the bounded read in the controller (aborts during the read).
/// </summary>
[Collection("UploadLimit")]
public class UploadLimitTests(UploadLimitFactory factory)
{
    [Fact]
    public async Task Upload_BeyondBodyCap_IsRejectedBeforeReading_WithStable413()
    {
        var client = await factory.CreateClient().LoginAsync(DbSeed.ApplicantUsername, DbSeed.ApplicantPassword);
        var before = await AttachmentCountAsync();

        // 200 KB body >> cap (4096 + 64 KB overhead): the middleware must stop it pre-read.
        var response = await client.UploadAsync(
            "/api/v1/requests/1/attachments", "big.bin", TestFiles.Pdf(200 * 1024));

        Assert.Equal(HttpStatusCode.RequestEntityTooLarge, response.StatusCode);
        Assert.True(await response.HasErrorCodeAsync(ErrorCodes.FileTooLarge));
        Assert.Equal(before, await AttachmentCountAsync()); // nothing persisted
    }

    [Fact]
    public async Task Upload_BeyondFileLimit_UnderBodyCap_Is413FileTooLarge()
    {
        var client = await factory.CreateClient().LoginAsync(DbSeed.ApplicantUsername, DbSeed.ApplicantPassword);
        var before = await AttachmentCountAsync();

        // 10 KB file: under the body cap, above the 4 KB file limit → the bounded read aborts.
        var response = await client.UploadAsync(
            "/api/v1/requests/1/attachments", "over.bin", TestFiles.Pdf(10 * 1024));

        Assert.Equal(HttpStatusCode.RequestEntityTooLarge, response.StatusCode);
        Assert.True(await response.HasErrorCodeAsync(ErrorCodes.FileTooLarge));
        Assert.Equal(before, await AttachmentCountAsync());
    }

    [Fact]
    public async Task Upload_UnderLimit_StillSucceeds()
    {
        var client = await factory.CreateClient().LoginAsync(DbSeed.ApplicantUsername, DbSeed.ApplicantPassword);

        var response = await client.UploadAsync(
            "/api/v1/requests/1/attachments", "ok.pdf", TestFiles.Pdf(2 * 1024), requestId: "ul-ok-1");

        Assert.Equal(HttpStatusCode.Created, response.StatusCode);
        var data = await response.ReadDataAsync();
        Assert.Equal(2 * 1024, data.GetProperty("sizeBytes").GetInt32());
    }

    private async Task<int> AttachmentCountAsync()
    {
        using var scope = factory.Services.CreateScope();
        var db = scope.ServiceProvider.GetRequiredService<Attachments.Infrastructure.Persistence.AppDbContext>();
        return await db.RequestAttachments.CountAsync();
    }
}
