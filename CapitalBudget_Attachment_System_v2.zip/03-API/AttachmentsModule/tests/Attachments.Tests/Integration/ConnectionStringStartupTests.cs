using Attachments.Core.Domain;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.AspNetCore.Mvc.Testing;
using Microsoft.Extensions.DependencyInjection;
using Xunit;

namespace Attachments.Tests.Integration;

/// <summary>
/// v2 review, item 5 — the API must NEVER fall back to an unintended default SQL
/// connection: with a real (non-InMemory) provider configured and a blank
/// connection string, startup must fail fast with a clear Persian message.
/// </summary>
public class ConnectionStringStartupTests
{
    [Fact]
    public void SqlServerProvider_WithoutConnectionString_FailsFastAtStartup()
    {
        var exception = Record.Exception(() =>
        {
            using var failing = new SqlServerNoConnectionStringFactory();
            _ = failing.CreateClient(); // triggers the host build → startup guard
        });

        Assert.NotNull(exception);
        var text = Flatten(exception!);
        Assert.Contains("رشته اتصال", text);                 // explicit Persian fail-fast message
        Assert.Contains("ConnectionStrings__Default", text); // actionable fix in the message
    }

    [Fact]
    public async Task InMemoryProvider_WithoutConnectionString_StillStarts()
    {
        // The lab/test provider intentionally does not need a SQL connection string.
        using var factory = new InMemoryNoConnectionStringFactory();
        using var client = factory.CreateClient();

        var response = await client.GetAsync("/health");
        Assert.True(response.IsSuccessStatusCode);
    }

    private sealed class SqlServerNoConnectionStringFactory : WebApplicationFactory<Program>
    {
        protected override void ConfigureWebHost(IWebHostBuilder builder)
        {
            builder.UseEnvironment("Development");
            builder.UseSetting("Database:Provider", "SqlServer");
            builder.UseSetting("ConnectionStrings:Default", "");   // blank → must fail fast
            builder.ConfigureAppConfiguration((_, configuration) =>
            {
                configuration.AddInMemoryCollection(new Dictionary<string, string?>
                {
                    ["Database:Provider"] = "SqlServer",
                    ["ConnectionStrings:Default"] = ""
                });
            });
        }
    }

    private sealed class InMemoryNoConnectionStringFactory : WebApplicationFactory<Program>
    {
        protected override void ConfigureWebHost(IWebHostBuilder builder)
        {
            builder.UseEnvironment("Development");
            builder.UseSetting("Database:Provider", "InMemory");
            builder.UseSetting("ConnectionStrings:Default", "");
            builder.ConfigureAppConfiguration((_, configuration) =>
            {
                configuration.AddInMemoryCollection(new Dictionary<string, string?>
                {
                    ["Database:Provider"] = "InMemory",
                    ["ConnectionStrings:Default"] = ""
                });
            });
        }
    }

    private static string Flatten(Exception exception)
    {
        var text = new List<string>();
        for (var current = (Exception?)exception; current is not null; current = current.InnerException)
            text.Add(current.Message);
        return string.Join(" | ", text);
    }
}
