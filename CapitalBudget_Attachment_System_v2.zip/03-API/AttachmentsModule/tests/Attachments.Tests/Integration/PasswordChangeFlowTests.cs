using System.Net;
using System.Net.Http.Json;
using Attachments.Core.Domain;
using Xunit;

namespace Attachments.Tests.Integration;

/// <summary>
/// Accounts flagged MustChangePassword are hard-gated: every non-auth endpoint answers
/// 403 PASSWORD-CHANGE-REQUIRED until /auth/change-password succeeds (weak and
/// username-equal passwords rejected by the policy).
/// </summary>
[Collection(nameof(AttachmentsApiCollection))]
public class PasswordChangeFlowTests(AttachmentsApiFactory factory)
{
    [Fact]
    public async Task MustChangePassword_BlocksNonAuthEndpoints_UntilChangeSucceeds()
    {
        var client = await factory.CreateClient().LoginAsync(DbSeed.ForcedUsername, DbSeed.ForcedPassword);

        // me reflects the flag
        var me = await client.GetAsync("/api/v1/auth/me");
        Assert.Equal(HttpStatusCode.OK, me.StatusCode);
        Assert.True((await me.ReadDataAsync()).GetProperty("mustChangePassword").GetBoolean());

        // blocked: request scope + attachments + micro list
        var blocked1 = await client.GetAsync("/api/v1/requests/by-code/PRG-FORCE-001");
        Assert.Equal(HttpStatusCode.Forbidden, blocked1.StatusCode);
        Assert.True(await blocked1.HasErrorCodeAsync(ErrorCodes.PasswordChangeRequired));

        var blocked2 = await client.GetAsync("/api/v1/requests/1/attachments");
        Assert.Equal(HttpStatusCode.Forbidden, blocked2.StatusCode);
        Assert.True(await blocked2.HasErrorCodeAsync(ErrorCodes.PasswordChangeRequired));

        // weak password (common list) rejected
        var weak = await client.PostAsJsonAsync("/api/v1/auth/change-password",
            new { currentPassword = DbSeed.ForcedPassword, newPassword = "12345678" });
        Assert.Equal(HttpStatusCode.BadRequest, weak.StatusCode);
        Assert.True(await weak.HasErrorCodeAsync(ErrorCodes.PasswordWeak));

        // password equal to the username rejected
        var usernameEqual = await client.PostAsJsonAsync("/api/v1/auth/change-password",
            new { currentPassword = DbSeed.ForcedPassword, newPassword = DbSeed.ForcedUsername });
        Assert.Equal(HttpStatusCode.BadRequest, usernameEqual.StatusCode);
        Assert.True(await usernameEqual.HasErrorCodeAsync(ErrorCodes.PasswordWeak));

        // wrong current password rejected
        var wrongCurrent = await client.PostAsJsonAsync("/api/v1/auth/change-password",
            new { currentPassword = "totally-wrong", newPassword = DbSeed.ForcedNewPassword });
        Assert.Equal(HttpStatusCode.BadRequest, wrongCurrent.StatusCode);
        Assert.True(await wrongCurrent.HasErrorCodeAsync(ErrorCodes.CurrentPasswordInvalid));

        // valid change → 200
        var changed = await client.PostAsJsonAsync("/api/v1/auth/change-password",
            new { currentPassword = DbSeed.ForcedPassword, newPassword = DbSeed.ForcedNewPassword });
        Assert.Equal(HttpStatusCode.OK, changed.StatusCode);

        // unblocked immediately (session principal rebuilt from the fresh user row)
        var unblocked = await client.GetAsync("/api/v1/requests/by-code/PRG-FORCE-001");
        Assert.Equal(HttpStatusCode.OK, unblocked.StatusCode);

        var meAfter = await client.GetAsync("/api/v1/auth/me");
        Assert.False((await meAfter.ReadDataAsync()).GetProperty("mustChangePassword").GetBoolean());
    }

    [Fact]
    public async Task ChangePassword_WithoutSession_Returns401()
    {
        var client = factory.CreateClient();

        var response = await client.PostAsJsonAsync("/api/v1/auth/change-password",
            new { currentPassword = "x", newPassword = "y" });

        Assert.Equal(HttpStatusCode.Unauthorized, response.StatusCode);
    }

    [Fact]
    public async Task ReLogin_AfterPasswordChange_WorksWithNewPasswordOnly()
    {
        var client = await factory.CreateClient().LoginAsync(DbSeed.ForcedUsername, DbSeed.ForcedNewPassword);

        var me = await client.GetAsync("/api/v1/auth/me");
        Assert.Equal(HttpStatusCode.OK, me.StatusCode);
        Assert.False((await me.ReadDataAsync()).GetProperty("mustChangePassword").GetBoolean());

        var oldPassword = await factory.CreateClient().PostAsJsonAsync("/api/v1/auth/login",
            new { username = DbSeed.ForcedUsername, password = DbSeed.ForcedPassword });
        Assert.Equal(HttpStatusCode.Unauthorized, oldPassword.StatusCode);
    }
}
