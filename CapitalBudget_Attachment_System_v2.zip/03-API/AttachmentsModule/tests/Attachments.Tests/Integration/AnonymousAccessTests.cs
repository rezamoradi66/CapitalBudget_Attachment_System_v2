using System.Net;
using Xunit;

namespace Attachments.Tests.Integration;

/// <summary>Every protected endpoint must answer 401 UNAUTHENTICATED without a session cookie.</summary>
[Collection(nameof(AttachmentsApiCollection))]
public class AnonymousAccessTests(AttachmentsApiFactory factory)
{
    public static TheoryData<string, string> ProtectedEndpoints => new()
    {
        { "GET", "/api/v1/requests/1/attachments" },
        { "POST", "/api/v1/requests/1/attachments" },
        { "GET", "/api/v1/micros/1/attachments" },
        { "POST", "/api/v1/micros/1/attachments" },
        { "GET", "/api/v1/attachments/1/info" },
        { "GET", "/api/v1/attachments/1" },
        { "DELETE", "/api/v1/attachments/1" },
        { "GET", "/api/v1/requests/by-code/PRG-LAB-001" },
        { "GET", "/api/v1/auth/me" },
        { "POST", "/api/v1/auth/logout" }
    };

    [Theory]
    [MemberData(nameof(ProtectedEndpoints))]
    public async Task ProtectedEndpoints_Return401WithoutSession(string method, string url)
    {
        var client = factory.CreateClient();
        var request = new HttpRequestMessage(new HttpMethod(method), url);
        if (method == "POST")
            request.Content = new MultipartFormDataContent(); // authorization fails before model binding

        var response = await client.SendAsync(request);

        Assert.Equal(HttpStatusCode.Unauthorized, response.StatusCode);
        Assert.True(await response.HasErrorCodeAsync(Attachments.Core.Domain.ErrorCodes.Unauthenticated),
            await response.Content.ReadAsStringAsync());
    }

    [Fact]
    public async Task HealthEndpoint_IsAnonymousAndHealthy()
    {
        var client = factory.CreateClient();

        var response = await client.GetAsync("/health");
        var body = await response.Content.ReadAsStringAsync();

        Assert.Equal(HttpStatusCode.OK, response.StatusCode);
        Assert.Contains("Healthy", body, StringComparison.Ordinal);
    }
}
