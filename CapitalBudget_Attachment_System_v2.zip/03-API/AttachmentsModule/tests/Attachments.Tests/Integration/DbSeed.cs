using Attachments.Core.Application;
using Attachments.Core.Domain;
using Attachments.Core.Domain.Entities;
using Attachments.Core.Services;
using Attachments.Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;

namespace Attachments.Tests.Integration;

/// <summary>
/// Idempotent seed for each EF InMemory database (per factory/host):
/// admin, applicant, outsider, lockout-target, forced-password user, and the lab requests
/// (PRG-LAB-001 with 2 micros, PRG-OUT-001, PRG-COUNT-001, PRG-IDEM-001, PRG-FORCE-001).
/// All passwords are hashed with the REAL Pbkdf2PasswordHasher (PBKDF2-SHA256, 100k iterations).
/// </summary>
public static class DbSeed
{
    public const string AdminUsername = "admin";
    public const string AdminPassword = "Admin!2345";
    public const string ApplicantUsername = "applicant1";
    public const string ApplicantPassword = "Applicant!2345";
    public const string OutsiderUsername = "outsider1";
    public const string OutsiderPassword = "Outsider!2345";
    public const string LockedUsername = "lockme1";
    public const string LockedPassword = "Lockme!2345";
    public const string ForcedUsername = "forceuser1";
    public const string ForcedPassword = "Forced!2345";
    public const string ForcedNewPassword = "N4w-Secret-Pass!2026";

    public static async Task SeedAsync(IServiceProvider services)
    {
        var db = services.GetRequiredService<AppDbContext>();
        var hasher = services.GetRequiredService<IPasswordHasher>();

        if (await db.Users.AnyAsync(u => u.Username == AdminUsername))
            return;

        var admin = new User
        {
            Username = AdminUsername, PasswordHash = hasher.Hash(AdminPassword),
            FirstName = "مدیر", LastName = "سامانه", IsActive = true, MustChangePassword = false
        };
        var applicant = new User
        {
            Username = ApplicantUsername, PasswordHash = hasher.Hash(ApplicantPassword),
            FirstName = "علی", LastName = "محمدی", IsActive = true, UnitId = 10, ManagementId = 100
        };
        var outsider = new User
        {
            Username = OutsiderUsername, PasswordHash = hasher.Hash(OutsiderPassword),
            FirstName = "سارا", LastName = "کریمی", IsActive = true, UnitId = 20, ManagementId = 200
        };
        var locked = new User
        {
            Username = LockedUsername, PasswordHash = hasher.Hash(LockedPassword),
            FirstName = "کاربر", LastName = "قفلی", IsActive = true
        };
        var forced = new User
        {
            Username = ForcedUsername, PasswordHash = hasher.Hash(ForcedPassword),
            FirstName = "نیازمند", LastName = "تغییر گذرواژه", IsActive = true, MustChangePassword = true, UnitId = 30
        };

        db.Users.AddRange(admin, applicant, outsider, locked, forced);
        await db.SaveChangesAsync();

        db.UserRoles.AddRange(
            new UserRole { UserId = admin.Id, RoleCode = RoleCodes.Admin },
            new UserRole { UserId = applicant.Id, RoleCode = RoleCodes.Applicant },
            new UserRole { UserId = outsider.Id, RoleCode = RoleCodes.Applicant },
            new UserRole { UserId = locked.Id, RoleCode = RoleCodes.Applicant },
            new UserRole { UserId = forced.Id, RoleCode = RoleCodes.Applicant });
        await db.SaveChangesAsync();

        var lab = new Request
        {
            Code = "PRG-LAB-001", Title = "درخواست تجهیزات آزمایشگاه مرکزی",
            BudKind = BudKinds.Capital, Status = RequestStatuses.Draft,
            ApplicantId = applicant.Id, CreatedById = applicant.Id, UnitId = 10, ManagementId = 100
        };
        var outsiderRequest = new Request
        {
            Code = "PRG-OUT-001", Title = "درخواست کاربر دیگر",
            BudKind = BudKinds.Capital, Status = RequestStatuses.Draft,
            ApplicantId = outsider.Id, CreatedById = outsider.Id, UnitId = 20, ManagementId = 200
        };
        var countRequest = new Request
        {
            Code = "PRG-COUNT-001", Title = "درخواست آزمون سقف تعداد پیوست",
            BudKind = BudKinds.Capital, Status = RequestStatuses.Draft,
            ApplicantId = applicant.Id, CreatedById = applicant.Id, UnitId = 10, ManagementId = 100
        };
        var idemRequest = new Request
        {
            Code = "PRG-IDEM-001", Title = "درخواست آزمون شماره درخواست تکراری",
            BudKind = BudKinds.Capital, Status = RequestStatuses.Draft,
            ApplicantId = applicant.Id, CreatedById = applicant.Id, UnitId = 10, ManagementId = 100
        };
        var forcedRequest = new Request
        {
            Code = "PRG-FORCE-001", Title = "درخواست کاربر نیازمند تغییر گذرواژه",
            BudKind = BudKinds.Capital, Status = RequestStatuses.Draft,
            ApplicantId = forced.Id, CreatedById = forced.Id, UnitId = 30, ManagementId = 300
        };

        db.Requests.AddRange(lab, outsiderRequest, countRequest, idemRequest, forcedRequest);
        await db.SaveChangesAsync();

        db.RequestMicros.AddRange(
            new RequestMicro { RequestId = lab.Id, SeqNo = 1, Title = "ریزفهرست تجهیزات آزمایشگاهی", AhpStatus = AhpStatuses.Pending },
            new RequestMicro { RequestId = lab.Id, SeqNo = 2, Title = "ریزفهرست نرم‌افزار تخصصی", AhpStatus = AhpStatuses.Pending });
        await db.SaveChangesAsync();
    }
}
