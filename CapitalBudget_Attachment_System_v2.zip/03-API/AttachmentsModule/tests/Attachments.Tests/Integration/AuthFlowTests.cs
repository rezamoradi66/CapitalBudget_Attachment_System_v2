using System.Net;
using System.Net.Http.Json;
using Attachments.Core.Domain;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Xunit;

namespace Attachments.Tests.Integration;

[Collection(nameof(AttachmentsApiCollection))]
public class AuthFlowTests(AttachmentsApiFactory factory)
{
    [Fact]
    public async Task LoginThenMeThenLogout_FullCycle()
    {
        var client = await factory.CreateClient().LoginAsync(DbSeed.AdminUsername, DbSeed.AdminPassword);

        var me = await client.GetAsync("/api/v1/auth/me");
        Assert.Equal(HttpStatusCode.OK, me.StatusCode);
        var profile = await me.ReadDataAsync();
        Assert.Equal(DbSeed.AdminUsername, profile.GetProperty("username").GetString());
        Assert.Equal("مدیر سامانه", profile.GetProperty("fullName").GetString());
        Assert.Contains("admin", profile.GetProperty("roles").EnumerateArray().Select(r => r.GetString()));
        Assert.False(profile.GetProperty("mustChangePassword").GetBoolean());

        var logout = await client.PostAsync("/api/v1/auth/logout", null);
        Assert.Equal(HttpStatusCode.OK, logout.StatusCode);

        var meAfterLogout = await client.GetAsync("/api/v1/auth/me");
        Assert.Equal(HttpStatusCode.Unauthorized, meAfterLogout.StatusCode);
        Assert.True(await meAfterLogout.HasErrorCodeAsync(ErrorCodes.Unauthenticated));
    }

    [Fact]
    public async Task Login_WithWrongPassword_Returns401InvalidCredentials()
    {
        var client = factory.CreateClient();

        var response = await client.PostAsJsonAsync("/api/v1/auth/login",
            new { username = DbSeed.ApplicantUsername, password = "wrong-password" });

        Assert.Equal(HttpStatusCode.Unauthorized, response.StatusCode);
        Assert.True(await response.HasErrorCodeAsync(ErrorCodes.InvalidCredentials));
    }

    [Fact]
    public async Task Login_WithUnknownUser_ReturnsUniform401()
    {
        var client = factory.CreateClient();

        var response = await client.PostAsJsonAsync("/api/v1/auth/login",
            new { username = "no-such-user", password = "whatever123" });

        Assert.Equal(HttpStatusCode.Unauthorized, response.StatusCode);
        Assert.True(await response.HasErrorCodeAsync(ErrorCodes.InvalidCredentials)); // no user enumeration
    }

    [Fact]
    public async Task FiveWrongPasswords_LockAccount_EvenForCorrectCredentials_UntilLockExpires()
    {
        var client = factory.CreateClient();

        for (var attempt = 1; attempt <= 4; attempt++)
        {
            var failed = await client.PostAsJsonAsync("/api/v1/auth/login",
                new { username = DbSeed.LockedUsername, password = $"bad-{attempt}" });
            Assert.Equal(HttpStatusCode.Unauthorized, failed.StatusCode);
            Assert.True(await failed.HasErrorCodeAsync(ErrorCodes.InvalidCredentials));
        }

        var fifth = await client.PostAsJsonAsync("/api/v1/auth/login",
            new { username = DbSeed.LockedUsername, password = "bad-5" });
        Assert.Equal(HttpStatusCode.Unauthorized, fifth.StatusCode);
        Assert.True(await fifth.HasErrorCodeAsync(ErrorCodes.LoginLocked));

        // Correct credentials are still rejected while the lock is active.
        var locked = await client.PostAsJsonAsync("/api/v1/auth/login",
            new { username = DbSeed.LockedUsername, password = DbSeed.LockedPassword });
        Assert.Equal(HttpStatusCode.Unauthorized, locked.StatusCode);
        Assert.True(await locked.HasErrorCodeAsync(ErrorCodes.LoginLocked));

        // Manipulate the lockout row: the clock "waits" past the 15-minute lockout window.
        await ExpireLockoutAsync(DbSeed.LockedUsername);
        var unlocked = await client.PostAsJsonAsync("/api/v1/auth/login",
            new { username = DbSeed.LockedUsername, password = DbSeed.LockedPassword });
        Assert.Equal(HttpStatusCode.OK, unlocked.StatusCode);
    }

    [Fact]
    public async Task GetRequestByCode_ResolvesRequestWithMicros()
    {
        var client = await factory.CreateClient().LoginAsync(DbSeed.ApplicantUsername, DbSeed.ApplicantPassword);

        var response = await client.GetAsync("/api/v1/requests/by-code/PRG-LAB-001");

        Assert.Equal(HttpStatusCode.OK, response.StatusCode);
        var data = await response.ReadDataAsync();
        Assert.Equal("PRG-LAB-001", data.GetProperty("code").GetString());
        Assert.Equal("draft", data.GetProperty("status").GetString());
        Assert.Equal("capital", data.GetProperty("budKind").GetString());
        Assert.Equal(2, data.GetProperty("micros").GetArrayLength());
        var micros = data.GetProperty("micros").EnumerateArray().ToList();
        Assert.Equal(1, micros[0].GetProperty("seqNo").GetInt32());
        Assert.Equal(2, micros[1].GetProperty("seqNo").GetInt32());
    }

    [Fact]
    public async Task GetRequestByCode_IsScopedForOutsider()
    {
        var client = await factory.CreateClient().LoginAsync(DbSeed.OutsiderUsername, DbSeed.OutsiderPassword);

        var response = await client.GetAsync("/api/v1/requests/by-code/PRG-LAB-001");

        Assert.Equal(HttpStatusCode.NotFound, response.StatusCode); // invisible == not found (no enumeration)
        Assert.True(await response.HasErrorCodeAsync(ErrorCodes.NotFound));
    }

    private async Task ExpireLockoutAsync(string username)
    {
        using var scope = factory.Services.CreateScope();
        var db = scope.ServiceProvider.GetRequiredService<Attachments.Infrastructure.Persistence.AppDbContext>();
        var lockout = await db.LoginLockouts.SingleAsync(l => l.Username == username);
        lockout.LockedUntilUtc = DateTime.UtcNow.AddMinutes(-1);
        await db.SaveChangesAsync();
    }
}
