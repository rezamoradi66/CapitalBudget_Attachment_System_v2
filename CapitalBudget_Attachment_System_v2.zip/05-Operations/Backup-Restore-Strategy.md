# راهبرد نسخه پشتیبان و بازیابی — ماژول پیوست‌ها (FILESTREAM)

## ۱. اصول (تطبیق D-11 قطعی)

- داده FILESTREAM بخشی از دیتابیس است: **Full/Diff/Log Backup آن را کامل پوشش می‌دهد** — هیچ پشتیبان جداگانه فایل‌سیستم لازم نیست (مزیت اصلی انتخاب کارفرما).
- **هرگز موفقیت Backup را معادل موفقیت Restore فرض نکن** — بازیابی آزمایشی حداقل **ماهی یک‌بار در محیط آزمایشی** و ثبت نتیجه (D-11؛ فرم ثبت در §۵).
- RPO/RTO/مدت نگهداری/مسئولیت اجرا: **بدون تأیید واحد فناوری اطلاعات تعیین نمی‌شود** (باز — سند Open-Issues). پیشنهاد شروع مذاکره (نه تصمیم): Full روزانه + Log هر ۱۵ دقیقه + نگهداری ۳۰ روز — صرفاً نقطه شروع گفتگو.
- Recovery Model دیتابیس باید **FULL** باشد تا بازگشت نقطه‌زمانی ممکن شود (اسکریپت 00 وضعیت فعلی را نشان می‌دهد).

## ۲. دستورهای پشتیبان‌گیری

```sql
-- Full (روزانه)
BACKUP DATABASE [CapitalBudgetDB]
TO DISK = N'E:\CBM-Backup\CapitalBudgetDB_Full.bak'
WITH INIT, NAME = N'CBM-Full', CHECKSUM, COMPRESSION, STATS = 10;

-- Diff (ساعتی در ساعات کاری — قابل مذاکره)
BACKUP DATABASE [CapitalBudgetDB]
TO DISK = N'E:\CBM-Backup\CapitalBudgetDB_Diff.bak'
WITH DIFFERENTIAL, INIT, CHECKSUM, COMPRESSION;

-- Log (ساعت‌های میانی — فقط با Recovery Model=FULL)
BACKUP LOG [CapitalBudgetDB]
TO DISK = N'E:\CBM-Backup\CapitalBudgetDB_Log.trn'
WITH INIT, CHECKSUM, COMPRESSION;

-- اثبات سلامت نسخه (بدون بازیابی)
RESTORE VERIFYONLY FROM DISK = N'E:\CBM-Backup\CapitalBudgetDB_Full.bak' WITH CHECKSUM;
```
نکته حجم: Backup شامل بایت‌های FILESTREAM است؛ حجم پشتیبان ≈ حجم داده + پیوست‌ها. ظرفیت دیسک پشتیبان باید با رشد پیوست‌ها محاسبه شود.

## ۳. بازیابی (ترتیب کامل)

```sql
RESTORE DATABASE [CapitalBudgetDB]
FROM DISK = N'E:\CBM-Backup\CapitalBudgetDB_Full.bak'
WITH NORECOVERY, REPLACE, MOVE 'CapitalBudgetDB' TO 'D:\Data\CapitalBudgetDB.mdf',
     MOVE 'CapitalBudgetDB_log' TO 'L:\Logs\CapitalBudgetDB_log.ldf',
     MOVE 'AttachmentsFSData' TO 'D:\CBM\FS\AttachmentsFSData';
-- (نام فایل‌های منطقی را از RESTORE FILELISTONLY بگیرید)
RESTORE DATABASE [CapitalBudgetDB] FROM DISK = N'..._Diff.bak' WITH NORECOVERY;
RESTORE LOG [CapitalBudgetDB] FROM DISK = N'..._Log.trn' WITH RECOVERY;
```
⚠️ مسیر FILESTREAM در بازیابی باید همان سیاست مسیر (گام ۳ راهنمای FILESTREAM) رعایت کند؛ پوشه مقصد نباید از قبل وجود داشته باشد.

## ۴. یکپارچگی پس از بازیابی (مبنای آزمون TC-ATT-041…043)

1. تعداد رکوردها: `SELECT COUNT(*) FROM dbo.RequestAttachments` — مقایسه با پیش از پشتیبان‌گیری.
2. جمع اندازه: `SELECT SUM(SizeBytes) …` — مقایسه.
3. **باز کردن واقعی فایل‌ها**: چند فایل را با API دانلود و SHA-256 را با ستون `Sha256` مقایسه کنید (اسکریپت 04-Health-Check خلاصه‌ها را می‌دهد).
4. ورود کاربر مجاز و دانلود موفق → یکپارچگی مجوزها پس از بازیابی.

## ۵. فرم ثبت آزمون بازیابی (الزام D-11 و TC-ATT-040…043)

| فیلد | مقدار |
|---|---|
| تاریخ/ساعت آزمون | |
| مجری | |
| نسخه پشتیبان مبنا (نام/تاریخ) | |
| نوع بازیابی (Full / Full+Diff / Full+Diff+Log) | |
| نتیجه RESTORE VERIFYONLY | |
| تعداد رکوردهای پیوست قبل/بعد | |
| جمع SizeBytes قبل/بعد | |
| تعداد فایل دانلود و تطبیق SHA-256 | |
| ورود و دانلود مجاز موفق؟ (بله/خیر) | |
| نتیجه نهایی (PASS/FAIL) + شرح | |

## ۶. سیاست نگهداری (پیش‌نویس مذاکره با IT — قطعی نیست)

- پنجره پیشنهادی: ۳۰ روز نسخه‌های روزانه + ۱۲ نسخه ماهانه؛ نگهداری سالانه طبق الزامات نگهداری اسناد سازمان (۵–۱۰ سال موضوع مأموریت — تثبیت دقیق با IT).
- محل نگهداری: دیسک محلی + کپی روی رسانه دوم (NAS/دستگاه خارجی) — در دستور کار IT.
