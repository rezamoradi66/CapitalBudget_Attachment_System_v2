# دستورالعمل نصب روی IIS — ماژول پیوست‌ها (Windows Server 2019)

> هیچ گامی از این دستورالعمل به‌صورت خودکار اجرا نشده است؛ اجرا با IT و در محیط آزمایشی اول.

## ۱. پیش‌نیازها

| مورد | اقدام |
|---|---|
| Hosting Bundle | نصب `dotnet-hosting-10.0.x-win.exe` (آفلاین قابل انتقال) + `net stop was /y && net start w3svc` |
| IIS | نقش Web Server + `URL Rewrite` لازم نیست (API مستقل) |
| دیتابیس | اسکریپت‌های 02-Database اجرا و Verify شده باشند |

## ۲. App Pool و Site

```powershell
Import-Module WebAdministration
New-WebAppPool -Name "CBM-Attachments"
Set-ItemProperty IIS:\AppPools\CBM-Attachments -Name managedRuntimeVersion -Value ""
Set-ItemProperty IIS:\AppPools\CBM-Attachments -Name processModel.loadUserProfile -Value $false
New-Website -Name "CBM-Attachments" -PhysicalPath "C:\Apps\CBMAttachments" -ApplicationPool "CBM-Attachments" -Port 8090
```

## ۳. مجوزها (اصل حداقل دسترسی — بند ۷-۱۵ مأموریت)

| مسیر | حساب | مجوز |
|---|---|---|
| `C:\Apps\CBMAttachments` | `IIS AppPool\CBM-Attachments` | Read & Execute |
| `C:\Apps\CBMAttachments\logs` | همان | Modify (لاگ Serilog) |
| پوشه FILESTREAM container | همان | Read/Write — **فقط همین** |

- App Pool **نباید** عضو Administrators باشد.
- حساب اتصال SQL: Windows Authentication با همین هویت (برای SqlFileStream الزامی است)؛ در SQL فقط مجوزهای جدولی حداقلی (Security-Plan §۳).

## ۴. پیکربندی

```powershell
# متغیرهای محیطی — بدون ذخیره رمز در فایل (D-09)
New-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\WAS\Parameters" -Name placeholder -Value 0 -PropertyType DWord -Force  # (نمونه — در عمل از web.config environmentVariables یا Registry Per-AppPool استفاده کنید)
```
ساده‌تر و توصیه‌شده: مقادیر در `publish/web.config` داخل `<environmentVariables>` (بدون رمز) یا متغیرهای محیطی حساب App Pool. مقادیر لازم: `ASPNETCORE_ENVIRONMENT=Production`، `ConnectionStrings__Default`، `Attachments__BinaryStore=Filestream`.

## ۵. توپولوژی (ترجیح D-22 — تک‌مبدأ)

- **گزینه الف (ترجیحی):** HTML و API در یک Site — API به‌صورت Application فرزند (مثلاً `/api`)؛ Cookie هم‌مبدأ می‌ماند و نیازی به CORS نیست.
- **گزینه ب (فقط با دلیل فنی و تأیید کارفرما):** دو Site مجزا → فعال‌سازی CORS محدود + `SameSite=None; Secure` (ریسک‌های CSRF/CORS مستند در Security-Plan).
- بررسی‌های IIS واقعی (ساختار سایت‌های موجود، Host Headerها) در دستور کار IT است (D-22 — قطعی نیست).

## ۶. صحت‌سنجی نصب

1. `GET /health` → `{"status":"Healthy"}`.
2. ورود با حساب مدیر اولیه (رمز تولیدشده در استقرار — D-16) → تغییر اجباری رمز.
3. TC-ATT-032: بارگذاری/دانلود واقعی روی FILESTREAM.
4. لاگ‌ها: `logs/app-*.log` بدون محتوای فایل/مسیر (TC-ATT-019).

## ۷. بازگشت از تغییرات (Rollback)

1. Stop سایت → تغییر مسیر/حذف Site و App Pool (دیتابیس دست‌نخورده می‌ماند).
2. در صورت نیاز به حذف ساختار دیتابیس: **فقط** `99-Rollback-Attachment-Structure.sql` (اگر رکورد پیوستی وجود داشته باشد اجرا نمی‌شود — بازیابی از پشتیبان طبق Backup-Restore-Strategy).

## سقف حجم درخواست در IIS (افزوده v2 — بند ۴ بازبینی)

سرویس در حالت In-Process محدودیت‌های Kestrel را نادیده می‌گیرد؛ بنابراین سقف بدنه درخواست در سه لایه هم‌سان باید کنترل شود:

| لایه | مقدار پیشنهادی (سقف فایل = ۱۰۴۸۵۷۶ بایت) | محل تنظیم |
|---|---|---|
| کد (IISServerOptions.MaxRequestBodySize) | 1112576 = ۱MB + ۶۴KB | خودکار در Program.cs (v2) — نیازی به اقدام نیست |
| Site — maxAllowedContentLength | 1112576 | web.config / Request Filtering |
| ANCM In-Process (باقی‌مانده از کد) | همان IISServerOptions | — |

```xml
<!-- نمونه برای web.config (فقط در صورت تمایل به سخت‌گیری مضاعف در لایه IIS): -->
<system.webServer>
  <security>
    <requestFiltering>
      <requestLimits maxAllowedContentLength="1112576" />
    </requestFiltering>
  </security>
</system.webServer>
```

توجه: با این سقف، بدنه‌های بزرگ‌تر با وضعیت ۴۱۳ رد می‌شوند؛ پاسخ قراردادی ProblemDetails از Middleware داخلی سرویس می‌آید (لایه‌های داخلی زودتر رد می‌کنند) و در صورت رد در لایه IIS، بدنه پاسخ ممکن است خالی باشد — رفتار طبیعی و پذیرفته‌شده.
