#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
================================================================
patch_html.py — وصله جراحی اتصال قابلیت «پیوست فایل» به REST API
تسک A5 — نسخه ۱٫۰ (قابل تکرار و deterministic)
================================================================
وظیفه:
  ۱) خواندن HTML اصلی (تک‌فایل اپ، با کدگذاری UTF-8 و حفظ دقیق
     نویسه‌های پایان خط — newline='' در خواندن و نوشتن).
  ۲) اعمال ۸ وصله (P1 تا P8) به‌صورت مبتنی بر «لنگر متنی دقیق»؛
     هر لنگر باید دقیقاً یک‌بار در فایل موجود باشد وگرنه اسکریپت
     بدون نوشتن خروجی، با خطا متوقف می‌شود (assert یکتایی).
  ۳) نوشتن خروجی در همان پوشه فایل ورودی:
     Capital_Budget_Management_Stabilized_v3_1_1.attachments.html
  ۴) همگام‌سازی نسخه بازبینی آداپتور (cbm-attachments-adapter.js)
     در همان پوشه خود اسکریپت — همیشه با رشته داخلی یکسان می‌شود.
  ۵) چاپ خلاصه فارسی وصله‌های اعمال‌شده با شماره خط (قبل/بعد).

اصول:
  - هیچ بخش دیگری از فایل بازفرمت یا جابه‌جا نمی‌شود؛ تنها متن
    جایگزین‌شده در ناحیه لنگرها تغییر می‌کند.
  - پیش‌فرض CBM_API_CONFIG.enabled=false ⇒ رفتار فعلی اپ تغییر
    نمی‌کند (آداپتور خنثی است).
  - استاندارد کتابخانه پایتون؛ بدون وابستگی خارجی.
================================================================
"""

import argparse
import os
import sys

DEFAULT_SRC = '/home/z/my-project/audit_src/extracted/Capital_Budget_Management_Stabilized_v3_1_1.html'
OUT_NAME = 'Capital_Budget_Management_Stabilized_v3_1_1.attachments.html'

# ----------------------------------------------------------------
# کد آداپتور (عیناً همان cbm-attachments-adapter.js؛ در هر اجرا
# نسخه بازبینی کنار اسکریپت با این رشته همگام می‌شود)
# ----------------------------------------------------------------
ADAPTER_JS = r"""/* ================================================================
   CBM Attachments Adapter — نسخه ۱٫۰ (تسک A5)
   ----------------------------------------------------------------
   نقش: پل اختیاری بین قابلیت «پیوست فایل» اپ تک‌فایلی و REST API
   (AttachmnetsModule.Api — مسیرهای /api/v1/ و پاسخ ProblemDetails).

   قرارداد فعال‌سازی:
     window.CBM_API_CONFIG = { enabled: true, baseUrl: '/api' };
   پیش‌فرض: enabled:false ⇒ آداپتور کاملاً خنثی است و رفتار فعلی اپ
   (localStorage) صددرصد بدون تغییر می‌ماند.

   نگاشت مالکیت (مستند ۰۱-Planning/Attachment-Architecture.md §۶):
     OwnerType 1 = برنامه/درخواست  →  POST /api/v1/requests/{id}/attachments
     OwnerType 2 = ریزتقاضا        →  POST /api/v1/micros/{id}/attachments
     شناسه‌یابی مالک: برنامه با «کد برنامه» (p.code) از طریق
       GET /api/v1/requests/by-code/{code}
     و ریزتقاضا با نگاشت مستند «m.id ↔ SeqNo» در فهرست micros همان
     پاسخ (seqNo === m.id)؛ سپس POST با شناسه سرور micro.

   اصل ایمنی: هر متد در try/catch است؛ در دسترس‌نبودن سرور هرگز اپ را
   نمی‌شکند. فقط از toast سراسری اپ استفاده می‌شود (در نبود آن ساکت است).
   ================================================================ */
window.CBM_ATT = (function () {
  'use strict';

  /* ---------- پیکربندی ---------- */
  function cfg() {
    try { return (typeof window !== 'undefined' && window.CBM_API_CONFIG) || null; } catch (e) { return null; }
  }
  function isEnabled() {
    try { var c = cfg(); return !!(c && c.enabled); } catch (e) { return false; }
  }
  function apiBase() {
    var c = cfg();
    var b = String((c && c.baseUrl) || '/api');
    return b.replace(/\/+$/, '');
  }
  /* مسیرهای کامل: baseUrl + /v1/...  (مثال: /api → /api/v1/...) */
  function API() { return apiBase() + '/v1'; }

  /* ---------- وضعیت ---------- */
  var pending = new Map();        /* attId → File (فایل محلی در انتظار بارگذاری) */
  var ownerCache = new Map();     /* code → { requestId, micros:[{id, seqNo}], ts } */
  var tries = new Map();          /* attId → تعداد تلاش ناموفق بارگذاری */
  var errToasted = new Set();     /* attId هایی که برایشان یک‌بار خطا toast شده */
  var uploading = new WeakSet();  /* مالک‌های در حال پردازش (جلوگیری از double-flush) */
  var flushing = false;
  var authed = false;             /* صرفاً اطلاعاتی — احراز هویت مبتنی بر Cookie سمت سرور است */

  /* ---------- ابزارها ---------- */
  function rid() {
    return 'req-' + Math.random().toString(36).slice(2, 10) + '-' + Date.now().toString(36);
  }
  function toastSafe(msg, type) {
    try { if (typeof toast === 'function') toast(String(msg), type || 'error'); } catch (e) {}
  }
  function getDB() {
    try { if (typeof db !== 'undefined' && db && db.programs) return db; } catch (e) {}
    try { if (typeof window !== 'undefined' && window.db && window.db.programs) return window.db; } catch (e2) {}
    try { if (typeof globalThis !== 'undefined' && globalThis.db && globalThis.db.programs) return globalThis.db; } catch (e3) {}
    return null;
  }
  /* تشخیص نوع مالک: برنامه/درخواست (دارای micros یا history) یا ریزتقاضا */
  function kindOf(o) {
    try {
      if (o && (Array.isArray(o.micros) || Array.isArray(o.history) || ('budKind' in o))) return 'request';
    } catch (e) {}
    return 'micro';
  }
  function attsOf(o) { return (o && Array.isArray(o.atts)) ? o.atts : []; }
  function hasPendingAtt(it) { return !!(it && it.pendingRemote && !it.remote); }

  var HTTP_FA = {
    400: 'درخواست ارسالی نامعتبر است',
    401: 'نشست شما منقضی شده است؛ دوباره وارد شوید',
    403: 'اجازه انجام این عملیات را ندارید',
    404: 'مورد درخواستی در سرور یافت نشد',
    409: 'تداخل در وضعیت رکورد؛ صفحه را نوسازی کنید',
    413: 'حجم فایل بیش از حد مجاز سرور است',
    415: 'نوع فایل مجاز نیست'
  };
  function fallbackMsg(status) {
    return HTTP_FA[status] || ('خطای سرور (کد ' + (status || '—') + ')');
  }
  function problemMsg(res, body) {
    try {
      if (body && typeof body === 'object') {
        if (body.title) return String(body.title);
        if (body.detail) return String(body.detail);
      }
    } catch (e) {}
    return fallbackMsg(res && res.status);
  }

  /* ---------- هسته HTTP ----------
     apiFetch: پوشش fetch با credentials، X-Request-Id برای بارگذاری‌ها،
     خواندن ProblemDetails و نمایش toast فارسی (مگر opts.silent). */
  async function apiFetch(path, opts) {
    opts = opts || {};
    var url = API() + path;
    var headers = Object.assign({}, opts.headers || {});
    if (opts.xRequestId) headers['X-Request-Id'] = opts.xRequestId;
    if (opts.json) headers['Content-Type'] = 'application/json';
    var init = {
      method: opts.method || 'GET',
      credentials: opts.credentials || 'same-origin',
      headers: headers
    };
    if (opts.body !== undefined) init.body = opts.body;
    var res, body = null;
    try { res = await fetch(url, init); }
    catch (netErr) {
      console.warn('[CBM_ATT] network error on', url, netErr);
      var m1 = 'اتصال به سرور پیوست‌ها برقرار نشد';
      if (!opts.silent) toastSafe(m1, 'error');
      return { ok: false, status: 0, error: 'network', message: m1 };
    }
    var ct = '';
    try { ct = (res.headers && res.headers.get) ? (res.headers.get('content-type') || '') : ''; } catch (eH) {}
    if (ct.indexOf('application/json') !== -1) { try { body = await res.json(); } catch (eJ) { body = null; } }
    if (!res.ok) {
      var msg = problemMsg(res, body);
      console.warn('[CBM_ATT] http', res.status, 'on', url, msg);
      if (!opts.silent) toastSafe(msg, 'error');
      return { ok: false, status: res.status, error: 'http', message: msg, problem: body };
    }
    return { ok: true, status: res.status, data: body };
  }

  /* ---------- احراز هویت (غیرمسدودکننده) ---------- */
  async function login(username, password) {
    if (!isEnabled()) return false;
    try {
      var r = await apiFetch('/auth/login', {
        method: 'POST', credentials: 'include', json: true, silent: true,
        body: JSON.stringify({ username: String(username == null ? '' : username), password: String(password == null ? '' : password) })
      });
      if (r.ok) { authed = true; console.info('[CBM_ATT] ورود به سرور پیوست‌ها برقرار شد'); return true; }
      console.warn('[CBM_ATT] login failed:', r.status, r.message);
      toastSafe('اتصال به سرور پیوست‌ها برقرار نشد', 'error');
      return false;
    } catch (e) {
      console.warn('[CBM_ATT] login error', e);
      try { toastSafe('اتصال به سرور پیوست‌ها برقرار نشد', 'error'); } catch (e2) {}
      return false;
    }
  }
  async function logout() {
    if (!isEnabled()) return;
    try { await apiFetch('/auth/logout', { method: 'POST', silent: true }); } catch (e) { console.warn('[CBM_ATT] logout error', e); }
    authed = false;
    ownerCache.clear();
  }

  /* ---------- شناسه‌یابی مالک سمت سرور ---------- */
  function parseMicros(data) {
    try {
      var arr = (data && (data.micros || data.microRequests || data.items)) || [];
      if (!Array.isArray(arr)) return [];
      return arr.map(function (x) {
        var id = x && (x.id != null ? x.id : x.microId);
        /* نگاشت مستند: SeqNo سمت سرور معادل m.id سمت HTML است */
        var seq = x && (x.seqNo != null ? x.seqNo : (x.SeqNo != null ? x.SeqNo : x.seq));
        return { id: (id == null ? null : String(id)), seqNo: (seq == null ? null : String(seq)) };
      }).filter(function (x) { return x.id != null; });
    } catch (e) { return []; }
  }
  function findParentRequest(m) {
    var d = getDB();
    if (!d || !Array.isArray(d.programs)) return null;
    for (var i = 0; i < d.programs.length; i++) {
      var p = d.programs[i];
      if (!p || typeof p !== 'object') continue;
      if (p === m) return p;
      var ms = Array.isArray(p.micros) ? p.micros : [];
      for (var j = 0; j < ms.length; j++) {
        if (ms[j] === m) return p;
        if (m && m.id && ms[j] && ms[j].id === m.id) return p;
      }
    }
    return null;
  }
  /* خروجی: {ok:true, requestId[, microId]} یا {ok:false, reason} */
  async function resolveOwner(kind, ownerObj) {
    try {
      if (!isEnabled()) return { ok: false, reason: 'disabled' };
      if (kind === 'request') {
        var code = ownerObj && ownerObj.code;
        if (!code) return { ok: false, reason: 'no-code' }; /* پیش‌نویسِ بی‌کد — به flush واگذار می‌شود */
        var key = String(code);
        var cached = ownerCache.get(key);
        if (cached) return { ok: true, requestId: cached.requestId };
        var r = await apiFetch('/requests/by-code/' + encodeURIComponent(key), { silent: true });
        if (!r.ok) return { ok: false, reason: 'resolve-failed', status: r.status, message: r.message };
        var ridSrv = r.data && (r.data.id != null ? r.data.id : r.data.requestId);
        if (ridSrv == null) return { ok: false, reason: 'bad-payload' };
        var entry = { requestId: String(ridSrv), micros: parseMicros(r.data), ts: Date.now() };
        ownerCache.set(key, entry);
        return { ok: true, requestId: entry.requestId };
      }
      if (kind === 'micro') {
        var m = ownerObj;
        if (!m || !m.id) return { ok: false, reason: 'no-id' };
        var parent = findParentRequest(m);
        if (!parent) return { ok: false, reason: 'no-parent' };
        var c = ownerCache.get(String(parent.code));
        if (!c) {
          var r2 = await resolveOwner('request', parent);
          if (!r2.ok) return r2;
          c = ownerCache.get(String(parent.code));
        }
        var hit = (c.micros || []).filter(function (x) { return x.seqNo != null && String(x.seqNo) === String(m.id); })[0];
        if (!hit) return { ok: false, reason: 'micro-not-found' };
        return { ok: true, requestId: c.requestId, microId: String(hit.id) };
      }
      return { ok: false, reason: 'bad-kind' };
    } catch (e) {
      console.warn('[CBM_ATT] resolveOwner error', e);
      return { ok: false, reason: 'error' };
    }
  }

  /* ---------- بارگذاری ---------- */
  /* ثبت فایل محلی برای شناسه پیوست (فراخوانی از هوک P2 در attsAddFiles) */
  function trackPending(attItem, file) {
    try {
      if (!isEnabled()) return false;
      if (!attItem || !attItem.id || !file) return false;
      pending.set(String(attItem.id), file);
      return true;
    } catch (e) { console.warn('[CBM_ATT] trackPending error', e); return false; }
  }
  async function tryUploadNow(o) {
    if (!isEnabled()) return 0;
    if (!o || uploading.has(o)) return 0;
    uploading.add(o);
    try { return await uploadOwner(o); }
    catch (e) { console.warn('[CBM_ATT] tryUploadNow error', e); return 0; }
    finally { uploading.delete(o); }
  }
  async function uploadOwner(o) {
    var items = attsOf(o).filter(function (it) {
      return it && it.pendingRemote && !it.remote && it.id && pending.has(String(it.id)) && pending.get(String(it.id));
    });
    if (!items.length) return 0;
    var kind = kindOf(o);
    var own = await resolveOwner(kind, o);
    if (!own || !own.ok) return 0; /* مالک هنوز سمت سرور قابل‌تشخیص نیست → به flush واگذار می‌شود */
    var base = (kind === 'request')
      ? '/requests/' + encodeURIComponent(own.requestId) + '/attachments'
      : '/micros/' + encodeURIComponent(own.microId) + '/attachments';
    var doneCount = 0;
    for (var i = 0; i < items.length; i++) {
      var it = items[i];
      var file = pending.get(String(it.id));
      try {
        var fd = new FormData();
        fd.append('file', file, it.name || (file && file.name) || ('file-' + it.id));
        if (it.name) fd.append('displayName', it.name);
        var r = await apiFetch(base, { method: 'POST', body: fd, xRequestId: rid(), silent: true });
        if (r.ok) {
          it.remote = true;
          it.pendingRemote = false;
          var srv = r.data && (r.data.id != null ? r.data.id : (r.data.attachmentId != null ? r.data.attachmentId : null));
          it.serverId = (srv == null ? it.id : String(srv));
          if (r.data && (r.data.displayName || r.data.fileName)) it.serverName = String(r.data.displayName || r.data.fileName);
          pending.delete(String(it.id));
          tries.delete(String(it.id));
          doneCount++;
        } else if (r.status === 401) {
          authed = false;
          toastSafe('نشست شما منقضی شده است؛ دوباره وارد شوید', 'error');
          return doneCount; /* توقف تلاش‌های بعدی تا ورود مجدد */
        } else {
          tries.set(String(it.id), (tries.get(String(it.id)) || 0) + 1);
          if (!errToasted.has(String(it.id))) {
            errToasted.add(String(it.id));
            toastSafe('بارگذاری پیوست «' + (it.name || '') + '» در سرور ناموفق بود' + (r.message ? ' — ' + r.message : ''), 'error');
          }
        }
      } catch (eUp) {
        console.warn('[CBM_ATT] upload error', it.id, eUp);
        tries.set(String(it.id), (tries.get(String(it.id)) || 0) + 1);
      }
    }
    return doneCount;
  }
  /* پیمایش کل db: پیوست‌های برنامه (OwnerType 1) و ریزتقاضاها (OwnerType 2) */
  async function flushPending() {
    if (!isEnabled() || flushing) return;
    flushing = true;
    try {
      var d = getDB();
      if (!d || !Array.isArray(d.programs)) return;
      for (var i = 0; i < d.programs.length; i++) {
        var p = d.programs[i];
        if (!p || typeof p !== 'object') continue;
        if (attsOf(p).some(hasPendingAtt)) { try { await uploadOwner(p); } catch (e1) { console.warn('[CBM_ATT] flush prog error', e1); } }
        var ms = Array.isArray(p.micros) ? p.micros : [];
        for (var j = 0; j < ms.length; j++) {
          var m = ms[j];
          if (m && typeof m === 'object' && attsOf(m).some(hasPendingAtt)) { try { await uploadOwner(m); } catch (e2) { console.warn('[CBM_ATT] flush micro error', e2); } }
        }
      }
    } catch (e) {
      console.warn('[CBM_ATT] flush error', e);
    } finally {
      flushing = false;
    }
  }

  /* ---------- دانلود ---------- */
  async function download(a, lnk) {
    try {
      if (!isEnabled()) return false;
      var id = a && (a.serverId || a.id);
      if (!id) { toastSafe('شناسه پیوست برای دانلود یافت نشد', 'error'); return false; }
      var res = await fetch(API() + '/attachments/' + encodeURIComponent(String(id)), { credentials: 'same-origin' });
      if (res.status === 401) { authed = false; toastSafe('نشست شما منقضی شده است؛ دوباره وارد شوید', 'error'); return false; }
      if (!res.ok) { toastSafe(problemMsg(res, null), 'error'); return false; }
      var blob = await res.blob();
      var url = URL.createObjectURL(blob);
      lnk.href = url;
      lnk.download = a.name || ('file-' + a.id);
      (document.body || document.documentElement).appendChild(lnk);
      lnk.click();
      lnk.remove();
      setTimeout(function () { try { URL.revokeObjectURL(url); } catch (eR) {} }, 4000);
      return true;
    } catch (e) {
      console.warn('[CBM_ATT] download error', e);
      try { toastSafe('دریافت پیوست از سرور ناموفق بود', 'error'); } catch (e2) {}
      return false;
    }
  }

  /* ---------- حذف ---------- */
  /* true = حذف سروری موفق (ادامه حذف محلی مجاز)؛ false = ناموفق (حذف محلی باید رد شود) */
  async function remove(a, o) {
    try {
      if (!isEnabled()) return true;
      var id = a && (a.serverId || a.id);
      if (!id) { toastSafe('شناسه پیوست برای حذف یافت نشد', 'error'); return false; }
      var r = await apiFetch('/attachments/' + encodeURIComponent(String(id)), { method: 'DELETE', silent: true });
      if (r.ok) { pending.delete(String(a.id)); return true; }
      if (r.status === 401) { authed = false; toastSafe('نشست شما منقضی شده است؛ دوباره وارد شوید', 'error'); }
      else { toastSafe('حذف پیوست در سرور ناموفق بود' + (r.message ? ' — ' + r.message : ''), 'error'); }
      return false;
    } catch (e) {
      console.warn('[CBM_ATT] remove error', e);
      try { toastSafe('حذف پیوست در سرور ناموفق بود', 'error'); } catch (e2) {}
      return false;
    }
  }

  /* ---------- پاک‌سازی برای ذخیره‌سازی محلی ----------
     ورودی db دست‌نخورده می‌ماند؛ خروجی کپی کم‌عمق است که فقط در
     آیتم‌های پیوست remote/pendingRemote مقدار data را null می‌کند. */
  function stripAtt(a) {
    if (a && (a.remote || a.pendingRemote)) {
      var c = Object.assign({}, a);
      c.data = null;
      return c;
    }
    return a;
  }
  function stripRemoteData(d) {
    if (!isEnabled()) return d; /* غیرفعال: بدون هیچ تغییری */
    try {
      if (!d || !Array.isArray(d.programs)) return d;
      var out = Object.assign({}, d);
      out.programs = d.programs.map(function (p) {
        if (!p || typeof p !== 'object') return p;
        var q = Object.assign({}, p);
        if (Array.isArray(p.atts)) q.atts = p.atts.map(stripAtt);
        if (Array.isArray(p.micros)) {
          q.micros = p.micros.map(function (m) {
            if (!m || typeof m !== 'object') return m;
            var mm = Object.assign({}, m);
            if (Array.isArray(m.atts)) mm.atts = m.atts.map(stripAtt);
            return mm;
          });
        }
        return q;
      });
      return out;
    } catch (e) {
      console.warn('[CBM_ATT] stripRemoteData error', e);
      return d;
    }
  }

  function isRemote(a) { try { return !!(a && (a.remote || a.pendingRemote)); } catch (e) { return false; } }

  /* ---------- API عمومی ---------- */
  var APIObj = {
    version: '1.0',
    login: login,
    logout: logout,
    apiFetch: apiFetch,
    resolveOwner: resolveOwner,
    trackPending: trackPending,
    tryUploadNow: tryUploadNow,
    flushPending: flushPending,
    download: download,
    remove: remove,
    stripRemoteData: stripRemoteData,
    sanitizeForSave: stripRemoteData, /* نام مستعار */
    isRemote: isRemote,
    pending: pending,
    ownerCache: ownerCache
  };
  try { Object.defineProperty(APIObj, 'enabled', { get: isEnabled, enumerable: true, configurable: true }); } catch (e) { APIObj.enabled = isEnabled(); }

  return APIObj;
})();
"""

# ----------------------------------------------------------------
# P1 — آداپتور + پیکربندی، درست پیش از ثابت‌های پیوست (درون همان
# <script> اصلی؛ طبق معماری مصوب، پیش‌فرض غیرفعال)
# ----------------------------------------------------------------
P1_ANCHOR = 'const ATT_MAX_SIZE = 1024 * 1024;'
P1_HEAD = (
    '/* A5-PATCH(P1) — آداپتور پیوست‌ها (CBM_ATT) و پیکربندی اتصال\n'
    '   فعال‌سازی: window.CBM_API_CONFIG = { enabled: true, baseUrl: \'/api\' }\n'
    '   پیش‌فرض: enabled:false ⇒ هیچ رفتاری از اپ تغییر نمی‌کند.\n'
    '   جزئیات: cbm-attachments-adapter.js و Diff-Report.md (تسک A5)\n'
    '   ================================================================ */\n'
    "window.CBM_API_CONFIG = { enabled: false, baseUrl: '/api' };\n"
)

# ----------------------------------------------------------------
# P2 — انشعاب در attsAddFiles (درون attsBind): در حالت متصل به‌جای
# خواندن dataURL، متادیتا با data:null افزوده و فایل در نگاشت
# pending آداپتور ثبت می‌شود؛ اعتبارسنجی‌های قبلی (تعداد/حجم/تکرار)
# عیناً بازاستفاده می‌شوند. سپس تلاش برای بارگذاری فوری.
# ----------------------------------------------------------------
P2_ANCHOR = (
    "      const rd = new FileReader();\n"
    "      rd.onload = () => {\n"
    "        cur.push({ id: uid(), name: f.name, size: f.size, type: f.type || '', data: String(rd.result), byId: me.id || '', by: me.id ? (me.fn + ' ' + me.ln) : '', date: todayJStr(), time: nowTimeStr() });\n"
    "        done(true, f.name);\n"
    "      };\n"
    "      rd.onerror = () => { lastErr = 'خواندن فایل «' + f.name + '» ناموفق بود'; done(false); };\n"
    "      rd.readAsDataURL(f);\n"
    "    });"
)
P2_REPL = (
    "      /* A5-PATCH(P2): حالت متصل — فایل در نگاشت pending آداپتور نگه داشته می‌شود و متادیتا با data=null\n"
    "         و pendingRemote:true از همان مسیر (cur.push + done) افزوده می‌شود؛ اعتبارسنجی‌های بالا عیناً مشترک‌اند */\n"
    "      if (window.CBM_ATT && CBM_ATT.enabled){\n"
    "        const __attItem = { id: uid(), name: f.name, size: f.size, type: f.type || '', data: null, byId: me.id || '', by: me.id ? (me.fn + ' ' + me.ln) : '', date: todayJStr(), time: nowTimeStr(), pendingRemote: true };\n"
    "        cur.push(__attItem);\n"
    "        CBM_ATT.trackPending(__attItem, f);\n"
    "        done(true, f.name);\n"
    "      } else {\n"
    "      const rd = new FileReader();\n"
    "      rd.onload = () => {\n"
    "        cur.push({ id: uid(), name: f.name, size: f.size, type: f.type || '', data: String(rd.result), byId: me.id || '', by: me.id ? (me.fn + ' ' + me.ln) : '', date: todayJStr(), time: nowTimeStr() });\n"
    "        done(true, f.name);\n"
    "      };\n"
    "      rd.onerror = () => { lastErr = 'خواندن فایل «' + f.name + '» ناموفق بود'; done(false); };\n"
    "      rd.readAsDataURL(f);\n"
    "      }\n"
    "    });\n"
    "    /* A5-PATCH(P2): بارگذاری فوری اگر مالک سمت سرور قابل‌تشخیص باشد (کد برنامه/SeqNo ریزتقاضا)؛\n"
    "       در غیر این صورت، flushPending در saveDB آن را دنبال می‌کند */\n"
    "    if (window.CBM_ATT && CBM_ATT.enabled) { try { CBM_ATT.tryUploadNow(o); } catch (eUp) {} }"
)

# ----------------------------------------------------------------
# P3 — انشعاب دانلود در کلیک‌هندلر attsBind؛ خط appendChild/click/
# remove بعدی دست‌نخورده می‌ماند (آداپتور خودش href را تنظیم و click
# را پس از دریافت blob انجام می‌دهد).
# ----------------------------------------------------------------
P3_ANCHOR = (
    "      const lnk = document.createElement('a');\n"
    "      lnk.href = a.data; lnk.download = a.name || ('file-' + a.id);"
)
P3_REPL = (
    "      const lnk = document.createElement('a');\n"
    "      /* A5-PATCH(P3): در حالت متصل، پیوست‌های راه‌دور از طریق API دانلود می‌شوند (blob → objectURL)؛\n"
    "         click پویای سطر بعد در این حالت بی‌اثر است و آداپتور خودش پس از دریافت فایل click را انجام می‌دهد */\n"
    "      if (window.CBM_ATT && CBM_ATT.enabled && (a.remote || a.pendingRemote)) { CBM_ATT.download(a, lnk); }\n"
    "      else { lnk.href = a.data; lnk.download = a.name || ('file-' + a.id); }"
)

# ----------------------------------------------------------------
# P4 — انشعاب حذف در کلیک‌هندلر attsBind: در حالت متصل ابتدا DELETE
# سمت سرور؛ در صورت شکست، حذف محلی/تاریخچه/toast موفقیت انجام
# نمی‌شود (پیام‌ها و ثبت تاریخچه دقیقاً حفظ شده‌اند).
# ----------------------------------------------------------------
P4_ANCHOR = (
    "          if (!ok) return;\n"
    "          o.atts = list().filter(x => x.id !== id);\n"
    "          /* نوبت ۳۲: ثبت حذف پیوست در تاریخچه */\n"
    "          if (histFn) histFn(false, [a.name]);\n"
    "          toast('پیوست حذف شد', 'success');\n"
    "          if (onChange) onChange();\n"
    "          else rerender();"
)
P4_REPL = (
    "          if (!ok) return;\n"
    "          /* A5-PATCH(P4): در حالت متصل ابتدا حذف سمت سرور؛ در صورت شکست، حذف محلی و تاریخچه انجام نمی‌شود */\n"
    "          const __attDelLocal = () => {\n"
    "            o.atts = list().filter(x => x.id !== id);\n"
    "            /* نوبت ۳۲: ثبت حذف پیوست در تاریخچه */\n"
    "            if (histFn) histFn(false, [a.name]);\n"
    "            toast('پیوست حذف شد', 'success');\n"
    "            if (onChange) onChange();\n"
    "            else rerender();\n"
    "          };\n"
    "          if (window.CBM_ATT && CBM_ATT.enabled && (a.remote || a.pendingRemote)){\n"
    "            Promise.resolve(CBM_ATT.remove(a, o))\n"
    "              .then(rmOk => { if (rmOk === false){ return; } __attDelLocal(); })\n"
    "              .catch(() => { toast('حذف پیوست در سرور ناموفق بود؛ دوباره تلاش کنید', 'error'); });\n"
    "          } else { __attDelLocal(); }"
)

# ----------------------------------------------------------------
# P5 — هوک اول saveDB: flushPending آتش-و-فراموش در ابتدای تابع
# (هرگز مسدودکننده نیست؛ شکست آداپتور در try گیر می‌افتد).
# ----------------------------------------------------------------
P5_ANCHOR = 'function saveDB(silent){'
P5_REPL = (
    'function saveDB(silent){\n'
    '  /* A5-PATCH(P5): همگام‌سازی پیوست‌های در انتظار — آتش-و-فراموش؛ هرگز ذخیره‌سازی محلی را مسدود یا خراب نمی‌کند */\n'
    '  if (window.CBM_ATT && CBM_ATT.enabled) { try { CBM_ATT.flushPending(); } catch (eFP) {} }'
)

# ----------------------------------------------------------------
# P6 — هوک دوم saveDB: تصویر ذخیره‌سازی از آداپتور گرفته می‌شود؛
# در حالت متصل داده باینری (dataURL) پیوست‌های راه‌دور از snapshot
# حذف می‌شود تا localStorage پر نشود (db اصلی دست‌نخورده می‌ماند).
# ----------------------------------------------------------------
P6_ANCHOR = (
    "  try { localStorage.setItem(DB_KEY, JSON.stringify(db)); if (!silent) toast('داده‌ها با موفقیت ذخیره شد', 'success'); }"
)
P6_REPL = (
    '  /* A5-PATCH(P6): در حالت متصل، داده باینری (dataURL) پیوست‌های راه‌دور از تصویر ذخیره‌سازی حذف می‌شود\n'
    '     (کپی کم‌عمق از آداپتور؛ db اصلی و پیوست‌های محلی دست‌نخورده می‌مانند) */\n'
    '  const __snap = (window.CBM_ATT && CBM_ATT.enabled) ? CBM_ATT.stripRemoteData(db) : db;\n'
    "  try { localStorage.setItem(DB_KEY, JSON.stringify(__snap)); if (!silent) toast('داده‌ها با موفقیت ذخیره شد', 'success'); }"
)

# ----------------------------------------------------------------
# P7 — هوک ورود: پس از استقرار نشست محلی، ورود به سرور پیوست‌ها
# (غیرهمگام؛ شکست فقط هشدار — ورود اپ هرگز خراب نمی‌شود).
# لنگر با دو خط زمینه یکتا شده است (نمونه دوم در init نشست، زمینه‌اش
# متفاوت است).
# ----------------------------------------------------------------
P7_ANCHOR = (
    "  session.user = u;\n"
    "  try { sessionStorage.setItem(SESSION_KEY, u.username); } catch (e) {}"
)
P7_REPL = (
    "  session.user = u;\n"
    "  /* A5-PATCH(P7): ورود غیرهمگام به سرور پیوست‌ها — غیرمسدودکننده؛ شکست فقط هشدار می‌دهد */\n"
    "  if (window.CBM_ATT && CBM_ATT.enabled) { try { CBM_ATT.login(username, pass); } catch (eLg) {} }\n"
    "  try { sessionStorage.setItem(SESSION_KEY, u.username); } catch (e) {}"
)

# ----------------------------------------------------------------
# P8 — هوک خروج: ابطال نشست سرور پیوست‌ها پس از خروج محلی.
# ----------------------------------------------------------------
P8_ANCHOR = (
    "      session.user = null;\n"
    "      try { sessionStorage.removeItem(SESSION_KEY); } catch (e) {}"
)
P8_REPL = (
    "      session.user = null;\n"
    "      /* A5-PATCH(P8): ابطال نشست سرور پیوست‌ها (غیرمسدودکننده) */\n"
    "      if (window.CBM_ATT && CBM_ATT.enabled) { try { CBM_ATT.logout(); } catch (eLo) {} }\n"
    "      try { sessionStorage.removeItem(SESSION_KEY); } catch (e) {}"
)

# ----------------------------------------------------------------
# فهرست ترتیبی وصله‌ها (هر لنگر باید دقیقاً یک‌بار یافت شود)
# ----------------------------------------------------------------
PATCHES = [
    {
        'pid': 'P1',
        'desc': 'درج آداپتور CBM_ATT + پیکربندی CBM_API_CONFIG (پیش‌فرض غیرفعال) پیش از ثابت‌های پیوست',
        'anchor': P1_ANCHOR,
        'replacement': P1_HEAD + ADAPTER_JS + '\n' + P1_ANCHOR,
    },
    {
        'pid': 'P2',
        'desc': 'انشعاب افزودن در attsAddFiles: حالت متصل = متادیتا با data:null + نگهداری فایل در CBM_ATT.pending + تلاش بارگذاری فوری',
        'anchor': P2_ANCHOR,
        'replacement': P2_REPL,
    },
    {
        'pid': 'P3',
        'desc': 'انشعاب دانلود در attsBind: پیوست راه‌دور از طریق CBM_ATT.download (blob از API)',
        'anchor': P3_ANCHOR,
        'replacement': P3_REPL,
    },
    {
        'pid': 'P4',
        'desc': 'انشعاب حذف در attsBind: DELETE سمت سرور؛ شکست ⇒ صرف‌نظر از حذف محلی + toast خطا',
        'anchor': P4_ANCHOR,
        'replacement': P4_REPL,
    },
    {
        'pid': 'P5',
        'desc': 'هوک saveDB: فراخوانی آتش-و-فراموش CBM_ATT.flushPending در ابتدای تابع',
        'anchor': P5_ANCHOR,
        'replacement': P5_REPL,
    },
    {
        'pid': 'P6',
        'desc': 'هوک saveDB: استفاده از تصویر پاک‌سازی‌شده CBM_ATT.stripRemoteData(db) پیش از JSON.stringify',
        'anchor': P6_ANCHOR,
        'replacement': P6_REPL,
    },
    {
        'pid': 'P7',
        'desc': 'هوک doLogin: ورود غیرهمگام به سرور پیوست‌ها پس از session.user = u',
        'anchor': P7_ANCHOR,
        'replacement': P7_REPL,
    },
    {
        'pid': 'P8',
        'desc': 'هوک logout: ابطال نشست سرور پیوست‌ها پس از session.user = null',
        'anchor': P8_ANCHOR,
        'replacement': P8_REPL,
    },
]

# توجه: P5 و P6 دو وصله مستقل با دو لنگر مجزا در saveDB هستند
# (ابتدای تابع برای P5 و خط JSON.stringify برای P6) و ترتیب اعمال
# آن‌ها روی هم اثر تخریبی ندارد.


def apply_patches(src, verbose=True):
    """اعمال ترتیبی وصله‌ها با assert یکتایی هر لنگر.
    خروجی: (src_new, گزارش) — در صورت شکست، AssertionError با پیام فارسی."""
    report = []
    for p in PATCHES:
        anchor = p['anchor']
        n = src.count(anchor)
        if n != 1:
            raise AssertionError(
                'لنگر %s باید دقیقاً یک‌بار در فایل باشد؛ یافته‌شده: %d بار — توقف بدون نوشتن خروجی.'
                % (p['pid'], n)
            )
        before_line = src.count('\n', 0, src.index(anchor)) + 1
        src = src.replace(anchor, p['replacement'], 1)
        inserted = p['replacement'].count('\n') - anchor.count('\n')
        after_line = before_line  # ناحیه تغییر از همین خط شروع می‌شود
        end_line = before_line + max(inserted, 0)
        report.append({
            'pid': p['pid'], 'desc': p['desc'],
            'anchor_line': before_line,
            'after_start': after_line, 'after_end': end_line,
            'lines_added': inserted,
        })
        if verbose:
            print('  ✔ %s اعمال شد — لنگر در خط %d؛ پس از وصله: خطوط %d تا %d (+%d خط)'
                  % (p['pid'], before_line, after_line, end_line, inserted))
    return src, report


def main(argv=None):
    ap = argparse.ArgumentParser(
        description='وصله جراحی اتصال پیوست‌ها به REST API (تسک A5)')
    ap.add_argument('input', nargs='?', default=DEFAULT_SRC,
                    help='مسیر HTML ورودی (پیش‌فرض: فایل پایدار v3.1.1)')
    ap.add_argument('-o', '--output', default=None,
                    help='مسیر خروجی (پیش‌فرض: کنار ورودی با پسوند .attachments.html)')
    ap.add_argument('--no-adapter-sync', action='store_true',
                    help='همگام‌سازی cbm-attachments-adapter.js انجام نشود')
    args = ap.parse_args(argv)

    src_path = os.path.abspath(args.input)
    if not os.path.isfile(src_path):
        print('✖ فایل ورودی یافت نشد: ' + src_path)
        return 2

    with open(src_path, 'r', encoding='utf-8', newline='') as f:
        src = f.read()
    orig_len = len(src)

    print('== اعمال وصله‌های A5 روی: %s' % src_path)
    try:
        out, report = apply_patches(src, verbose=True)
    except AssertionError as e:
        print('✖ خطای لنگر: %s' % e)
        return 2

    out_path = os.path.abspath(args.output) if args.output else os.path.join(os.path.dirname(src_path), OUT_NAME)
    with open(out_path, 'w', encoding='utf-8', newline='') as f:
        f.write(out)

    # همگام‌سازی نسخه بازبینی آداپتور (عین رشته داخلی)
    if not args.no_adapter_sync:
        here = os.path.dirname(os.path.abspath(__file__))
        adapter_path = os.path.join(here, 'cbm-attachments-adapter.js')
        with open(adapter_path, 'w', encoding='utf-8', newline='\n') as f:
            f.write(ADAPTER_JS)
        print('== نسخه بازبینی آداپتور همگام شد: %s' % adapter_path)

    # خلاصه فارسی
    print('')
    print('================= خلاصه وصله‌ها (A5) =================')
    for r in report:
        print('%s | لنگر خط %d (قبل) → خطوط %d–%d (بعد) | %s'
              % (r['pid'], r['anchor_line'], r['after_start'], r['after_end'], r['desc']))
    print('------------------------------------------------------')
    print('حجم قبل : %s نویسه' % f'{orig_len:,}')
    print('حجم بعد : %s نویسه' % f'{len(out):,}')
    print('تفاوت   : %+d نویسه (فقط ناحیه‌های ۸ وصله)' % (len(out) - orig_len))
    print('✔ خروجی نوشته شد: %s' % out_path)
    print('وضعیت اتصال پیش‌فرض: CBM_API_CONFIG.enabled = false (رفتار فعلی صددرصد حفظ شده)')
    return 0


if __name__ == '__main__':
    sys.exit(main())
