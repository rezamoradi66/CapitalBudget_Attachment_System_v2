# گزارش تغییرات نسخه ۲ — دور بازبینی اصلاحی (Change-Report v2)

**مبنای مقایسه:** بسته تحویل‌شده v1 (`CapitalBudget_Attachment_System_v1.zip` — SHA-256 `d17dafa5…b9e7c`) در برابر بسته اصلاحی v2 (همین بسته).
**دامنه:** هشت بند بازبینی کارفرما؛ **هیچ** فایل HTML/آداپتور/اسکریپت وصله‌ای تغییر نکرد؛ **هیچ** تغییر عملیاتی انجام نشد؛ TC-ATT-030…043 همچنان PENDING-LAB.

---

## ۱. نقشه هشت بند بازبینی به اصلاحات

| # | بند کارفرما | تصمیم مهندسی | وضعیت |
|---|---|---|---|
| ۱ | حذف رمز ثابت آزمایشی (رشته رمز/هش ثابت) از Seed/مستندات + تولید رمز تصادفی امن + حفظ تغییر اجباری | حذف کامل رمز و هش ثابت؛ مولد CSPRNG (`InitialPasswordGenerator` در Core + ابزار کنسول `LabCredentialGenerator`)؛ اسکریپت ۰۵ هش را با متغیر SQLCMD می‌گیرد و قالب را سخت اعتبارسنجی می‌کند (طول ۸۳/پیشوند/Base64/پدینگ)؛ `MustChangePassword=1` دست‌نخورده | ✅ |
| ۲ | قفل ورود ۵/۱۵ + مقاومت چند-IP + سوءاستفاده قفل | مکانیزم ۵/۱۵ از v1 موجود بود (D-02) و حفظ شد؛ سخت‌سازی: کلید قفل نرمال‌شده (بزرگ/کوچک حروف و فاصله‌ها همان حساب)؛ مقاومت چند-IP با آزمون سطح سرویس (۵ IP) اثبات شد؛ دو تهدید جدید در Security-Plan §۲ + پیشنهاد D-23 (گزینه‌ها برای تصمیم کارفرما — بدون کد جدید) | ✅ |
| ۳ | Rollback: تعداد ستون دلیل حذف نیست | معیار «۱۸ ستون» به‌کلی حذف؛ فقط نشانگر مالکیت `CreatedByScript='02-Create-Attachment-Structure'` (فقط توسط اسکریپت ۰۲ ثبت می‌شود) مجوز DROP می‌دهد؛ بدون نشانگر = فقط حذف الحاقیات v6 | ✅ |
| ۴ | کنترل حجم پیش از خواندن کامل + سقف HTTP/حافظه | بافر کامل `MemoryStream` + `ToArray()` حذف؛ خواندن قطع‌شدنی قطعه‌ای ۶۴KB؛ چهار لایه سقف هم‌نوا: `IISServerOptions.MaxRequestBodySize` و Kestrel (سقف فایل+۶۴KB) → Middleware `Content-Length` (۴۱۳ پیش از خواندن) → `MultipartBodyLengthLimit` (بافر فریم‌ورک از ۱۲۸MB به ≈۱MB محدود) → خواندن کاربردی؛ مصرف حافظه کاربرد ≤ سقف + یک قطعه؛ نگاشت `InvalidDataException` سقف multipart به همان ۴۱۳ قراردادی | ✅ |
| ۵ | بدون پیکربندی معتبر، پیش‌فرض خاموش DB ممنوع | fallback `Server=.;Database=CapitalBudgetDB;Trusted_Connection=…` حذف؛ اعتبارسنجی در **استارتاپ** (نه اولین کوئری): Provider غیر InMemory + کانکشن خالی → استثنای روشن فارسی و توقف | ✅ |
| ۶ | آزمون خودکار برای هر اصلاح + عدم اعلام آزمون اجرانشده | ۱۹ آزمون جدید (۵+۴+۵+۳+۲) — همه اجرا و PASS (۱۰۸/۱۰۸ از TRX واقعی) + ۱۰ راستی‌آزمایی شبیه‌سازی‌شده منطق اعتبارسنجی SQL؛ هیچ نتیجه‌ای از آزمون اجرانشده گزارش نشده | ✅ |
| ۷ | FILESTREAM/پشتیبان/بازیابی PENDING-LAB بماند | TC-ATT-030…043 دست‌نخورده؛ در v2 اجرای واقعی اسکریپت‌های ۰۵/۹۹ نیز صراحتاً PENDING-LAB ثبت شد (Open-Issues §۵-۵/۶) | ✅ |
| ۸ | هیچ تغییر عملیاتی | همه کارها در sandbox توسعه؛ بدون هیچ اتصال به سرور/دیتابیس عملیاتی | ✅ |

---

## ۲. تفاوت فایل‌به‌فایل (نسخه‌های کامل بدون خروجی‌های ساخت)

خروجی اسکریپت مقایسه (`scripts/diff_packages_v1_v2.py` — SHA-256 فایل‌به‌فایل): **۷۵ فایل بدون تغییر، ۱۳ فایل جدید (۱۲ مورد اصلاحی + همین سند گزارش تغییر)، ۱۶ فایل تغییر‌یافته، ۰ فایل حذف‌شده** (پوشه `publish/` جداگانه: ۶۶ فایل در هر دو نسخه، باینری‌ها با بیلد v2 بازتولید شده‌اند).

### فایل‌های جدید (۱۲ + همین سند)
| فایل | دلیل |
|---|---|
| `02-Database/tools/LabCredentialGenerator/Program.cs` + `.csproj` | بند ۱ — مولد رمز تصادفی امن (CSPRNG) + هش قالب استاندارد |
| `03-API/…/src/Attachments.Core/Services/InitialPasswordGenerator.cs` | بند ۱ — هسته مولد (آزمون‌پذیر) |
| `03-API/…/src/Attachments.Core/Services/UploadLimitsGuard.cs` | بند ۴ — خواندن قطع‌شدنی + پیام یکنواخت ۴۱۳ |
| `03-API/…/src/Attachments.Api/Http/FormFileLimits.cs` | بند ۴ — پوشش IFormFile (Core بدون وابستگی ASP.NET می‌ماند) |
| `03-API/…/src/Attachments.Api/Middleware/RequestSizeGuardMiddleware.cs` | بند ۴ — رد ۴۱۳ پیش از خواندن بدنه |
| `03-API/…/tests/Attachments.Tests/Unit/AuthServiceLockoutTests.cs` | بند ۲ — ۵ آزمون قفل حساب/چند-IP/کلید نرمال |
| `03-API/…/tests/Attachments.Tests/Unit/InitialPasswordGeneratorTests.cs` | بند ۱ — ۴ آزمون مولد |
| `03-API/…/tests/Attachments.Tests/Unit/UploadLimitsGuardTests.cs` | بند ۴ — ۵ آزمون خواندن محدود |
| `03-API/…/tests/Attachments.Tests/Integration/UploadLimitTests.cs` | بند ۴ — ۳ آزمون یکپارچگی سقف‌ها (کارخانه ۴KB) |
| `03-API/…/tests/Attachments.Tests/Integration/ConnectionStringStartupTests.cs` | بند ۵ — ۲ آزمون استارتاپ |
| `03-API/…/tests/Attachments.Tests/TestResults/att-v2.trx` | شاهد اجرا — نتیجه خام ۱۰۸/۱۰۸ (TRX واقعی runner) |

### فایل‌های تغییر‌یافته (۱۶)
| فایل | خلاصه تغییر |
|---|---|
| `02-Database/sql/05-Seed-Lab-Minimal.sql` | حذف رمز/هش ثابت؛ گام ۱٫۵ اعتبارسنجی سخت هش؛ درج با `$(InitialPasswordHash)`؛ به‌روزرسانی سرصفحه |
| `02-Database/sql/99-Rollback-Attachment-Structure.sql` | حذف معیار «۱۸ ستون»؛ DROP فقط با نشانگر مالکیت؛ پیام صریح در نبود نشانگر |
| `02-Database/Runbook-Lab-Deployment.md` | گام ۷ بازنویسی (زیرگام ۷-۱ مولد رمز، ۷-۲ اجرای پارامتری)؛ جدول ثبت‌ها |
| `03-API/…/src/Attachments.Api/Program.cs` | Fail-fast کانکشن‌استرینگ؛ چهار لایه سقف حجم؛ ثبت RequestSizeGuardMiddleware؛ لاگ استارتاپ |
| `03-API/…/src/Attachments.Api/Controllers/AttachmentsController.cs` | حذف بافر کامل؛ خواندن محدود؛ تزریق `AttachmentLimits` |
| `03-API/…/src/Attachments.Api/Middleware/ExceptionHandlingMiddleware.cs` | نگاشت سقف multipart → ۴۱۳ قراردادی |
| `03-API/…/src/Attachments.Core/Application/AuthService.cs` | کلید قفل نرمال‌شده (بند ۲) |
| `03-API/…/src/Attachments.Core/Application/AttachmentService.cs` | پیام ۴۱۳ از `UploadLimitsGuard` (یکنواختی) |
| `03-API/API-SPEC.md` | مستند لایه‌بندی ۴۱۳ |
| `03-API/BUILD-AND-RUN.md` | نتایج v2؛ fail-fast کانکشن؛ سقف حجم درخواست |
| `05-Operations/IIS-Deployment-Guide.md` | بخش «سقف حجم درخواست در IIS» (maxAllowedContentLength) |
| `01-Planning/Attachment-Security-Plan.md` | سطرهای ۱ و ۵؛ سه تهدید جدید؛ §۴ محرمانگی |
| `01-Planning/Attachment-Open-Issues.md` | D-23 پیشنهادی؛ شمارش موارد کارفرما؛ محدودیت‌های v2 |
| `06-Tests/Test-Report-Executed.md` | بخش آزمون‌های جدید v2؛ شمارش ۱۰۸/۱۰۸؛ مرز PENDING-LAB |
| `07-Compliance/Compliance-Report.md` | بخش §۲-ب — انطباق هشت‌بندی بازبینی |
| `README.md` | نسخه ۲؛ نقشه بسته؛ خلاصه اصلاحات |

### بدون تغییر (شواهد)
هر ۷ فایل `04-HTML-Patch/`، ۴ سند دیگر `01-Planning/`، اسکریپت‌های ۰۰/۰۱/۰۲/۰۳/۰۴، اسناد 05-Operations دیگر، `Lab-Test-Runbook.md` (TC-ATT-030…043 حفظ)، `sample-requests.http`، `appsettings*.json`، `Database-Structure.md`.

> نکته: در تست‌های v1 رمزهای سینتتیک `DbSeed` (الگوی «نام‌نقش + پسوند ثابت»، ۵ مقدار) حفظ شدند — این‌ها اعتبارنامه واقعی نیستند و فقط میزبان تست InMemory را تغذیه می‌کنند (طبق طبقه‌بندی اسکن v1)؛ بند ۱ ناظر به Seed SQL و مستندات بود و آن‌ها اصلاح شد. اسکن v2: صفر رشته ممنوعه (رمز ثابت آزمایشی قدیمی + هش آن) در کل بسته.

---

## ۳. فهرست آزمون‌های اجراشده (نسخه v2 — واقعی)

**ساخت:** `dotnet build -c Release` → 0 خطا / 0 هشدار (SDK 10.0.402) + ساخت ابزار مولد (0/0) + اجرای واقعی ابزار (یک اعتبارنامه تولید شد و هش آن در اعتبارسنجی شبیه‌سازی قبول شد).

**آزمون‌ها:** `dotnet test -c Release` → **108/108 PASS، 0 Failed، 0 Skipped** (TRX: `03-API/AttachmentsModule/tests/Attachments.Tests/TestResults/att-v2.trx`).

۱۹ آزمون جدید:
- `AuthServiceLockoutTests`: Lockout_EngagesAtFifthFailure_ForFifteenMinutes · Lockout_RejectsEvenCorrectPassword_UntilLockExpires · Lockout_CountsAttempts_AcrossDifferentClientIps · Lockout_Key_IsCaseAndWhitespaceInsensitive · SuccessfulLogin_ResetsTheFailedCounter
- `InitialPasswordGeneratorTests`: GeneratedPassword_HasDocumentedLength_AndAlphabetOnly · GeneratedPasswords_SatisfyPasswordPolicy · GeneratedHash_MatchesTheExactStorageFormat_AndVerifies · GeneratedCredentials_AreUniqueAcrossCalls
- `UploadLimitsGuardTests`: ReadStream_ExactlyAtLimit_ReadsEverything · ReadStream_OneByteBeyondLimit_Throws413FileTooLarge · ReadStream_FarBeyondLimit_AbortsEarly_WithoutBufferingWholeBody · ReadStream_EmptyInput_ReturnsEmptyArray · ReadStream_SmallBody_ReadsExactly
- `UploadLimitTests` (یکپارچگی): Upload_BeyondBodyCap_IsRejectedBeforeReading_WithStable413 · Upload_BeyondFileLimit_UnderBodyCap_Is413FileTooLarge · Upload_UnderLimit_StillSucceeds
- `ConnectionStringStartupTests`: SqlServerProvider_WithoutConnectionString_FailsFastAtStartup · InMemoryProvider_WithoutConnectionString_StillStarts

**راستی‌آزمایی خارج از dotnet:** شبیه‌سازی منطق اعتبارسنجی هش اسکریپت ۰۵ → ۱۰/۱۰ (۴ هش واقعی ابزار = قبول؛ ۶ ورودی نامعتبر = رد).

**PENDING-LAB (عمداً اجرا نشده — بدون SQL Server در محیط توسعه):** اجرای اسکریپت‌های ۰۰/۰۱/۰۲/۰۳/۰۴/۰۵/۹۹ روی SQL Server؛ TC-ATT-030…043 (FILESTREAM/پشتیبان/بازیابی)؛ رفتار لایه انتقال Kestrel/IIS (TestServer ندارد).

---

## ۴. سازگاری پس‌رونده

- قرارداد HTTP بدون تغییر؛ تنها بهبود: رد بدنه‌های بزرگ اکنون در همه لایه‌ها ۴۱۳ قراردادی است (قبلاً تا ۱۲۸MB بافر و سپس ۴۱۳ می‌شد).
- متغیر محیطی جدیدی الزامی نشده؛ `ConnectionStrings__Default` اکنون **الزامی واقعی** است (در v1 غیبتش بی‌صدا به `Server=.` می‌افتاد).
- جداول/رویه‌های دیتابیس تغییر نکرده‌اند؛ فقط اسکریپت ۰۵ یک متغیر SQLCMD جدید (`InitialPasswordHash`) و اسکریپت ۹۹ معیار سخت‌گیرانه‌تر دارد.
- مسیر ارتقای v1→v2: جایگزینی بسته کافی است؛ هیچ داده/اسکیمای عملیاتی درگیر نیست.
